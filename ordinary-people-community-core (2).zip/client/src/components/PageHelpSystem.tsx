import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { HelpCircle, BookOpen, Users, MessageCircle, ShoppingCart, Heart, Search, Brain, Home, User, Phone, Globe, Settings, ChevronRight } from "lucide-react";
import { useTranslation } from "@/hooks/useTranslation";

interface PageHelpSystemProps {
  currentPage?: string;
}

export function PageHelpSystem({ currentPage = "dashboard" }: PageHelpSystemProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { t } = useTranslation();

  // Prevent auto-closing - only close when explicitly requested
  const handleOpenChange = (open: boolean) => {
    setIsOpen(open);
  };

  // Listen for custom open instructions events
  useEffect(() => {
    const handleOpenInstructions = () => {
      console.log("Custom event received - opening instructions");
      setIsOpen(true);
    };
    
    const handleForceOpenInstructions = () => {
      console.log("Force event received - opening instructions");
      setIsOpen(true);
    };
    
    document.addEventListener('openInstructions', handleOpenInstructions);
    document.addEventListener('forceOpenInstructions', handleForceOpenInstructions);
    
    return () => {
      document.removeEventListener('openInstructions', handleOpenInstructions);
      document.removeEventListener('forceOpenInstructions', handleForceOpenInstructions);
    };
  }, []);

  // Simple event handling - let dialog work normally
  useEffect(() => {
    // Just ensure dialog content is visible when open
    if (isOpen) {
      const dialog = document.querySelector('[data-dialog-content="true"]');
      if (dialog) {
        (dialog as HTMLElement).style.zIndex = '9999';
      }
    }
  }, [isOpen]);

  const pageData: Record<string, any> = {
    dashboard: {
      title: t('dashboard.title'),
      description: t('dashboard.helpDescription'),
      steps: [
        t('dashboard.helpStep1'),
        t('dashboard.helpStep2'),
        t('dashboard.helpStep3'),
        t('dashboard.helpStep4')
      ],
      tips: [
        t('dashboard.helpTip1'),
        t('dashboard.helpTip2')
      ]
    },
    community: {
      title: t('community.title'),
      description: "Share posts, engage in discussions, and connect with the community",
      steps: [
        "Browse community discussions by category",
        "Join conversations that interest you",
        "Create new discussion topics",
        "Use the search to find specific topics"
      ],
      tips: [
        "Categories help organize discussions",
        "Be respectful in community interactions"
      ]
    },
    profileWall: {
      title: "Profile Wall",
      description: "Share posts, photos, videos and connect with your social network",
      steps: [
        "Click 'Edit Cover' to customize your profile header image",
        "Use 'Edit Profile' to update your name, bio, and location",
        "Post updates by typing in the text box and clicking 'Post'",
        "Add photos or videos to posts using the Photo/Video buttons",
        "Use existing gallery system to organize your media in albums",
        "Connect social media accounts for multi-platform sharing",
        "Like, comment, and share posts from your network"
      ],
      tips: [
        "Gallery system already supports album creation and photo organization",
        "Multi-Share lets you post to multiple social platforms at once",
        "Cover photo and profile image can be cropped and positioned",
        "Posts can include text, photos, videos, and links"
      ]
    },
    locationAds: {
      title: "Business Directory",
      description: "Discover businesses worldwide with contact details and direct website access",
      steps: [
        "Select a country from the dropdown menu",
        "Choose a specific city or leave as 'All Countries' for broader search",
        "Click 'Search Businesses' to find local services",
        "Browse business cards showing company details and services",
        "Click any business card to view full profile with contact information",
        "Use 'Call', 'Email', 'Website', or 'Get Directions' buttons for direct contact",
        "Perfect for travelers seeking local services or residents finding nearby businesses"
      ],
      tips: [
        "Business directory covers restaurants, shops, services, and professional businesses",
        "Each business shows location, contact details, and website links",
        "Tap anywhere on business cards to access full company profiles",
        "Great for finding quality services when traveling or in new areas"
      ]
    }
  };

  const currentPageData = pageData[currentPage] || pageData.dashboard;

  return (
    <>
      <button
        className="bg-white border border-gray-300 hover:bg-gray-50 rounded px-2 py-1 text-[10px] font-bold cursor-pointer"
        onClick={() => setIsOpen(true)}
        style={{
          pointerEvents: 'auto',
          cursor: 'pointer',
          zIndex: 9999,
          position: 'relative'
        }}
      >
        Instructions
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/20" onClick={() => setIsOpen(false)} />
          <div className="bg-white border border-gray-200 shadow-lg rounded-lg max-w-lg w-full relative z-[10000] max-h-[90vh] overflow-y-auto p-6"
               data-dialog-content="true">
            <div className="mb-4">
              <h2 className="flex items-center gap-2 text-lg font-semibold">
                <BookOpen className="w-5 h-5" />
                {currentPageData.title} - Instructions
              </h2>
            </div>
            
            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                {currentPageData.description}
              </p>
              
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <ChevronRight className="w-4 h-4" />
                  How to use this page:
                </h4>
                <ol className="space-y-2 text-sm">
                  {currentPageData.steps.map((step: string, index: number) => (
                    <li key={index} className="flex gap-2">
                      <span className="bg-gray-100 text-gray-700 text-xs px-1.5 py-0.5 rounded min-w-[20px] text-center font-medium">
                        {index + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
              
              {currentPageData.tips && (
                <div>
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <Brain className="w-4 h-4" />
                    Tips:
                  </h4>
                  <ul className="space-y-1 text-sm">
                    {currentPageData.tips.map((tip: string, index: number) => (
                      <li key={index} className="flex gap-2">
                        <span className="text-blue-500">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            
            <div className="flex justify-end mt-6">
              <Button 
                onClick={() => setIsOpen(false)}
                variant="outline"
                size="sm"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}