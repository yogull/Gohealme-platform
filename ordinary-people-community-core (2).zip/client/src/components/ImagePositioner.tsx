import { useState, useRef, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

interface ImagePositionerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  imageUrl: string;
  onPositionSave: (position: { x: number; y: number; scale: number }) => void;
}

export default function ImagePositioner({ 
  open, 
  onOpenChange, 
  imageUrl, 
  onPositionSave 
}: ImagePositionerProps) {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [scale, setScale] = useState([1]);
  const [isDragging, setIsDragging] = useState(false);
  const imageRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    setIsDragging(true);
    e.preventDefault();
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging || !containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100 - 50;
    const y = ((e.clientY - rect.top) / rect.height) * 100 - 50;
    
    setPosition({ 
      x: Math.max(-50, Math.min(50, x)), 
      y: Math.max(-50, Math.min(50, y)) 
    });
  }, [isDragging]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleSave = () => {
    onPositionSave({ x: position.x, y: position.y, scale: scale[0] });
    onOpenChange(false);
  };

  const handleReset = () => {
    setPosition({ x: 0, y: 0 });
    setScale([1]);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Position Your Cover Image</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Image Preview Container */}
          <div 
            ref={containerRef}
            className="relative w-full h-32 bg-gray-100 rounded-lg overflow-hidden cursor-move border-2 border-dashed border-gray-300"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          >
            <img
              ref={imageRef}
              src={imageUrl}
              alt="Cover preview"
              className="absolute w-full h-full object-cover transition-transform duration-150"
              style={{
                transform: `translate(${position.x}%, ${position.y}%) scale(${scale[0]})`,
                transformOrigin: 'center center'
              }}
              draggable={false}
            />
            
            {/* Overlay instructions */}
            <div className="absolute top-2 left-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
              Drag to position
            </div>
          </div>

          {/* Scale Control */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Zoom: {scale[0].toFixed(1)}x</label>
            <Slider
              value={scale}
              onValueChange={setScale}
              max={2}
              min={0.5}
              step={0.1}
              className="w-full"
            />
          </div>

          {/* Position Display */}
          <div className="text-xs text-gray-500 text-center">
            Position: X: {position.x.toFixed(0)}%, Y: {position.y.toFixed(0)}%
          </div>

          {/* Action Buttons */}
          <div className="flex justify-between gap-2">
            <Button 
              variant="outline" 
              onClick={handleReset}
              className="flex-1"
            >
              Reset
            </Button>
            <Button 
              onClick={handleSave}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              Save Position
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}