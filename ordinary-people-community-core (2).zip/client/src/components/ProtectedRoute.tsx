import { useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { getCurrentAppUser } from '@/lib/auth';
import type { User } from '@shared/schema';
import { Loader2, Leaf } from 'lucide-react';

interface ProtectedRouteProps {
  children: (user: User) => React.ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const [appUser, setAppUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userData = await getCurrentAppUser(firebaseUser.uid);
          if (userData) {
            setAppUser(userData);
            localStorage.setItem('auth_user', JSON.stringify(userData));
          } else {
            // User not found in database, redirect to login
            localStorage.removeItem('auth_user');
            window.location.href = '/login';
            return;
          }
        } catch (error) {
          console.error('Error fetching user:', error);
          localStorage.removeItem('auth_user');
          window.location.href = '/login';
          return;
        }
      } else {
        // No Firebase user, redirect to login
        localStorage.removeItem('auth_user');
        window.location.href = '/login';
        return;
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center mx-auto mb-4">
            <Leaf className="text-white text-2xl" size={24} />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Ordinary People Community</h2>
          <div className="flex items-center justify-center space-x-2">
            <Loader2 className="animate-spin text-primary" size={20} />
            <span className="text-gray-600">Verifying access...</span>
          </div>
        </div>
      </div>
    );
  }

  if (!appUser) {
    // This should not happen due to redirects above, but safety fallback
    window.location.href = '/login';
    return null;
  }

  return <>{children(appUser)}</>;
}