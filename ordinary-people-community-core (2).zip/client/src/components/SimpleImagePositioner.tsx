import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface SimpleImagePositionerProps {
  onImageCropped: (croppedImageData: string) => void;
  onCancel: () => void;
  aspectRatio?: number;
  cropShape?: 'round' | 'rect';
}

export default function SimpleImagePositioner({
  onImageCropped,
  onCancel,
  aspectRatio = 1,
  cropShape = 'rect'
}: SimpleImagePositionerProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [cropPosition, setCropPosition] = useState({ x: 50, y: 50 });
  const [cropSize, setCropSize] = useState({ width: 200, height: 200 });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const { toast } = useToast();

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({ title: "Invalid File", description: "Please select an image file" });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setSelectedImage(result);
      // Set initial crop size based on aspect ratio
      const height = 200;
      const width = height * aspectRatio;
      setCropSize({ width, height });
    };
    reader.readAsDataURL(file);
  };

  const handleCrop = async () => {
    if (!selectedImage || !imageRef.current || !canvasRef.current) {
      toast({ title: "Error", description: "No image selected" });
      return;
    }

    try {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      const img = imageRef.current;

      if (!ctx) {
        toast({ title: "Error", description: "Canvas not supported" });
        return;
      }

      // Calculate actual crop dimensions based on image size
      const scaleX = img.naturalWidth / img.offsetWidth;
      const scaleY = img.naturalHeight / img.offsetHeight;
      
      const actualCropX = cropPosition.x * scaleX;
      const actualCropY = cropPosition.y * scaleY;
      const actualCropWidth = cropSize.width * scaleX;
      const actualCropHeight = cropSize.height * scaleY;

      // Set canvas size to crop size
      canvas.width = cropSize.width;
      canvas.height = cropSize.height;

      // Draw the cropped image
      ctx.drawImage(
        img,
        actualCropX,
        actualCropY,
        actualCropWidth,
        actualCropHeight,
        0,
        0,
        cropSize.width,
        cropSize.height
      );

      // If round crop, apply circular mask
      if (cropShape === 'round') {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const radius = Math.min(centerX, centerY);

        for (let y = 0; y < canvas.height; y++) {
          for (let x = 0; x < canvas.width; x++) {
            const distance = Math.sqrt((x - centerX) ** 2 + (y - centerY) ** 2);
            if (distance > radius) {
              const index = (y * canvas.width + x) * 4;
              data[index + 3] = 0; // Set alpha to 0 (transparent)
            }
          }
        }
        ctx.putImageData(imageData, 0, 0);
      }

      const croppedImageData = canvas.toDataURL('image/png');
      onImageCropped(croppedImageData);
    } catch (error) {
      console.error('Error cropping image:', error);
      toast({ title: "Error", description: "Failed to crop image" });
    }
  };

  const moveCrop = (deltaX: number, deltaY: number) => {
    if (!imageRef.current) return;
    
    const maxX = imageRef.current.offsetWidth - cropSize.width;
    const maxY = imageRef.current.offsetHeight - cropSize.height;
    
    setCropPosition(prev => ({
      x: Math.max(0, Math.min(maxX, prev.x + deltaX)),
      y: Math.max(0, Math.min(maxY, prev.y + deltaY))
    }));
  };

  const resizeCrop = (delta: number) => {
    const newHeight = Math.max(50, Math.min(300, cropSize.height + delta));
    const newWidth = newHeight * aspectRatio;
    setCropSize({ width: newWidth, height: newHeight });
  };

  return (
    <div className="space-y-4">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />
      
      {!selectedImage ? (
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
          <Button onClick={triggerFileSelect} className="mb-4 bg-blue-600 hover:bg-blue-700">
            Select Image
          </Button>
          <p className="text-gray-500">Choose an image to crop</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="relative border border-gray-300 inline-block max-w-full">
            <img
              ref={imageRef}
              src={selectedImage}
              alt="Image to crop"
              className="max-w-full max-h-96 block"
            />
            
            {/* Crop overlay */}
            <div
              className={`absolute border-2 border-blue-500 bg-blue-500 bg-opacity-20 ${cropShape === 'round' ? 'rounded-full' : ''}`}
              style={{
                left: cropPosition.x,
                top: cropPosition.y,
                width: cropSize.width,
                height: cropSize.height
              }}
            >
              <div className="absolute top-1 left-1 bg-white text-black text-xs px-1 rounded">
                Crop Area
              </div>
            </div>
          </div>

          {/* Position Controls */}
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium block mb-2">Position</label>
              <div className="grid grid-cols-3 gap-2">
                <Button onClick={() => moveCrop(-10, -10)} variant="outline" size="sm">↖</Button>
                <Button onClick={() => moveCrop(0, -10)} variant="outline" size="sm">↑</Button>
                <Button onClick={() => moveCrop(10, -10)} variant="outline" size="sm">↗</Button>
                <Button onClick={() => moveCrop(-10, 0)} variant="outline" size="sm">←</Button>
                <Button onClick={() => setCropPosition({ x: 50, y: 50 })} variant="outline" size="sm">⌂</Button>
                <Button onClick={() => moveCrop(10, 0)} variant="outline" size="sm">→</Button>
                <Button onClick={() => moveCrop(-10, 10)} variant="outline" size="sm">↙</Button>
                <Button onClick={() => moveCrop(0, 10)} variant="outline" size="sm">↓</Button>
                <Button onClick={() => moveCrop(10, 10)} variant="outline" size="sm">↘</Button>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium block mb-2">Size</label>
              <div className="flex gap-2">
                <Button onClick={() => resizeCrop(-20)} variant="outline" size="sm">Smaller</Button>
                <Button onClick={() => setCropSize({ width: 200 * aspectRatio, height: 200 })} variant="outline" size="sm">Reset</Button>
                <Button onClick={() => resizeCrop(20)} variant="outline" size="sm">Larger</Button>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4">
            <Button onClick={triggerFileSelect} variant="outline" className="flex-1">
              Select Different Image
            </Button>
            <Button onClick={onCancel} variant="outline" className="flex-1">
              Cancel
            </Button>
            <Button onClick={handleCrop} className="flex-1 bg-green-600 hover:bg-green-700">
              Crop & Save
            </Button>
          </div>
        </div>
      )}
      
      {/* Hidden canvas for cropping */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}