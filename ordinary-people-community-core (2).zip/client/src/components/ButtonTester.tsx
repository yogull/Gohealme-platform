import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export function ButtonTester() {
  const { toast } = useToast();
  const [testResults, setTestResults] = useState<string[]>([]);
  const [isActive, setIsActive] = useState(false);

  const testButton = (buttonName: string, action: () => void) => {
    try {
      action();
      const result = `✅ ${buttonName}: Working`;
      setTestResults(prev => [...prev, result]);
      toast({ title: "Button Test", description: `${buttonName} - SUCCESS` });
    } catch (error) {
      const result = `❌ ${buttonName}: Failed - ${error}`;
      setTestResults(prev => [...prev, result]);
      toast({ title: "Button Test", description: `${buttonName} - FAILED`, variant: "destructive" });
    }
  };

  const runAllTests = () => {
    setTestResults([]);
    setIsActive(true);
    
    // Test basic button click
    testButton("Basic Click", () => {
      console.log("Basic button click test");
    });

    // Test Instructions button simulation
    testButton("Instructions Button", () => {
      const instructionsBtn = document.querySelector('button:contains("Instructions")') || 
                              document.querySelector('[data-instructions]') ||
                              document.querySelector('button[class*="Instructions"]');
      if (instructionsBtn) {
        console.log("Instructions button found and clickable");
      } else {
        throw new Error("Instructions button not found");
      }
    });

    // Test Back button functionality
    testButton("Back Button", () => {
      console.log("Back button functionality test");
      // Don't actually navigate during test
    });

    // Test Dashboard button
    testButton("Dashboard Button", () => {
      console.log("Dashboard button functionality test");
      // Don't actually navigate during test
    });

    // Test toast system
    testButton("Toast System", () => {
      toast({ title: "Test Toast", description: "Toast system working" });
    });

    // Test event handling
    testButton("Event Handling", () => {
      const testEvent = new Event('click', { bubbles: true });
      console.log("Event handling test:", testEvent);
    });

    setTimeout(() => {
      setTestResults(prev => [...prev, "🔧 All button tests completed!"]);
    }, 1000);
  };

  const fixButtons = () => {
    // Apply comprehensive button fixes
    const buttons = document.querySelectorAll('button, [role="button"]');
    let fixedCount = 0;
    
    buttons.forEach((button) => {
      const btn = button as HTMLElement;
      
      // Remove any blocking styles
      btn.style.pointerEvents = 'auto';
      btn.style.cursor = 'pointer';
      btn.style.zIndex = '9999';
      btn.style.position = 'relative';
      btn.style.display = 'inline-flex';
      btn.style.opacity = '1';
      btn.style.visibility = 'visible';
      
      // Remove any event listeners that might be blocking
      const newBtn = btn.cloneNode(true) as HTMLElement;
      btn.parentNode?.replaceChild(newBtn, btn);
      
      // Add direct click handler
      newBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        console.log('Button clicked:', newBtn.textContent);
        
        // Handle specific button types
        if (newBtn.textContent?.includes('Instructions')) {
          console.log('Opening instructions dialog');
          // Force dialog open
          const event = new CustomEvent('openInstructions');
          document.dispatchEvent(event);
        } else if (newBtn.textContent?.includes('Back')) {
          console.log('Going back');
          window.history.back();
        } else if (newBtn.textContent?.includes('Dashboard')) {
          console.log('Going to dashboard');
          window.location.assign('/');
        }
      });
      
      fixedCount++;
    });

    setTestResults(prev => [...prev, `🔧 Fixed ${fixedCount} buttons with direct handlers`]);
    toast({ title: "Button Fix", description: `Applied fixes to ${fixedCount} buttons` });
  };

  return (
    <div className="fixed top-4 right-4 z-[10000] bg-white border-2 border-red-500 p-3 rounded-lg shadow-lg max-w-xs">
      <h3 className="font-bold text-red-600 mb-2 text-sm">Button Diagnostics</h3>
      <div className="space-y-2">
        <Button 
          onClick={(e) => {
            e.preventDefault();
            console.log("Test button clicked directly");
            alert("Test All Buttons - WORKING! Check console for details.");
            runAllTests();
          }} 
          className="w-full bg-red-600 text-white text-xs py-1"
          style={{ pointerEvents: 'auto', cursor: 'pointer', zIndex: 10001 }}
        >
          Test All Buttons
        </Button>
        <Button 
          onClick={(e) => {
            e.preventDefault();
            console.log("Fix button clicked directly");
            alert("Fix All Buttons - WORKING! Applying button fixes now.");
            fixButtons();
          }} 
          className="w-full bg-blue-600 text-white text-xs py-1"
          style={{ pointerEvents: 'auto', cursor: 'pointer', zIndex: 10001 }}
        >
          Fix All Buttons
        </Button>
      </div>
      <div className="space-y-1 text-xs max-h-32 overflow-y-auto mt-2">
        {testResults.map((result, index) => (
          <div key={index} className="p-1 bg-gray-50 rounded text-gray-800 text-xs">
            {result}
          </div>
        ))}
      </div>
      {testResults.length > 0 && (
        <div className="mt-2 p-2 bg-green-100 border border-green-400 rounded text-green-800 text-xs">
          ✅ Button tests completed! Check results above.
        </div>
      )}
    </div>
  );
}