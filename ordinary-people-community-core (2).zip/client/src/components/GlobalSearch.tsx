import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, User, Pill, MessageCircle, X } from "lucide-react";
import { Link } from "wouter";
import type { User as UserType, Supplement, CommunityDiscussion } from "@shared/schema";

interface SearchResults {
  users: UserType[];
  supplements: Supplement[];
  discussions: CommunityDiscussion[];
}

interface GlobalSearchProps {
  isOpen: boolean;
  onClose: () => void;
  onOpen: () => void;
}

export function GlobalSearch({ isOpen, onClose, onOpen }: GlobalSearchProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery.trim());
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const { data: searchResults, isLoading } = useQuery<SearchResults>({
    queryKey: ["/api/global-search", debouncedQuery],
    enabled: debouncedQuery.length > 2,
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/global-search?q=${encodeURIComponent(debouncedQuery)}`);
      return response.json();
    },
  });

  const handleSearch = () => {
    if (searchQuery.trim()) {
      onOpen();
    }
  };

  const clearSearch = () => {
    setSearchQuery("");
    setDebouncedQuery("");
    onClose();
  };

  return (
    <>
      {/* Search Input in Header */}
      <div className="relative flex-1 max-w-md mx-4">
        <div className="relative">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleSearch}
            className="absolute left-1 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0 z-10 hover:bg-gray-100"
            aria-label="Search"
          >
            <Search className="h-4 w-4 text-gray-400 hover:text-gray-600" />
          </Button>
          <Input
            placeholder="Search users, supplements, discussions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => searchQuery.trim() && onOpen()}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            className="pl-10 pr-10"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearSearch}
              className="absolute right-1 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
            >
              <X className="h-3 w-3" />
            </Button>
          )}
        </div>
      </div>

      {/* Search Results Modal */}
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Search Results for "{debouncedQuery}"
            </DialogTitle>
          </DialogHeader>

          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
            </div>
          )}

          {searchResults && !isLoading && (
            <div className="space-y-6">
              {/* Users Results */}
              {searchResults.users.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Users ({searchResults.users.length})
                  </h3>
                  <div className="grid gap-3">
                    {searchResults.users.map((user) => (
                      <Card key={user.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-10 w-10">
                              <AvatarFallback>{user.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <Link href="/social" onClick={onClose}>
                                <h4 className="font-medium hover:text-primary cursor-pointer">
                                  {user.name}
                                </h4>
                              </Link>
                              {user.email && (
                                <p className="text-sm text-gray-600">{user.email}</p>
                              )}
                              <div className="flex gap-2 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  User
                                </Badge>
                                {user.isAdmin && (
                                  <Badge variant="secondary" className="text-xs">
                                    Admin
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Supplements Results */}
              {searchResults.supplements.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <Pill className="h-5 w-5" />
                    Supplements ({searchResults.supplements.length})
                  </h3>
                  <div className="grid gap-3">
                    {searchResults.supplements.map((supplement) => (
                      <Card key={supplement.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start space-x-3">
                            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                              <Pill className="h-6 w-6 text-white" />
                            </div>
                            <div className="flex-1">
                              <Link href="/supplements" onClick={onClose}>
                                <h4 className="font-medium hover:text-primary cursor-pointer">
                                  {supplement.name}
                                </h4>
                              </Link>
                              <p className="text-sm text-gray-600 mt-1">
                                {supplement.dosage} • {supplement.frequency}
                              </p>
                              {supplement.notes && (
                                <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                                  {supplement.notes}
                                </p>
                              )}
                              <div className="flex gap-2 mt-2">
                                <Badge variant="outline" className="text-xs">
                                  Supplement
                                </Badge>
                                <Badge variant="secondary" className="text-xs">
                                  {supplement.timeOfDay}
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Discussions Results */}
              {searchResults.discussions.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    Discussions ({searchResults.discussions.length})
                  </h3>
                  <div className="grid gap-3">
                    {searchResults.discussions.map((discussion) => (
                      <Card key={discussion.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start space-x-3">
                            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-green-500 to-blue-600 flex items-center justify-center">
                              <MessageCircle className="h-6 w-6 text-white" />
                            </div>
                            <div className="flex-1">
                              <Link href="/community" onClick={onClose}>
                                <h4 className="font-medium hover:text-primary cursor-pointer">
                                  {discussion.title}
                                </h4>
                              </Link>
                              <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                                {discussion.description}
                              </p>
                              <div className="flex gap-2 mt-2">
                                <Badge variant="outline" className="text-xs">
                                  Discussion
                                </Badge>
                                {discussion.location && (
                                  <Badge variant="secondary" className="text-xs">
                                    📍 {discussion.location}
                                  </Badge>
                                )}
                                <Badge variant="outline" className="text-xs">
                                  👥 {discussion.participantCount} participants
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                  💬 {discussion.messageCount} messages
                                </Badge>
                              </div>
                              {discussion.tags && discussion.tags.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {discussion.tags.slice(0, 3).map((tag, index) => (
                                    <Badge key={index} variant="outline" className="text-xs">
                                      #{tag}
                                    </Badge>
                                  ))}
                                  {discussion.tags.length > 3 && (
                                    <Badge variant="outline" className="text-xs">
                                      +{discussion.tags.length - 3} more
                                    </Badge>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* No Results */}
              {searchResults && 
               searchResults.users.length === 0 && 
               searchResults.supplements.length === 0 && 
               searchResults.discussions.length === 0 && (
                <div className="text-center py-8">
                  <Search className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No results found</h3>
                  <p className="text-gray-500">
                    Try searching for users, supplements, or discussion topics with different keywords.
                  </p>
                </div>
              )}
            </div>
          )}

          {debouncedQuery.length <= 2 && debouncedQuery.length > 0 && (
            <div className="text-center py-8">
              <Search className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500">Type at least 3 characters to search</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}