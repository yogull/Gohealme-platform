import React, { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Camera, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { auth } from '@/lib/firebase';

interface SimpleImageUploadProps {
  onImageUploaded: (imageUrl: string) => void;
  buttonText?: string;
  isProfileImage?: boolean;
  className?: string;
}

export function SimpleImageUpload({ 
  onImageUploaded, 
  buttonText = "Upload Image", 
  isProfileImage = false,
  className = ""
}: SimpleImageUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      // Check file type
      if (!file.type.startsWith('image/')) {
        toast({ title: "Please select an image file", variant: "destructive" });
        return;
      }

      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({ title: "File too large. Please select an image under 5MB", variant: "destructive" });
        return;
      }

      // Get current user
      const firebaseUser = auth.currentUser;
      if (!firebaseUser) {
        toast({ title: "Please login first", variant: "destructive" });
        return;
      }

      // Show loading state
      toast({ title: "Uploading image...", description: "Please wait while we process your image" });

      // Convert to Base64
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64Data = reader.result as string;
          
          // Get Firebase ID token for authentication
          const idToken = await firebaseUser.getIdToken();
          
          // Get user ID from Firebase
          const userResponse = await fetch(`/api/users/firebase/${firebaseUser.uid}`, {
            headers: {
              'Authorization': `Bearer ${idToken}`
            }
          });
          
          if (!userResponse.ok) {
            throw new Error('Failed to authenticate user');
          }
          
          const userData = await userResponse.json();

          // Upload to backend with authentication
          const uploadResponse = await fetch('/api/files/upload', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${idToken}`
            },
            body: JSON.stringify({
              fileName: `${isProfileImage ? 'profile' : 'image'}_${userData.id}_${Date.now()}.jpg`,
              fileType: file.type,
              fileData: base64Data,
              userId: userData.id.toString(),
              galleryName: isProfileImage ? 'profile' : 'general'
            })
          });

          if (!uploadResponse.ok) {
            const errorText = await uploadResponse.text();
            console.error('Upload response error:', errorText);
            throw new Error(`Upload failed: ${uploadResponse.status}`);
          }

          const result = await uploadResponse.json();
          console.log('Upload successful:', result);
          
          // Return the file URL for display
          const imageUrl = result.url || base64Data;
          onImageUploaded(imageUrl);
          
          toast({ 
            title: "Image uploaded successfully!", 
            description: `${isProfileImage ? 'Profile image' : 'Image'} added to gallery`
          });

        } catch (error) {
          console.error('Upload error:', error);
          toast({ 
            title: "Upload failed", 
            description: error instanceof Error ? error.message : "Please try again",
            variant: "destructive" 
          });
        }
      };

      reader.onerror = () => {
        toast({ 
          title: "File reading failed", 
          description: "Could not read the selected file",
          variant: "destructive" 
        });
      };

      reader.readAsDataURL(file);

    } catch (error) {
      console.error('File processing error:', error);
      toast({ title: "Failed to process image", variant: "destructive" });
    }

    // Clear the input
    if (event.target) {
      event.target.value = '';
    }
  };

  return (
    <>
      <Button
        onClick={handleFileSelect}
        className={className}
        variant={isProfileImage ? "default" : "outline"}
      >
        {isProfileImage ? (
          <Camera className="h-4 w-4" />
        ) : (
          <>
            <Upload className="h-4 w-4 mr-2" />
            {buttonText}
          </>
        )}
      </Button>
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        style={{ display: 'none' }}
      />
    </>
  );
}