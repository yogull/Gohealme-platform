import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Home } from 'lucide-react';
import { useLocation } from 'wouter';

interface UniversalBackButtonProps {
  className?: string;
  showDashboard?: boolean;
}

export function UniversalBackButton({ className = "", showDashboard = true }: UniversalBackButtonProps) {
  const [, setLocation] = useLocation();

  const handleBack = () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      setLocation('/dashboard');
    }
  };

  return (
    <div className={`flex gap-2 mb-4 ${className}`}>
      <Button 
        variant="outline" 
        size="sm" 
        className="flex items-center gap-2"
        onClick={handleBack}
      >
        <ArrowLeft className="h-4 w-4" />
        Back
      </Button>
      
      {showDashboard && (
        <Button 
          variant="outline" 
          size="sm" 
          className="flex items-center gap-2"
          onClick={() => setLocation('/dashboard')}
        >
          <Home className="h-4 w-4" />
          Dashboard
        </Button>
      )}
    </div>
  );
}