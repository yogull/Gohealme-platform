import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Share2, Facebook, Twitter, Instagram, Linkedin, Youtube, X } from "lucide-react";

interface SocialMediaDiscoveryPopupProps {
  userId: number;
  hasConnectedSocial: boolean;
}

export function SocialMediaDiscoveryPopup({ userId, hasConnectedSocial }: SocialMediaDiscoveryPopupProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [hasShown, setHasShown] = useState(false);

  useEffect(() => {
    // Show popup immediately if user hasn't connected social media and hasn't seen popup before
    const hasSeenPopup = localStorage.getItem(`social-discovery-popup-${userId}`);
    
    if (!hasConnectedSocial && !hasSeenPopup && !hasShown) {
      // No timeout - show immediately when conditions are met
      setIsOpen(true);
      setHasShown(true);
      localStorage.setItem(`social-discovery-popup-${userId}`, 'true');
    }
  }, [userId, hasConnectedSocial, hasShown]);

  const handleConnectNow = () => {
    setIsOpen(false);
    // Scroll to social media section
    const element = document.querySelector('.social-media-links');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      // Trigger edit mode after scroll
      const editButton = element.querySelector('button') as HTMLButtonElement;
      if (editButton) editButton.click();
    }
  };

  if (hasConnectedSocial) return null;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="max-w-md mx-auto bg-gradient-to-br from-blue-50 to-purple-50">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-bold text-blue-900 flex items-center gap-2">
              <Share2 className="w-6 h-6" />
              Unlock Multi-Share Power!
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="text-center">
            <div className="flex justify-center gap-2 mb-3">
              <Facebook className="w-8 h-8 text-blue-600" />
              <Twitter className="w-8 h-8 text-blue-400" />
              <Instagram className="w-8 h-8 text-pink-500" />
              <Linkedin className="w-8 h-8 text-blue-700" />
              <Youtube className="w-8 h-8 text-red-600" />
            </div>
            <h3 className="font-bold text-lg text-gray-900 mb-2">
              🚀 Ready for the Marketing Revolution?
            </h3>
            <p className="text-sm text-gray-700 mb-4">
              Connect your social media accounts to unlock OPC's Multi-Share system. 
              Post once and automatically share to ALL platforms simultaneously!
            </p>
          </div>

          <div className="bg-white p-4 rounded-lg border-2 border-blue-200">
            <h4 className="font-semibold text-blue-900 mb-2">💥 What You Get:</h4>
            <ul className="text-sm space-y-1 text-gray-700">
              <li>✅ Post to Facebook, Twitter, Instagram, LinkedIn & YouTube at once</li>
              <li>✅ Reach connected users' audiences (even without being friends)</li>
              <li>✅ Custom messages for each platform</li>
              <li>✅ Exponential viral growth potential</li>
            </ul>
          </div>

          <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
            <p className="text-xs text-yellow-800 text-center">
              <strong>Found in:</strong> Profile Wall → Social Media Connections → "Connect & Resize Cards"
            </p>
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={handleConnectNow}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              🔗 Connect Now
            </Button>
            <Button 
              onClick={() => setIsOpen(false)}
              variant="outline"
              className="flex-1"
            >
              Maybe Later
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}