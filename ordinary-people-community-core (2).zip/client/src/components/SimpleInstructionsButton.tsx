import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { X, BookOpen } from "lucide-react";

interface SimpleInstructionsButtonProps {
  currentPage?: string;
}

export function SimpleInstructionsButton({ currentPage = "dashboard" }: SimpleInstructionsButtonProps) {
  const [showModal, setShowModal] = useState(false);

  const pageInstructions = {
    dashboard: {
      title: "Dashboard Instructions",
      steps: [
        "View your community overview and health metrics",
        "Access quick links to different platform features", 
        "Check notifications and recent activity",
        "Use the navigation menu to explore other sections"
      ]
    },
    community: {
      title: "Community Instructions", 
      steps: [
        "Browse discussions by category",
        "Create new posts to share with the community",
        "Join conversations that interest you",
        "Use search to find specific topics"
      ]
    }
  };

  const currentInstructions = pageInstructions[currentPage as keyof typeof pageInstructions] || pageInstructions.dashboard;

  if (!showModal) {
    return (
      <Button
        onClick={() => setShowModal(true)}
        variant="outline"
        size="sm"
        className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 bg-white border-gray-300 hover:bg-gray-50 w-20 px-1 py-1 text-[10px] font-bold whitespace-nowrap"
      >
        Instructions
      </Button>
    );
  }

  return (
    <>
      {/* Button */}
      <Button
        onClick={() => setShowModal(true)}
        variant="outline"
        size="sm"
        className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 bg-white border-gray-300 hover:bg-gray-50 w-20 px-1 py-1 text-[10px] font-bold whitespace-nowrap"
      >
        Instructions
      </Button>

      {/* Modal Overlay */}
      <div className="fixed inset-0 z-[9999] bg-black/20 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl max-w-lg w-full max-h-[80vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              <h2 className="text-lg font-semibold">{currentInstructions.title}</h2>
            </div>
            <Button
              onClick={() => setShowModal(false)}
              variant="ghost"
              size="sm"
              className="p-1"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Content */}
          <div className="p-4 space-y-4">
            <p className="text-sm text-gray-600">
              Follow these steps to use this page effectively:
            </p>
            
            <ol className="space-y-3">
              {currentInstructions.steps.map((step, index) => (
                <li key={index} className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center text-xs font-medium">
                    {index + 1}
                  </span>
                  <span className="text-sm">{step}</span>
                </li>
              ))}
            </ol>
          </div>

          {/* Footer */}
          <div className="flex justify-end p-4 border-t">
            <Button
              onClick={() => setShowModal(false)}
              variant="outline"
              size="sm"
            >
              Close
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}