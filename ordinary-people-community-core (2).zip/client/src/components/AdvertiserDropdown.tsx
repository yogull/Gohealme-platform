import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Store, ChevronDown } from "lucide-react";

interface Company {
  id: number;
  name: string;
  description: string;
  location: string;
  website?: string;
  ownerId: number;
}

export function AdvertiserDropdown() {
  const [selectedAdvertiser, setSelectedAdvertiser] = useState<string>("");

  const { data: companies } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const activeAdvertisers = companies?.filter(company => 
    company.name && company.description
  ) || [];

  const handleAdvertiserSelect = (companyId: string) => {
    if (companyId && companyId !== "placeholder") {
      window.location.href = `/shop/company/${companyId}`;
    }
  };

  if (activeAdvertisers.length === 0) {
    return null;
  }

  return (
    <div className="w-full max-w-xs mx-auto mb-4">
      <Select onValueChange={handleAdvertiserSelect}>
        <SelectTrigger className="w-full bg-gradient-to-r from-purple-100 to-pink-100 border-purple-300 hover:from-purple-200 hover:to-pink-200 transition-colors">
          <div className="flex items-center gap-2">
            <Store className="h-4 w-4 text-purple-600" />
            <SelectValue placeholder="🛍️ Browse Advertiser Shops" />
          </div>
        </SelectTrigger>
        <SelectContent className="max-w-xs">
          <SelectItem value="placeholder" disabled className="text-gray-500">
            Select an advertiser to visit their shop
          </SelectItem>
          {activeAdvertisers.map((company) => (
            <SelectItem key={company.id} value={company.id.toString()}>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <span className="font-medium">{company.name}</span>
                <span className="text-xs text-gray-500">({company.location})</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      
      {activeAdvertisers.length > 0 && (
        <p className="text-xs text-center text-gray-600 mt-2">
          {activeAdvertisers.length} local businesses advertising • Click to shop
        </p>
      )}
    </div>
  );
}