import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Upload, Video, X, Play, Pause } from "lucide-react";

interface VideoUploadProps {
  onUpload: (files: File[]) => void;
  maxFiles?: number;
  maxSizeMB?: number;
  className?: string;
  clearAfterUpload?: boolean;
}

export function VideoUpload({ 
  onUpload, 
  maxFiles = 5, 
  maxSizeMB = 100,
  className = "",
  clearAfterUpload = false
}: VideoUploadProps) {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [captions, setCaptions] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    // Validate file types
    const videoFiles = files.filter(file => file.type.startsWith('video/'));
    if (videoFiles.length !== files.length) {
      toast({
        title: "Invalid File Type",
        description: "Please select only video files (MP4, WebM, MOV, etc.)",
        variant: "destructive",
      });
      return;
    }

    // Validate file sizes
    const oversizedFiles = videoFiles.filter(file => file.size > maxSizeMB * 1024 * 1024);
    if (oversizedFiles.length > 0) {
      toast({
        title: "File Too Large",
        description: `Maximum file size is ${maxSizeMB}MB. Please select smaller files.`,
        variant: "destructive",
      });
      return;
    }

    // Validate number of files
    if (selectedFiles.length + videoFiles.length > maxFiles) {
      toast({
        title: "Too Many Files",
        description: `Maximum ${maxFiles} videos allowed.`,
        variant: "destructive",
      });
      return;
    }

    // Create preview URLs
    const newPreviews = videoFiles.map(file => URL.createObjectURL(file));
    const newCaptions = videoFiles.map(() => "");

    setSelectedFiles(prev => [...prev, ...videoFiles]);
    setPreviews(prev => [...prev, ...newPreviews]);
    setCaptions(prev => [...prev, ...newCaptions]);
  };

  const removeFile = (index: number) => {
    // Revoke the object URL to prevent memory leaks
    URL.revokeObjectURL(previews[index]);
    
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
    setPreviews(prev => prev.filter((_, i) => i !== index));
    setCaptions(prev => prev.filter((_, i) => i !== index));
  };

  const updateCaption = (index: number, caption: string) => {
    setCaptions(prev => prev.map((c, i) => i === index ? caption : c));
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      toast({
        title: "No Files Selected",
        description: "Please select at least one video to upload.",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      // Simulate upload progress
      for (let i = 0; i <= 100; i += 10) {
        setUploadProgress(i);
        await new Promise(resolve => setTimeout(resolve, 50));
      }

      // Call the upload handler
      onUpload(selectedFiles);

      // Clear files if requested
      if (clearAfterUpload) {
        setSelectedFiles([]);
        setPreviews(prev => {
          prev.forEach(url => URL.revokeObjectURL(url));
          return [];
        });
        setCaptions([]);
        
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }

      toast({
        title: "Upload Successful",
        description: `${selectedFiles.length} video(s) uploaded successfully.`,
      });
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "There was an error uploading your videos. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className={`space-y-4 ${className}`}>
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors">
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          multiple
          onChange={handleFileSelect}
          className="hidden"
          disabled={uploading}
        />
        
        <Video className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <div className="space-y-2">
          <p className="text-lg font-medium">Upload Videos</p>
          <p className="text-sm text-gray-500">
            Drag and drop or click to select video files
          </p>
          <p className="text-xs text-gray-400">
            Maximum {maxFiles} files, up to {maxSizeMB}MB each
          </p>
        </div>
        
        <Button
          type="button"
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading || selectedFiles.length >= maxFiles}
          className="mt-4"
        >
          <Upload className="w-4 h-4 mr-2" />
          Select Videos
        </Button>
      </div>

      {selectedFiles.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-medium">Selected Videos ({selectedFiles.length})</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {selectedFiles.map((file, index) => (
              <Card key={index} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="relative">
                      <video
                        src={previews[index]}
                        className="w-full h-32 object-cover rounded"
                        controls
                        preload="metadata"
                      />
                      <Button
                        size="sm"
                        variant="destructive"
                        className="absolute top-2 right-2"
                        onClick={() => removeFile(index)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-sm font-medium truncate">{file.name}</p>
                      <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                      
                      <div>
                        <Label htmlFor={`caption-${index}`} className="text-xs">
                          Caption (optional)
                        </Label>
                        <Textarea
                          id={`caption-${index}`}
                          placeholder="Add a caption for this video..."
                          value={captions[index]}
                          onChange={(e) => updateCaption(index, e.target.value)}
                          className="mt-1 text-sm"
                          rows={2}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {uploading && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Uploading videos...</span>
                <span>{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="w-full" />
            </div>
          )}

          <div className="flex gap-2">
            <Button
              onClick={handleUpload}
              disabled={uploading}
              className="flex-1"
            >
              {uploading ? 'Uploading...' : `Upload ${selectedFiles.length} Video(s)`}
            </Button>
            
            <Button
              variant="outline"
              onClick={() => {
                setSelectedFiles([]);
                setPreviews(prev => {
                  prev.forEach(url => URL.revokeObjectURL(url));
                  return [];
                });
                setCaptions([]);
                if (fileInputRef.current) {
                  fileInputRef.current.value = '';
                }
              }}
              disabled={uploading}
            >
              Clear All
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}