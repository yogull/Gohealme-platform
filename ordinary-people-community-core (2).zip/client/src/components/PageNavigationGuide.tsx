import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Home, MessageCircle, Users, Building2, Settings, 
  HelpCircle, Search, Plus, Heart, ArrowLeft,
  Smartphone, Monitor, Navigation
} from "lucide-react";

const pageGuides = {
  "dashboard": {
    title: "Dashboard - Your Home Base",
    icon: <Home className="w-5 h-5" />,
    description: "Overview of your health journey and community activity",
    features: [
      "View your supplement tracking progress",
      "See recent community activity and notifications", 
      "Access quick actions for logging supplements",
      "Browse featured health content and discussions",
      "Navigate to any section of the platform"
    ],
    navigation: [
      "Use top navigation to access main sections",
      "Click 'Log Supplement' for daily tracking",
      "Scroll down to see community features",
      "Use sidebar (desktop) or menu (mobile) for all options"
    ]
  },
  "community": {
    title: "Community Discussions",
    icon: <MessageCircle className="w-5 h-5" />,
    description: "Join conversations on health, government, and personal topics",
    features: [
      "Browse discussion categories (Health, Government, Personal)",
      "Start new discussions on any topic",
      "Reply to existing conversations",
      "Like and share posts you find helpful",
      "Connect with like-minded community members"
    ],
    navigation: [
      "Select category from main page or dropdown",
      "Click 'Join Discussion' to participate",
      "Use back button to return to category list",
      "Search discussions by topic or keyword"
    ]
  },
  "chat": {
    title: "Chat & AI Assistant",
    icon: <MessageCircle className="w-5 h-5" />,
    description: "Private messaging and AI health guidance",
    features: [
      "Chat privately with other community members",
      "Get health advice from AI Health Assistant",
      "Ask questions about supplements and conditions",
      "Share experiences and get support",
      "Receive notifications for new messages"
    ],
    navigation: [
      "Click 'New Chat' to start conversation",
      "Search users to message community members",
      "AI Assistant available for health questions",
      "Use back button to return to chat list"
    ]
  },
  "profile": {
    title: "Profile Wall & Social",
    icon: <Users className="w-5 h-5" />,
    description: "Your personal space and social connections",
    features: [
      "Upload photos and videos to your gallery",
      "Share posts about your health journey",
      "Connect with other community members",
      "Edit your profile information and bio",
      "View and manage your social connections"
    ],
    navigation: [
      "Click 'Edit Profile' to update information",
      "Use 'Add Photos' or 'Add Video' for uploads",
      "Post updates to share with community",
      "Connect with users you find interesting"
    ]
  },
  "business": {
    title: "Business Directory",
    icon: <Building2 className="w-5 h-5" />,
    description: "Discover local businesses and health services",
    features: [
      "Search businesses by location (country/city)",
      "Browse featured advertisements",
      "Visit business websites and get contact info",
      "View business locations on map",
      "Support community businesses"
    ],
    navigation: [
      "Select country first, then choose city",
      "Click 'Search' to find businesses",
      "Tap business cards to visit websites",
      "Use 'Map' button for directions"
    ]
  },
  "admin": {
    title: "Admin Panel (John Proctor Only)",
    icon: <Settings className="w-5 h-5" />,
    description: "Manage platform content and community features",
    features: [
      "Manage RSS feeds and automated posting",
      "Create and organize discussion categories",
      "Moderate user content and discussions",
      "Manage business listings and advertisements",
      "View platform analytics and reports"
    ],
    navigation: [
      "Access via sidebar 'Admin' option",
      "Use tabs to switch between admin functions",
      "Always use back buttons to return to previous page",
      "Changes save automatically"
    ]
  }
};

const mobileGuide = {
  title: "Mobile Navigation Tips",
  tips: [
    "Tap the menu button (☰) in top-right for full navigation",
    "Swipe left/right on cards to see more content",
    "Use back button in top-left to return to previous page",
    "Pinch to zoom on images and content",
    "Pull down to refresh any page"
  ]
};

export function PageNavigationGuide() {
  const [selectedPage, setSelectedPage] = useState("dashboard");

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <HelpCircle className="w-4 h-4" />
          How to Use
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Navigation className="w-5 h-5 text-green-600" />
            Complete User Guide - Ordinary People Community
          </DialogTitle>
        </DialogHeader>

        <Tabs value={selectedPage} onValueChange={setSelectedPage} className="mt-4">
          <TabsList className="grid grid-cols-3 lg:grid-cols-6 gap-1">
            {Object.entries(pageGuides).map(([key, page]) => (
              <TabsTrigger key={key} value={key} className="text-xs flex flex-col gap-1 h-auto p-2">
                {page.icon}
                <span className="hidden sm:inline">{page.title.split(' ')[0]}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {Object.entries(pageGuides).map(([key, page]) => (
            <TabsContent key={key} value={key} className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    {page.icon}
                    {page.title}
                  </CardTitle>
                  <p className="text-gray-600">{page.description}</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      What You Can Do
                    </h4>
                    <ul className="space-y-2">
                      {page.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <Heart className="w-4 h-4 text-pink-600 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <ArrowLeft className="w-4 h-4" />
                      How to Navigate
                    </h4>
                    <ol className="space-y-2">
                      {page.navigation.map((step, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <Badge variant="outline" className="text-xs min-w-6 h-6 flex items-center justify-center">
                            {index + 1}
                          </Badge>
                          <span className="text-sm">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}

          <TabsContent value="mobile" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Smartphone className="w-5 h-5" />
                  {mobileGuide.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {mobileGuide.tips.map((tip, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Badge variant="outline" className="text-xs min-w-6 h-6 flex items-center justify-center">
                        {index + 1}
                      </Badge>
                      <span className="text-sm">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
          <h4 className="font-semibold text-green-900 mb-2 flex items-center gap-2">
            <Monitor className="w-4 h-4" />
            Universal Navigation Rules
          </h4>
          <ul className="text-sm text-green-800 space-y-1">
            <li>• Every page has a back button to return to the previous page</li>
            <li>• Use the sidebar (desktop) or menu button (mobile) to jump to any section</li>
            <li>• All buttons are clearly labeled with what they do</li>
            <li>• Your progress and data are saved automatically</li>
          </ul>
        </div>

        <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <h4 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
            <Search className="w-4 h-4" />
            Need More Help?
          </h4>
          <p className="text-sm text-blue-800">
            Each page also has its own "How to Use This Page" button for specific guidance.
            Contact us at ordinarypeoplecommunity.com@gmail.com for additional support.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}