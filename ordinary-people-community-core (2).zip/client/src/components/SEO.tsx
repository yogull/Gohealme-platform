import { useEffect } from 'react';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string[];
  image?: string;
  url?: string;
  type?: 'website' | 'article' | 'profile';
  publishedTime?: string;
  modifiedTime?: string;
  author?: string;
  section?: string;
}

export function SEO({
  title = "Ordinary People Community",
  description = "Join Ordinary People Community - A platform for open discussions on government topics, personal views, and health advice. Connect with real people and share experiences away from the elites.",
  keywords = [
    'ordinary people community', 'government discussions', 'personal views platform', 
    'health advice community', 'open discussions', 'away from elites',
    'people community', 'government topics', 'personal opinions',
    'health discussions', 'community platform', 'real people', 'ordinary citizens',
    'government views', 'health advice', 'community discussions',
    'personal experiences', 'open forum', 'people platform'
  ],
  image = 'https://gohealme.org/gohealme-logo.jpg',
  url = 'https://gohealme.org',
  type = 'website',
  publishedTime,
  modifiedTime,
  author = 'GoHealMe Team',
  section = 'Health & Wellness'
}: SEOProps) {
  
  useEffect(() => {
    // Update document title
    document.title = title;

    // Create or update meta tags
    const updateMetaTag = (name: string, content: string, property?: boolean) => {
      const attribute = property ? 'property' : 'name';
      let meta = document.querySelector(`meta[${attribute}="${name}"]`);
      
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attribute, name);
        document.head.appendChild(meta);
      }
      
      meta.setAttribute('content', content);
    };

    // Basic meta tags
    updateMetaTag('description', description);
    updateMetaTag('keywords', Array.isArray(keywords) ? keywords.join(', ') : (keywords || ''));
    updateMetaTag('author', author);
    updateMetaTag('robots', 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1');
    updateMetaTag('googlebot', 'index, follow');
    updateMetaTag('viewport', 'width=device-width, initial-scale=1.0');
    
    // Open Graph tags
    updateMetaTag('og:title', title, true);
    updateMetaTag('og:description', description, true);
    updateMetaTag('og:image', image, true);
    updateMetaTag('og:url', url, true);
    updateMetaTag('og:type', type, true);
    updateMetaTag('og:site_name', 'Ordinary People Community', true);
    updateMetaTag('og:locale', 'en_GB', true);
    
    // Twitter Card tags
    updateMetaTag('twitter:card', 'summary_large_image');
    updateMetaTag('twitter:title', title);
    updateMetaTag('twitter:description', description);
    updateMetaTag('twitter:image', image);
    updateMetaTag('twitter:site', '@ordinarypeople');
    updateMetaTag('twitter:creator', '@ordinarypeople');
    
    // Article specific tags
    if (type === 'article') {
      if (publishedTime) updateMetaTag('article:published_time', publishedTime, true);
      if (modifiedTime) updateMetaTag('article:modified_time', modifiedTime, true);
      if (author) updateMetaTag('article:author', author, true);
      if (section) updateMetaTag('article:section', section, true);
      
      if (Array.isArray(keywords)) {
        keywords.forEach(keyword => {
          const tagMeta = document.createElement('meta');
          tagMeta.setAttribute('property', 'article:tag');
          tagMeta.setAttribute('content', keyword);
          document.head.appendChild(tagMeta);
        });
      }
    }

    // Community discussion specific tags
    updateMetaTag('community:category', section || 'Community Discussions');
    updateMetaTag('community:specialty', 'Government Topics, Personal Views, Health Advice, Open Discussions');
    
    // Mobile optimization
    updateMetaTag('mobile-web-app-capable', 'yes');
    updateMetaTag('apple-mobile-web-app-capable', 'yes');
    updateMetaTag('apple-mobile-web-app-status-bar-style', 'black-translucent');
    updateMetaTag('apple-mobile-web-app-title', 'Ordinary People Community');
    
    // Additional SEO tags
    updateMetaTag('theme-color', '#ec4899');
    updateMetaTag('msapplication-TileColor', '#ec4899');
    updateMetaTag('application-name', 'Ordinary People Community');
    
    // Canonical URL
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', url);

    // Add JSON-LD structured data
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "GoHealMe",
      "description": description,
      "url": "https://gohealme.org",
      "logo": "https://gohealme.org/gohealme-logo.jpg",
      "sameAs": [
        "https://facebook.com/gohealme",
        "https://twitter.com/gohealme",
        "https://instagram.com/gohealme"
      ],
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://gohealme.org/search?q={search_term_string}",
        "query-input": "required name=search_term_string"
      },
      "mainEntity": {
        "@type": "HealthAndBeautyBusiness",
        "name": "GoHealMe",
        "description": "The People's Health Community - Supplement tracking, AI health guidance, and wellness support",
        "url": "https://gohealme.org",
        "logo": "https://gohealme.org/gohealme-logo.jpg",
        "contactPoint": {
          "@type": "ContactPoint",
          "email": "gohealme.org@gmail.com",
          "contactType": "customer service"
        },
        "serviceType": [
          "Health Tracking",
          "Supplement Management", 
          "Wellness Community",
          "AI Health Assistance",
          "Biometric Monitoring"
        ]
      }
    };

    // Remove existing structured data
    const existingStructuredData = document.querySelector('script[type="application/ld+json"]');
    if (existingStructuredData) {
      existingStructuredData.remove();
    }

    // Add new structured data
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(structuredData);
    document.head.appendChild(script);

  }, [title, description, keywords, image, url, type, publishedTime, modifiedTime, author, section]);

  return null;
}