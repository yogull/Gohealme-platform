// Stable Button Component - Prevents recurring button functionality issues
interface StableButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  variant?: 'primary' | 'secondary' | 'ghost' | 'outline';
  size?: 'sm' | 'default' | 'lg';
}

export function StableButton({ 
  onClick, 
  children, 
  className = '', 
  style = {}, 
  variant = 'primary',
  size = 'default'
}: StableButtonProps) {
  const baseStyles: React.CSSProperties = {
    cursor: 'pointer',
    border: 'none',
    borderRadius: '6px',
    fontWeight: '500',
    transition: 'all 0.2s',
    pointerEvents: 'auto',
    zIndex: 1000,
    ...style
  };

  const variantStyles = {
    primary: { backgroundColor: '#3b82f6', color: 'white', padding: '8px 16px' },
    secondary: { backgroundColor: '#f3f4f6', color: '#374151', padding: '8px 16px' },
    ghost: { backgroundColor: 'transparent', color: '#374151', padding: '4px 8px' },
    outline: { backgroundColor: 'transparent', color: '#374151', border: '1px solid #d1d5db', padding: '8px 16px' }
  };

  const sizeStyles = {
    sm: { fontSize: '14px', padding: '4px 12px' },
    default: { fontSize: '16px', padding: '8px 16px' },
    lg: { fontSize: '18px', padding: '12px 24px' }
  };

  const finalStyles = {
    ...baseStyles,
    ...variantStyles[variant],
    ...sizeStyles[size]
  };

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onClick();
  };

  return (
    <button
      style={finalStyles}
      className={className}
      onClick={handleClick}
      type="button"
    >
      {children}
    </button>
  );
}