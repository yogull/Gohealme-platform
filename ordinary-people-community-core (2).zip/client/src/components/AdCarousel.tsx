import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, MapPin } from "lucide-react";

interface Advertisement {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
  targetUrl?: string;
  targetLocation?: string;
  targetScope: string;
  impressions: number;
  clicks: number;
}

interface AdCarouselProps {
  location?: string;
  scope: "local" | "national";
  categoryId?: number;
  userId?: number;
  position: "left" | "right";
}

export function AdCarousel({ location, scope, categoryId, userId, position }: AdCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [impressionTracked, setImpressionTracked] = useState<Set<number>>(new Set());
  const [isMobile, setIsMobile] = useState(() => {
    // Initialize with proper mobile check on first render
    if (typeof window !== 'undefined') {
      return window.innerWidth <= 1024;
    }
    return false;
  });

  // Check for mobile on mount and resize
  useEffect(() => {
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth <= 1024);
    };
    
    checkIsMobile();
    window.addEventListener('resize', checkIsMobile);
    
    return () => window.removeEventListener('resize', checkIsMobile);
  }, []);

  const { data: advertisements = [], isLoading } = useQuery({
    queryKey: ["/api/advertisements", location, scope],
    queryFn: async () => {
      const params = new URLSearchParams({
        scope,
        limit: "5"
      });
      
      if (location) {
        params.append("location", location);
      }

      const response = await fetch(`/api/advertisements?${params}`);
      if (!response.ok) throw new Error("Failed to fetch advertisements");
      return response.json();
    },
    enabled: !isMobile // Don't fetch data on mobile
  });

  // Auto-rotate carousel every 8 seconds
  useEffect(() => {
    if (!isMobile && advertisements.length > 1) {
      const interval = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % advertisements.length);
      }, 8000);
      return () => clearInterval(interval);
    }
  }, [advertisements.length, isMobile]);

  // Track impressions only once per session to reduce database load
  useEffect(() => {
    if (!isMobile && advertisements.length > 0) {
      const currentAd = advertisements[currentIndex];
      const sessionKey = `ad_impression_${currentAd.id}_${Date.now().toString().slice(0, -5)}`;
      
      if (currentAd && !impressionTracked.has(currentAd.id) && !sessionStorage.getItem(sessionKey)) {
        recordImpression(currentAd.id);
        setImpressionTracked(prev => new Set(prev).add(currentAd.id));
        sessionStorage.setItem(sessionKey, "tracked");
      }
    }
  }, [currentIndex, advertisements, impressionTracked, isMobile]);

  const recordImpression = async (adId: number) => {
    try {
      // Only record impression if user has been viewing for at least 2 seconds
      setTimeout(async () => {
        await fetch(`/api/advertisements/${adId}/impression`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId,
            userLocation: location,
            discussionCategoryId: categoryId
          })
        });
      }, 2000);
    } catch (error) {
      console.error("Failed to record impression:", error);
    }
  };

  const recordClick = async (adId: number, targetUrl?: string) => {
    try {
      await fetch(`/api/advertisements/${adId}/click`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          userLocation: location,
          discussionCategoryId: categoryId
        })
      });

      if (targetUrl) {
        window.open(targetUrl, "_blank", "noopener,noreferrer");
      }
    } catch (error) {
      console.error("Failed to record click:", error);
    }
  };

  // Don't render on mobile to prevent overlay issues
  if (isMobile) {
    return null;
  }

  if (isLoading) {
    return (
      <div className={`w-48 ${position === "left" ? "mr-4" : "ml-4"}`}>
        <Card className="p-4 animate-pulse">
          <div className="h-32 bg-gray-200 rounded mb-2"></div>
          <div className="h-4 bg-gray-200 rounded mb-1"></div>
          <div className="h-3 bg-gray-200 rounded w-3/4"></div>
        </Card>
      </div>
    );
  }

  if (!advertisements.length) {
    return null;
  }

  const currentAd = advertisements[currentIndex];

  return (
    <div className={`w-48 ${position === "left" ? "mr-4" : "ml-4"} fixed ${position === "left" ? "left-2" : "right-2"} top-32 z-10 hidden lg:block`}>
      <Card className="p-3 shadow-lg border-2 hover:shadow-xl transition-shadow cursor-pointer bg-white/95 backdrop-blur-sm">
        <div className="flex items-center justify-between mb-2">
          <Badge variant={scope === "local" ? "default" : "secondary"} className="text-xs">
            {scope === "local" ? (
              <><MapPin className="w-3 h-3 mr-1" />{location}</>
            ) : (
              "National"
            )}
          </Badge>
          <span className="text-xs text-gray-500">Ad</span>
        </div>

        <div 
          onClick={() => recordClick(currentAd.id, currentAd.targetUrl)}
          className="space-y-2"
        >
          {currentAd.imageUrl && (
            <div className="w-full h-24 rounded overflow-hidden">
              <img 
                src={currentAd.imageUrl} 
                alt={currentAd.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          <div>
            <h4 className="font-semibold text-sm text-gray-900 line-clamp-2">
              {currentAd.title}
            </h4>
            <p className="text-xs text-gray-600 mt-1 line-clamp-3">
              {currentAd.description}
            </p>
          </div>

          {currentAd.targetUrl && (
            <div className="flex items-center text-blue-600 text-xs mt-2">
              <ExternalLink className="w-3 h-3 mr-1" />
              <span>Learn More</span>
            </div>
          )}
        </div>

        {/* Carousel indicators */}
        {advertisements.length > 1 && (
          <div className="flex justify-center mt-2 space-x-1">
            {advertisements.map((ad: any, index: number) => (
              <button
                key={ad.id}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentIndex ? "bg-blue-600" : "bg-gray-300"
                }`}
              />
            ))}
          </div>
        )}

        {/* Performance indicators for admins */}
        {userId === 4 && ( // John Proctor admin check
          <div className="text-xs text-gray-500 mt-2 border-t pt-2">
            Views: {currentAd.impressions} | Clicks: {currentAd.clicks}
          </div>
        )}
      </Card>
    </div>
  );
}