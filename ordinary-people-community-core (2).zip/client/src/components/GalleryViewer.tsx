import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { 
  X, ChevronLeft, ChevronRight, Heart, MessageCircle, Share2, 
  Send, MoreHorizontal, Trash2, Edit3, Play, Pause, Volume2, VolumeX 
} from 'lucide-react';

interface GalleryItem {
  id: number;
  caption?: string;
  likes: number;
  shares: number;
  views: number;
  createdAt: string;
  file: {
    id: number;
    mimeType: string;
    fileData: string;
    originalName: string;
  };
}

interface Comment {
  id: number;
  comment: string;
  likes: number;
  createdAt: string;
  user: {
    id: number;
    name: string;
  };
}

interface GalleryViewerProps {
  isOpen: boolean;
  onClose: () => void;
  galleryId: number;
  initialItemId?: number;
  currentUserId: number;
}

export default function GalleryViewer({ 
  isOpen, 
  onClose, 
  galleryId, 
  initialItemId, 
  currentUserId 
}: GalleryViewerProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Fetch gallery items
  const { data: galleryItems = [], isLoading } = useQuery({
    queryKey: ['/api/galleries', galleryId, 'items'],
    queryFn: async () => {
      const response = await fetch(`/api/galleries/${galleryId}/items`);
      if (!response.ok) throw new Error('Failed to fetch gallery items');
      return response.json();
    },
    enabled: isOpen && !!galleryId
  });

  // Find initial item index
  useEffect(() => {
    if (initialItemId && galleryItems.length > 0) {
      const index = galleryItems.findIndex((item: GalleryItem) => item.id === initialItemId);
      if (index !== -1) {
        setCurrentItemIndex(index);
      }
    }
  }, [initialItemId, galleryItems]);

  const currentItem = galleryItems[currentItemIndex];

  // Fetch comments for current item
  const { data: comments = [] } = useQuery({
    queryKey: ['/api/gallery-items', currentItem?.id, 'comments'],
    queryFn: async () => {
      const response = await fetch(`/api/gallery-items/${currentItem.id}/comments`);
      if (!response.ok) throw new Error('Failed to fetch comments');
      return response.json();
    },
    enabled: !!currentItem && showComments
  });

  // Increment views when item changes
  useEffect(() => {
    if (currentItem) {
      fetch(`/api/gallery-items/${currentItem.id}/view`, { method: 'POST' });
    }
  }, [currentItem]);

  // Toggle like mutation
  const likeMutation = useMutation({
    mutationFn: async (itemId: number) => {
      const response = await fetch(`/api/gallery-items/${itemId}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUserId })
      });
      if (!response.ok) throw new Error('Failed to toggle like');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/galleries', galleryId, 'items'] });
    }
  });

  // Add comment mutation
  const commentMutation = useMutation({
    mutationFn: async ({ itemId, comment }: { itemId: number; comment: string }) => {
      const response = await fetch(`/api/gallery-items/${itemId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUserId, comment })
      });
      if (!response.ok) throw new Error('Failed to add comment');
      return response.json();
    },
    onSuccess: () => {
      setNewComment('');
      queryClient.invalidateQueries({ queryKey: ['/api/gallery-items', currentItem.id, 'comments'] });
    }
  });

  // Share mutation
  const shareMutation = useMutation({
    mutationFn: async (itemId: number) => {
      const response = await fetch(`/api/gallery-items/${itemId}/share`, {
        method: 'POST'
      });
      if (!response.ok) throw new Error('Failed to record share');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/galleries', galleryId, 'items'] });
    }
  });

  const navigateToItem = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && currentItemIndex > 0) {
      setCurrentItemIndex(currentItemIndex - 1);
    } else if (direction === 'next' && currentItemIndex < galleryItems.length - 1) {
      setCurrentItemIndex(currentItemIndex + 1);
    }
  };

  const handleLike = () => {
    if (currentItem) {
      likeMutation.mutate(currentItem.id);
    }
  };

  const handleShare = () => {
    if (currentItem) {
      shareMutation.mutate(currentItem.id);
      if (navigator.share) {
        navigator.share({
          title: `Check out this ${currentItem.file.mimeType.startsWith('video') ? 'video' : 'image'}`,
          text: currentItem.caption || 'Shared from gallery',
          url: window.location.href
        });
      } else {
        navigator.clipboard.writeText(window.location.href);
        toast({
          title: "Link Copied",
          description: "Gallery item link copied to clipboard"
        });
      }
    }
  };

  const handleAddComment = () => {
    if (newComment.trim() && currentItem) {
      commentMutation.mutate({ itemId: currentItem.id, comment: newComment.trim() });
    }
  };

  const toggleVideoPlayback = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  if (!isOpen || !currentItem) return null;

  const isVideo = currentItem.file.mimeType.startsWith('video');
  const fileUrl = `data:${currentItem.file.mimeType};base64,${currentItem.file.fileData}`;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] sm:max-w-7xl max-h-[95vh] p-0 bg-black">
        <div className="relative h-full flex flex-col sm:flex-row">
          {/* Close button */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 z-50 text-white hover:bg-white/20"
            onClick={onClose}
          >
            <X className="h-6 w-6" />
          </Button>

          {/* Navigation buttons */}
          {currentItemIndex > 0 && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute left-4 top-1/2 -translate-y-1/2 z-50 text-white hover:bg-white/20"
              onClick={() => navigateToItem('prev')}
            >
              <ChevronLeft className="h-8 w-8" />
            </Button>
          )}
          
          {currentItemIndex < galleryItems.length - 1 && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-4 top-1/2 -translate-y-1/2 z-50 text-white hover:bg-white/20"
              onClick={() => navigateToItem('next')}
            >
              <ChevronRight className="h-8 w-8" />
            </Button>
          )}

          {/* Main content area */}
          <div className="flex-1 flex items-center justify-center relative">
            {isVideo ? (
              <div className="relative max-w-full max-h-full">
                <video
                  ref={videoRef}
                  src={fileUrl}
                  className="max-w-full max-h-[80vh] object-contain"
                  controls={false}
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                />
                
                {/* Video controls overlay */}
                <div className="absolute bottom-4 left-4 flex space-x-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-white hover:bg-white/20"
                    onClick={toggleVideoPlayback}
                  >
                    {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-white hover:bg-white/20"
                    onClick={toggleMute}
                  >
                    {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                  </Button>
                </div>
              </div>
            ) : (
              <img
                src={fileUrl}
                alt={currentItem.caption || currentItem.file.originalName}
                className="max-w-full max-h-[80vh] object-contain"
              />
            )}

            {/* Item info overlay */}
            <div className="absolute bottom-4 left-4 right-4 text-white">
              <div className="bg-black/50 rounded-lg p-4">
                {currentItem.caption && (
                  <p className="text-sm mb-2">{currentItem.caption}</p>
                )}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-xs text-gray-300">
                    <span>{currentItemIndex + 1} of {galleryItems.length}</span>
                    <span>{currentItem.views} views</span>
                    <span>{new Date(currentItem.createdAt).toLocaleDateString()}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-white hover:bg-white/20"
                      onClick={handleLike}
                      disabled={likeMutation.isPending}
                    >
                      <Heart className="h-4 w-4 mr-1" />
                      {currentItem.likes}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-white hover:bg-white/20"
                      onClick={() => setShowComments(!showComments)}
                    >
                      <MessageCircle className="h-4 w-4 mr-1" />
                      {comments.length}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-white hover:bg-white/20"
                      onClick={handleShare}
                      disabled={shareMutation.isPending}
                    >
                      <Share2 className="h-4 w-4 mr-1" />
                      {currentItem.shares}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Comments sidebar */}
          {showComments && (
            <div className="w-full sm:w-80 bg-white border-l sm:border-l border-t sm:border-t-0 flex flex-col max-h-[50vh] sm:max-h-full">
              <div className="p-4 border-b">
                <h3 className="font-semibold">Comments</h3>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {comments.map((comment: Comment) => (
                  <div key={comment.id} className="text-sm">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">{comment.user.name}</span>
                      <span className="text-xs text-gray-500">
                        {new Date(comment.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-gray-700">{comment.comment}</p>
                    {comment.likes > 0 && (
                      <div className="flex items-center mt-1 text-xs text-gray-500">
                        <Heart className="h-3 w-3 mr-1" />
                        {comment.likes}
                      </div>
                    )}
                  </div>
                ))}
                
                {comments.length === 0 && (
                  <p className="text-gray-500 text-center py-8">
                    No comments yet. Be the first to comment!
                  </p>
                )}
              </div>
              
              <div className="p-4 border-t">
                <div className="flex space-x-2">
                  <Textarea
                    placeholder="Add a comment..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    rows={2}
                    className="flex-1"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && e.ctrlKey) {
                        handleAddComment();
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    onClick={handleAddComment}
                    disabled={!newComment.trim() || commentMutation.isPending}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Press Ctrl+Enter to post
                </p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}