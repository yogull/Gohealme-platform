import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MapPin, Search, Building2, Phone, Mail, Globe, Eye } from 'lucide-react';

interface Advertisement {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  targetUrl: string;
  targetLocation: string;
  targetScope: string;
  impressions: number;
  clicks: number;
  advertiserName: string;
  companyName?: string;
  isFeatured?: boolean;
}

const UK_CITIES = [
  "London", "Manchester", "Birmingham", "Glasgow", "Liverpool", 
  "Leeds", "Sheffield", "Edinburgh", "Bristol", "Cardiff", 
  "Leicester", "Nottingham", "Newcastle", "Belfast", "Brighton"
];

export default function LocationAdBrowser() {
  const [showFeatured, setShowFeatured] = useState(true);
  const [selectedLocation, setSelectedLocation] = useState<string>('');
  const [searchLocation, setSearchLocation] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);

  // Filter cities based on search input
  const filteredCities = UK_CITIES.filter(city =>
    city.toLowerCase().includes(searchLocation.toLowerCase())
  );

  // Fetch featured ads
  const { data: featuredAds = [], isLoading: featuredLoading } = useQuery({
    queryKey: ['/api/companies/featured'],
    enabled: showFeatured
  });

  // Fetch location-based ads
  const { data: locationAds = [], isLoading: locationLoading } = useQuery({
    queryKey: ['/api/companies', selectedLocation],
    enabled: !showFeatured && !!selectedLocation
  });

  const ads = (showFeatured ? featuredAds : locationAds) as Advertisement[];
  const isLoading = showFeatured ? featuredLoading : locationLoading;

  const handleLocationSelect = (city: string) => {
    setSelectedLocation(city);
    setSearchLocation(city);
    setShowDropdown(false);
  };

  const handleSearchClick = () => {
    if (searchLocation.trim()) {
      setSelectedLocation(searchLocation.trim());
      setShowFeatured(false);
    }
  };

  const handleAdClick = async (ad: Advertisement) => {
    // Track click and open business profile
    try {
      await fetch('/api/companies/track-click', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adId: ad.id })
      });
      
      if (ad.targetUrl) {
        window.open(ad.targetUrl, '_blank');
      }
    } catch (error) {
      console.error('Failed to track ad click:', error);
    }
  };

  const handleBusinessProfile = (ad: Advertisement) => {
    // Navigate to business profile page
    window.location.href = `/business-profile/${ad.id}`;
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      {/* Toggle Header */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Business Directory</h1>
        <div className="flex gap-2">
          <Button
            variant={showFeatured ? "default" : "outline"}
            onClick={() => setShowFeatured(true)}
            className="flex items-center gap-2"
          >
            <Eye className="w-4 h-4" />
            Featured
          </Button>
          <Button
            variant={!showFeatured ? "default" : "outline"}
            onClick={() => setShowFeatured(false)}
            className="flex items-center gap-2"
          >
            <MapPin className="w-4 h-4" />
            By Location
          </Button>
        </div>
      </div>

      {/* Featured Ads */}
      {showFeatured && (
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Featured Businesses
              </CardTitle>
              <CardDescription>
                Premium businesses advertising across the platform
              </CardDescription>
            </CardHeader>
            <CardContent>
              {featuredLoading ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">Loading featured businesses...</p>
                </div>
              ) : ads.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {ads.map((ad: Advertisement) => (
                    <div
                      key={ad.id}
                      className="bg-white p-4 rounded-lg shadow-sm border hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => handleAdClick(ad)}
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                          {ad.companyName?.[0] || ad.advertiserName[0]}
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-800 line-clamp-1">
                            {ad.companyName || ad.title}
                          </h3>
                          <p className="text-sm text-gray-500">{ad.targetLocation}</p>
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                        {ad.description}
                      </p>

                      <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                        <span>{ad.impressions.toLocaleString()} views</span>
                        <span>{ad.clicks} clicks</span>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="flex-1 bg-blue-600 hover:bg-blue-700"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAdClick(ad);
                          }}
                        >
                          <Globe className="w-4 h-4 mr-1" />
                          Visit
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleBusinessProfile(ad);
                          }}
                        >
                          <Building2 className="w-4 h-4 mr-1" />
                          Profile
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">No featured businesses available</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Location Search */}
      {!showFeatured && (
        <div className="space-y-4">
          {/* Search Interface */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                Search Businesses by Location
              </CardTitle>
              <CardDescription>
                Enter a UK city name to find local businesses
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    type="text"
                    placeholder="Enter city name (e.g., London, Manchester, Birmingham)"
                    value={searchLocation}
                    onChange={(e) => {
                      setSearchLocation(e.target.value);
                      setShowDropdown(e.target.value.length > 0);
                    }}
                    onFocus={() => setShowDropdown(searchLocation.length > 0)}
                  />
                  {showDropdown && filteredCities.length > 0 && (
                    <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-md shadow-lg z-50 max-h-48 overflow-y-auto">
                      {filteredCities.slice(0, 8).map((city) => (
                        <div
                          key={city}
                          className="p-2 hover:bg-gray-100 cursor-pointer border-b border-gray-100 last:border-b-0"
                          onClick={() => handleLocationSelect(city)}
                        >
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4" />
                            {city}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <Button onClick={handleSearchClick}>
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </Button>
              </div>

              {/* Quick City Selection */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Or select from popular cities:
                </label>
                <Select onValueChange={handleLocationSelect}>
                  <SelectTrigger className="bg-white border-gray-200">
                    <SelectValue placeholder="Choose a city" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border border-gray-200 shadow-lg z-50">
                    {UK_CITIES.map((city) => (
                      <SelectItem key={city} value={city} className="hover:bg-gray-100">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          {city}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Search Results */}
          {selectedLocation && (
            <Card>
              <CardHeader>
                <CardTitle>Businesses in {selectedLocation}</CardTitle>
                <CardDescription>
                  Local businesses advertising in your area
                </CardDescription>
              </CardHeader>
              <CardContent>
                {locationLoading ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Searching for businesses in {selectedLocation}...</p>
                  </div>
                ) : ads.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {ads.map((ad: Advertisement) => (
                      <div
                        key={ad.id}
                        className="bg-white p-4 rounded-lg shadow-sm border hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => handleAdClick(ad)}
                      >
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                            {ad.companyName?.[0] || ad.advertiserName[0]}
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-800 line-clamp-1">
                              {ad.companyName || ad.title}
                            </h3>
                            <p className="text-sm text-gray-500">{ad.targetLocation}</p>
                          </div>
                        </div>
                        
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                          {ad.description}
                        </p>

                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            className="flex-1 bg-green-600 hover:bg-green-700"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAdClick(ad);
                            }}
                          >
                            <Globe className="w-4 h-4 mr-1" />
                            Visit
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleBusinessProfile(ad);
                            }}
                          >
                            <Building2 className="w-4 h-4 mr-1" />
                            Profile
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No businesses found in {selectedLocation}</p>
                    <p className="text-sm text-gray-400 mt-2">
                      Try searching for a different city or check featured businesses
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}