import React, { useState } from 'react';
import { Share2, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface UniversalShareSystemProps {
  content: string;
  title?: string;
  url?: string;
  type?: 'post' | 'comment' | 'blog' | 'discussion' | 'general';
  className?: string;
  variant?: 'button' | 'icon' | 'text';
}

export function UniversalShareSystem({ 
  content, 
  title = "Check this out!", 
  url = window.location.href,
  type = 'general',
  className = "",
  variant = 'button'
}: UniversalShareSystemProps) {
  const [isSharing, setIsSharing] = useState(false);
  const { toast } = useToast();

  // All 26+ platforms with proper sharing URLs
  const allPlatforms = [
    // Primary social media
    { name: 'Facebook', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}` },
    { name: 'Twitter', url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(content)}&url=${encodeURIComponent(url)}` },
    { name: 'LinkedIn', url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}` },
    { name: 'WhatsApp', url: `https://wa.me/?text=${encodeURIComponent(content + ' ' + url)}` },
    { name: 'Instagram', url: `https://www.instagram.com/` },
    
    // Messaging platforms
    { name: 'Telegram', url: `https://telegram.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(content)}` },
    { name: 'Discord', url: `https://discord.com/channels/@me` },
    { name: 'Snapchat', url: `https://www.snapchat.com/` },
    { name: 'Skype', url: `https://web.skype.com/share?url=${encodeURIComponent(url)}` },
    
    // Content platforms
    { name: 'Pinterest', url: `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(url)}&description=${encodeURIComponent(content)}` },
    { name: 'Reddit', url: `https://reddit.com/submit?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}` },
    { name: 'Tumblr', url: `https://tumblr.com/widgets/share/tool?canonicalUrl=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}` },
    { name: 'Medium', url: `https://medium.com/new-story` },
    
    // Video platforms
    { name: 'TikTok', url: `https://www.tiktok.com/` },
    { name: 'YouTube', url: `https://www.youtube.com/` },
    { name: 'Twitch', url: `https://www.twitch.tv/` },
    { name: 'Vimeo', url: `https://vimeo.com/` },
    
    // Professional/Tech platforms
    { name: 'GitHub', url: `https://github.com/` },
    { name: 'Stack Overflow', url: `https://stackoverflow.com/` },
    { name: 'Quora', url: `https://www.quora.com/` },
    { name: 'DeviantArt', url: `https://www.deviantart.com/` },
    { name: 'Behance', url: `https://www.behance.net/` },
    { name: 'Dribbble', url: `https://dribbble.com/` },
    
    // Audio platforms
    { name: 'Spotify', url: `https://open.spotify.com/` },
    { name: 'SoundCloud', url: `https://soundcloud.com/` },
    
    // Photo platforms
    { name: 'Flickr', url: `https://www.flickr.com/` },
    
    // Additional platforms
    { name: 'VKontakte', url: `https://vk.com/share.php?url=${encodeURIComponent(url)}` }
  ];

  const handleQuickShare = (e?: React.MouseEvent) => {
    console.log('🚀 EMERGENCY SHARE HANDLER - Direct activation');
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    setIsSharing(true);
    
    try {
      // Emergency direct sharing
      const emergencyPlatforms = [
        { name: 'Facebook', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}` },
        { name: 'Twitter', url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(content)}&url=${encodeURIComponent(url)}` },
        { name: 'LinkedIn', url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}` },
        { name: 'WhatsApp', url: `https://wa.me/?text=${encodeURIComponent(content + ' ' + url)}` }
      ];
      
      emergencyPlatforms.forEach((platform, index) => {
        setTimeout(() => {
          console.log(`📤 EMERGENCY: Opening ${platform.name}`);
          try {
            const popup = window.open(platform.url, `emergency_${platform.name}`, 'width=600,height=400,scrollbars=yes,resizable=yes');
            if (!popup) {
              console.warn(`Emergency popup blocked for ${platform.name}`);
            }
          } catch (popupError) {
            console.error(`Emergency popup error for ${platform.name}:`, popupError);
          }
        }, index * 300);
      });
      
      toast({
        title: "🚀 Emergency Share Active",
        description: "Opening 4 social platforms",
        duration: 4000
      });
      
      setTimeout(() => setIsSharing(false), 3000);
    } catch (error) {
      console.error('❌ Emergency share error:', error);
      setIsSharing(false);
    }
  };

  const handleMultiShare = () => {
    console.log('🌍 MULTI-SHARE SELECTION DIALOG');
    
    // Create a custom dialog for platform selection
    const dialogHtml = `
      <div id="multiShareDialog" style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="
          background: white;
          padding: 20px;
          border-radius: 8px;
          max-width: 500px;
          max-height: 80vh;
          overflow-y: auto;
        ">
          <h3 style="margin-bottom: 15px;">Select Platforms to Share</h3>
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 15px;">
            ${allPlatforms.map((platform, index) => `
              <label style="display: flex; align-items: center; padding: 5px;">
                <input type="checkbox" checked style="margin-right: 8px;" data-platform="${index}">
                <span style="font-size: 12px;">${platform.name}</span>
              </label>
            `).join('')}
          </div>
          <div style="display: flex; gap: 10px; justify-content: flex-end;">
            <button onclick="document.getElementById('multiShareDialog').remove()" style="
              padding: 8px 16px;
              border: 1px solid #ccc;
              background: white;
              border-radius: 4px;
              cursor: pointer;
            ">Cancel</button>
            <button onclick="window.executeMultiShare()" style="
              padding: 8px 16px;
              background: #3b82f6;
              color: white;
              border: none;
              border-radius: 4px;
              cursor: pointer;
            ">Share Selected</button>
          </div>
        </div>
      </div>
    `;
    
    // Add dialog to page
    document.body.insertAdjacentHTML('beforeend', dialogHtml);
    
    // Add global function for execution
    (window as any).executeMultiShare = () => {
      const checkboxes = document.querySelectorAll('#multiShareDialog input[type="checkbox"]:checked');
      const selectedPlatforms: number[] = [];
      
      checkboxes.forEach((checkbox: any) => {
        selectedPlatforms.push(parseInt(checkbox.dataset.platform));
      });
      
      // Open selected platforms
      selectedPlatforms.forEach((platformIndex, index) => {
        setTimeout(() => {
          const platform = allPlatforms[platformIndex];
          console.log(`📤 Opening selected: ${platform.name}`);
          window.open(platform.url, `selected_${platform.name}`, 'width=600,height=400,scrollbars=yes,resizable=yes');
        }, index * 200);
      });
      
      document.getElementById('multiShareDialog')?.remove();
      
      toast({
        title: "🌍 Multi-Share Complete",
        description: `Opened ${selectedPlatforms.length} selected platforms`,
        duration: 3000
      });
    };
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(url);
      toast({
        title: "Link Copied",
        description: "Share link copied to clipboard"
      });
    } catch (error) {
      console.error('Copy error:', error);
      toast({
        title: "Copy Failed",
        description: "Please copy the link manually",
        variant: "destructive"
      });
    }
  };

  if (variant === 'icon') {
    return (
      <button
        onClick={handleQuickShare}
        className={`inline-flex items-center p-1 rounded hover:bg-gray-100 ${className}`}
        disabled={isSharing}
        title="Quick Share"
      >
        <Share2 className="w-4 h-4" />
      </button>
    );
  }

  if (variant === 'text') {
    return (
      <button
        onClick={handleQuickShare}
        className={`text-sm text-blue-600 hover:text-blue-800 ${className}`}
        disabled={isSharing}
      >
        Share
      </button>
    );
  }

  // Full button variant with dropdown
  return (
    <div className={`relative inline-block ${className}`}>
      <div className="flex gap-1">
        <button
          onClick={(e) => {
            console.log('🔥 EMERGENCY SHARE CLICK DETECTED');
            e.preventDefault();
            e.stopPropagation();
            handleQuickShare(e);
          }}
          onMouseDown={(e) => {
            console.log('🔥 EMERGENCY SHARE MOUSEDOWN');
            e.preventDefault();
            e.stopPropagation();
            handleQuickShare(e);
          }}
          disabled={isSharing}
          className="inline-flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 cursor-pointer"
          title="Share to Facebook, Twitter, LinkedIn, WhatsApp"
          style={{ 
            pointerEvents: 'auto',
            zIndex: 9999,
            position: 'relative'
          }}
        >
          <Share2 className="w-3 h-3" />
          {isSharing ? 'Sharing...' : 'Share'}
        </button>
        
        <button
          onClick={(e) => {
            console.log('🔥 EMERGENCY ALL BUTTON CLICK DETECTED');
            e.preventDefault();
            e.stopPropagation();
            handleMultiShare();
          }}
          onMouseDown={(e) => {
            console.log('🔥 EMERGENCY ALL BUTTON MOUSEDOWN');
            e.preventDefault();
            e.stopPropagation();
            handleMultiShare();
          }}
          disabled={isSharing}
          className="inline-flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 cursor-pointer"
          title="Share to ALL 26+ platforms"
          style={{ 
            pointerEvents: 'auto',
            zIndex: 9999,
            position: 'relative'
          }}
        >
          <ExternalLink className="w-3 h-3" />
          {isSharing ? 'Opening...' : 'All'}
        </button>
        
        <button
          onClick={handleCopyLink}
          className="inline-flex items-center px-2 py-1.5 text-xs font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          title="Copy share link"
        >
          Copy
        </button>
      </div>
    </div>
  );
}