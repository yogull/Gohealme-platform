import { useState } from 'react';
import { Heart, Share2, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface SocialActionsProps {
  itemId: number;
  itemType: 'blog' | 'product' | 'image' | 'discussion';
  initialLikes?: number;
  initialComments?: number;
  isLiked?: boolean;
  showComments?: boolean;
  compact?: boolean;
}

export default function SocialActions({
  itemId,
  itemType,
  initialLikes = 0,
  initialComments = 0,
  isLiked = false,
  showComments = true,
  compact = false
}: SocialActionsProps) {
  const [liked, setLiked] = useState(isLiked);
  const [likeCount, setLikeCount] = useState(initialLikes);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (liked) {
        return apiRequest('DELETE', `/api/${itemType}s/${itemId}/like`);
      } else {
        return apiRequest('POST', `/api/${itemType}s/${itemId}/like`);
      }
    },
    onSuccess: () => {
      setLiked(!liked);
      setLikeCount(prev => liked ? prev - 1 : prev + 1);
      // Invalidate multiple query keys to ensure updates
      queryClient.invalidateQueries({ queryKey: [`/api/${itemType}s`] });
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall'] });
      queryClient.invalidateQueries({ queryKey: ['/api/community-discussions'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update like status",
        variant: "destructive"
      });
    }
  });

  const handleLike = () => {
    likeMutation.mutate();
  };

  const handleShare = () => {
    console.log('🔥 BLOG SHARE EMERGENCY ACTIVATION');
    
    // EMERGENCY DIRECT SHARE - bypassing all React components
    const shareContent = `Check out this ${itemType} on GoHealMe - The People's Health Community`;
    const currentUrl = window.location.href;
    
    try {
      // Create emergency native share dialog
      const platforms = [
        { name: 'Facebook', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}` },
        { name: 'Twitter', url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareContent)}&url=${encodeURIComponent(currentUrl)}` },
        { name: 'LinkedIn', url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(currentUrl)}` },
        { name: 'WhatsApp', url: `https://wa.me/?text=${encodeURIComponent(shareContent + ' ' + currentUrl)}` }
      ];
      
      // Emergency native dialog
      const dialogHtml = `
        <div id="emergencyShareDialog" style="
          position: fixed; top: 0; left: 0; width: 100%; height: 100%;
          background: rgba(0,0,0,0.8); z-index: 99999; display: flex;
          align-items: center; justify-content: center;
        ">
          <div style="background: white; padding: 20px; border-radius: 8px; max-width: 400px;">
            <h3 style="margin-bottom: 15px; text-align: center;">Share This ${itemType.charAt(0).toUpperCase() + itemType.slice(1)}</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
              ${platforms.map(platform => `
                <button onclick="window.open('${platform.url}', '_blank', 'width=600,height=400'); document.getElementById('emergencyShareDialog').remove();" 
                        style="padding: 10px; border: 1px solid #ddd; background: #f8f9fa; border-radius: 4px; cursor: pointer;">
                  ${platform.name}
                </button>
              `).join('')}
            </div>
            <div style="text-align: center;">
              <button onclick="navigator.clipboard.writeText('${currentUrl}').then(() => alert('Link copied!')).catch(() => {}); document.getElementById('emergencyShareDialog').remove();" 
                      style="padding: 8px 16px; background: #6b7280; color: white; border: none; border-radius: 4px; margin-right: 10px; cursor: pointer;">
                Copy Link
              </button>
              <button onclick="document.getElementById('emergencyShareDialog').remove()" 
                      style="padding: 8px 16px; border: 1px solid #ccc; background: white; border-radius: 4px; cursor: pointer;">
                Cancel
              </button>
            </div>
          </div>
        </div>
      `;
      
      document.body.insertAdjacentHTML('beforeend', dialogHtml);
      
      console.log('✅ Emergency blog share dialog activated');
      
    } catch (error) {
      console.error('Emergency share failed:', error);
      // Ultimate fallback
      alert(`Share this link: ${currentUrl}`);
    }
  };

  if (compact) {
    return (
      <div className="flex items-center gap-2 text-sm">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleLike}
          disabled={likeMutation.isPending}
          className={`p-1 h-auto ${liked ? 'text-red-500' : 'text-muted-foreground'}`}
        >
          <Heart className={`w-4 h-4 ${liked ? 'fill-current' : ''}`} />
          <span className="ml-1">{likeCount}</span>
        </Button>
        
        {showComments && (
          <span className="flex items-center gap-1 text-muted-foreground">
            <MessageCircle className="w-4 h-4" />
            {initialComments}
          </span>
        )}
        
        <Button
          variant="ghost"
          size="sm"
          onClick={handleShare}
          className="p-1 h-auto text-muted-foreground"
        >
          <Share2 className="w-4 h-4" />
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-4 py-3 border-t">
      <Button
        variant="ghost"
        onClick={handleLike}
        disabled={likeMutation.isPending}
        className={`flex items-center gap-2 ${liked ? 'text-red-500' : 'text-muted-foreground'}`}
      >
        <Heart className={`w-5 h-5 ${liked ? 'fill-current' : ''}`} />
        <span className="font-medium">{likeCount}</span>
        <span>Like{likeCount !== 1 ? 's' : ''}</span>
      </Button>

      {showComments && (
        <div className="flex items-center gap-2 text-muted-foreground">
          <MessageCircle className="w-5 h-5" />
          <span className="font-medium">{initialComments}</span>
          <span>Comment{initialComments !== 1 ? 's' : ''}</span>
        </div>
      )}

      <Button
        variant="ghost"
        onClick={handleShare}
        className="flex items-center gap-2 text-muted-foreground ml-auto"
      >
        <Share2 className="w-5 h-5" />
        <span>Share</span>
      </Button>
    </div>
  );
}