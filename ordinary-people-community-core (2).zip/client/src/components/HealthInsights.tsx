import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Activity, Calendar, Target, Award } from "lucide-react";
import { cn } from "@/lib/utils";

interface HealthMetric {
  name: string;
  value: number;
  previousValue: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  category: 'excellent' | 'good' | 'moderate' | 'needs_attention';
}

interface SupplementEffectiveness {
  supplementName: string;
  adherenceRate: number;
  effectivenessScore: number;
  correlatedMetrics: string[];
  recommendations: string[];
}

interface HealthInsightsData {
  overallScore: number;
  metrics: HealthMetric[];
  supplementEffectiveness: SupplementEffectiveness[];
  weeklyProgress: {
    week: string;
    score: number;
  }[];
  achievements: {
    title: string;
    description: string;
    earnedDate: string;
    icon: string;
  }[];
}

interface HealthInsightsProps {
  userId: number;
}

export function HealthInsights({ userId }: HealthInsightsProps) {
  const { data, isLoading } = useQuery<HealthInsightsData>({
    queryKey: [`/api/health-insights/${userId}`],
    enabled: !!userId,
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!data) return null;

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600 bg-green-50";
    if (score >= 60) return "text-blue-600 bg-blue-50";
    if (score >= 40) return "text-yellow-600 bg-yellow-50";
    return "text-red-600 bg-red-50";
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'excellent': return "text-green-600 bg-green-50 border-green-200";
      case 'good': return "text-blue-600 bg-blue-50 border-blue-200";
      case 'moderate': return "text-yellow-600 bg-yellow-50 border-yellow-200";
      case 'needs_attention': return "text-red-600 bg-red-50 border-red-200";
      default: return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-500" />;
      default: return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Health Insights</h2>
        <Badge variant="secondary" className="flex items-center gap-1">
          <Target className="w-3 h-3" />
          Overall Score: {data.overallScore}/100
        </Badge>
      </div>

      {/* Overall Health Score */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Health Dashboard
          </CardTitle>
          <CardDescription>
            Your comprehensive health overview based on supplement adherence and biometric data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Overall Health Score</span>
              <span className={cn("text-2xl font-bold px-3 py-1 rounded-full", getScoreColor(data.overallScore))}>
                {data.overallScore}%
              </span>
            </div>
            <Progress value={data.overallScore} className="h-3" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              {data.weeklyProgress.slice(-4).map((week, index) => (
                <div key={index} className="text-center">
                  <div className="text-xs text-gray-500 mb-1">{week.week}</div>
                  <div className="text-lg font-semibold">{week.score}%</div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Health Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {data.metrics.map((metric, index) => (
          <Card key={index} className={cn("border-l-4", getCategoryColor(metric.category))}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-sm">{metric.name}</h3>
                {getTrendIcon(metric.trend)}
              </div>
              <div className="space-y-2">
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold">{metric.value}</span>
                  <span className="text-sm text-gray-500">{metric.unit}</span>
                </div>
                <div className="text-xs text-gray-500">
                  Previous: {metric.previousValue} {metric.unit}
                </div>
                <Badge variant="outline" className={getCategoryColor(metric.category)}>
                  {metric.category.replace('_', ' ')}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Supplement Effectiveness */}
      <Card>
        <CardHeader>
          <CardTitle>Supplement Effectiveness Analysis</CardTitle>
          <CardDescription>
            How well your supplements are working based on adherence and health metrics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {data.supplementEffectiveness.map((supplement, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold">{supplement.supplementName}</h4>
                  <div className="flex gap-2">
                    <Badge variant="outline">
                      {supplement.adherenceRate}% adherence
                    </Badge>
                    <Badge variant={supplement.effectivenessScore >= 70 ? "default" : "secondary"}>
                      {supplement.effectivenessScore}% effective
                    </Badge>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h5 className="text-sm font-medium mb-2">Correlated Metrics</h5>
                    <div className="flex flex-wrap gap-1">
                      {supplement.correlatedMetrics.map((metric, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {metric}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h5 className="text-sm font-medium mb-2">Recommendations</h5>
                    <ul className="text-xs space-y-1">
                      {supplement.recommendations.map((rec, idx) => (
                        <li key={idx} className="text-gray-600">• {rec}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Achievements */}
      {data.achievements.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5" />
              Recent Achievements
            </CardTitle>
            <CardDescription>
              Milestones you've reached on your health journey
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              {data.achievements.map((achievement, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200">
                  <div className="text-2xl">{achievement.icon}</div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm">{achievement.title}</h4>
                    <p className="text-xs text-gray-600 mt-1">{achievement.description}</p>
                    <div className="flex items-center gap-1 mt-2">
                      <Calendar className="w-3 h-3 text-gray-400" />
                      <span className="text-xs text-gray-500">{achievement.earnedDate}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}