import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Gift, Users, Target, Share2, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ReferralStatus {
  referralsCount: number;
  freeAdsAvailable: number;
  nextRewardAt: number;
}

interface ReferralIncentivesProps {
  userId: number;
}

export default function ReferralIncentives({ userId }: ReferralIncentivesProps) {
  const { toast } = useToast();
  const [referralLink, setReferralLink] = useState('');

  const { data: referralStatus, isLoading } = useQuery<ReferralStatus>({
    queryKey: ['referral-status', userId],
    queryFn: () => fetch(`/api/referrals/status/${userId}`).then(res => res.json()),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  useEffect(() => {
    // Generate unique referral link for this user
    const baseUrl = window.location.origin;
    setReferralLink(`${baseUrl}?ref=user_${userId}_${Date.now()}&source=referral_incentive`);
  }, [userId]);

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast({
      title: "Referral Link Copied!",
      description: "Share this link to earn free ads. Every 2 people who sign up = 1 free ad!",
    });
  };

  const progressToNextReward = referralStatus 
    ? ((2 - referralStatus.nextRewardAt) / 2) * 100 
    : 0;

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gift className="w-5 h-5" />
            Loading Referral Rewards...
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Main Referral Card */}
      <Card className="w-full bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-purple-700">
            <Gift className="w-6 h-6" />
            Referral Reward System
          </CardTitle>
          <CardDescription>
            Invite friends and earn FREE advertisements! Every 2 successful referrals = 1 free ad worth £24
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {referralStatus?.referralsCount || 0}
              </div>
              <div className="text-sm text-gray-600">Total Referrals</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {referralStatus?.freeAdsAvailable || 0}
              </div>
              <div className="text-sm text-gray-600">Free Ads Available</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                £{((referralStatus?.freeAdsAvailable || 0) * 24).toFixed(0)}
              </div>
              <div className="text-sm text-gray-600">Value Earned</div>
            </div>
          </div>

          {/* Progress to Next Reward */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Progress to Next Free Ad</span>
              <span className="text-sm text-gray-600">
                {referralStatus?.nextRewardAt || 2} more referrals needed
              </span>
            </div>
            <Progress value={progressToNextReward} className="h-3" />
          </div>

          {/* Referral Link */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Your Referral Link</label>
            <div className="flex gap-2">
              <div className="flex-1 p-2 bg-white border rounded text-sm truncate">
                {referralLink}
              </div>
              <Button 
                onClick={copyReferralLink}
                variant="outline" 
                size="sm"
                className="flex items-center gap-1"
              >
                <Copy className="w-4 h-4" />
                Copy
              </Button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button 
              onClick={() => window.open(`https://facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`, '_blank')}
              className="flex-1"
              variant="outline"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share on Facebook
            </Button>
            <Button 
              onClick={() => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent('Join me on Ordinary People Community!')}&url=${encodeURIComponent(referralLink)}`, '_blank')}
              className="flex-1"
              variant="outline"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share on Twitter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* How It Works */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            How Referral Rewards Work
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">1</Badge>
              <div>
                <div className="font-medium">Share Your Link</div>
                <div className="text-sm text-gray-600">
                  Copy and share your unique referral link on social media, email, or direct messages
                </div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">2</Badge>
              <div>
                <div className="font-medium">People Join</div>
                <div className="text-sm text-gray-600">
                  When someone clicks your link and creates an account, they count as your referral
                </div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">3</Badge>
              <div>
                <div className="font-medium">Earn Free Ads</div>
                <div className="text-sm text-gray-600">
                  Every 2 successful referrals earns you 1 free advertisement (worth £24) in your personal shop
                </div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">4</Badge>
              <div>
                <div className="font-medium">Automatic Rewards</div>
                <div className="text-sm text-gray-600">
                  Free ads are automatically added to your account and can be used when creating business advertisements
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Examples */}
      <Card className="bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-green-700">Reward Examples</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>Refer 10 people:</span>
              <span className="font-medium text-green-600">5 free ads (£120 value)</span>
            </div>
            <div className="flex justify-between">
              <span>Refer 20 people:</span>
              <span className="font-medium text-green-600">10 free ads (£240 value)</span>
            </div>
            <div className="flex justify-between">
              <span>Refer 40 people:</span>
              <span className="font-medium text-green-600">20 free ads (£480 value)</span>
            </div>
            <div className="flex justify-between">
              <span>Refer 100 people:</span>
              <span className="font-medium text-green-600">50 free ads (£1,200 value)</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}