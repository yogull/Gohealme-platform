import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Upload, Image, Video, X } from "lucide-react";

interface BulletproofUploadProps {
  onUploadComplete: (url: string, type: 'image' | 'video') => void;
  accept?: string;
  maxSize?: number;
  multiple?: boolean;
  type: 'image' | 'video' | 'both';
}

export function BulletproofUpload({ 
  onUploadComplete, 
  accept,
  maxSize = 50 * 1024 * 1024, // 50MB default
  multiple = false,
  type = 'both'
}: BulletproofUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { toast } = useToast();

  const handleFileSelect = async (fileType: 'image' | 'video') => {
    const input = document.createElement('input');
    input.type = 'file';
    
    if (fileType === 'image') {
      input.accept = 'image/*';
    } else if (fileType === 'video') {
      input.accept = 'video/*';
    }
    
    input.multiple = multiple;
    
    input.onchange = async (e) => {
      const files = (e.target as HTMLInputElement).files;
      if (!files || files.length === 0) return;

      setIsUploading(true);
      setUploadProgress(0);

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        // Validate file type
        const isValidType = fileType === 'image' 
          ? file.type.startsWith('image/') 
          : file.type.startsWith('video/');
        
        if (!isValidType) {
          toast({
            title: "Invalid file type",
            description: `${file.name} is not a valid ${fileType} file`,
            variant: "destructive"
          });
          continue;
        }

        // Validate file size
        if (file.size > maxSize) {
          const sizeMB = Math.round(maxSize / (1024 * 1024));
          toast({
            title: "File too large",
            description: `${file.name} is larger than ${sizeMB}MB`,
            variant: "destructive"
          });
          continue;
        }

        try {
          setUploadProgress(25);
          
          // Convert to base64
          const base64Data = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });

          setUploadProgress(50);

          // Upload with retry logic
          let uploadResult;
          let attempts = 0;
          const maxAttempts = 3;

          while (attempts < maxAttempts) {
            try {
              setUploadProgress(75);
              
              const response = await fetch('/api/files/upload', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  fileName: file.name,
                  fileData: base64Data,
                  fileType: file.type,
                }),
              });

              if (response.ok) {
                uploadResult = await response.json();
                break;
              } else {
                throw new Error(`Upload failed: ${response.status}`);
              }
            } catch (retryError) {
              attempts++;
              if (attempts >= maxAttempts) {
                throw retryError;
              }
              // Wait 1 second before retry
              await new Promise(resolve => setTimeout(resolve, 1000));
            }
          }

          setUploadProgress(100);

          // Get final URL
          const finalUrl = uploadResult?.url || uploadResult?.fileId || base64Data;
          
          toast({
            title: "Upload successful",
            description: `${file.name} uploaded successfully`,
          });

          onUploadComplete(finalUrl, fileType);

        } catch (error) {
          console.error('Upload error:', error);
          toast({
            title: "Upload failed",
            description: `Failed to upload ${file.name}. Please try again.`,
            variant: "destructive"
          });
        }
      }

      setIsUploading(false);
      setUploadProgress(0);
    };

    input.click();
  };

  return (
    <div className="flex gap-2">
      {(type === 'image' || type === 'both') && (
        <Button 
          size="sm" 
          variant="outline"
          onClick={() => handleFileSelect('image')}
          disabled={isUploading}
        >
          <Image className="w-4 h-4 mr-1" />
          {isUploading ? `${uploadProgress}%` : 'Photo'}
        </Button>
      )}
      
      {(type === 'video' || type === 'both') && (
        <Button 
          size="sm" 
          variant="outline"
          onClick={() => handleFileSelect('video')}
          disabled={isUploading}
        >
          <Video className="w-4 h-4 mr-1" />
          {isUploading ? `${uploadProgress}%` : 'Video'}
        </Button>
      )}
    </div>
  );
}