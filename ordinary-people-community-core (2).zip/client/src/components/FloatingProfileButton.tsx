import { useAuth } from "@/hooks/useAuth";

interface FloatingProfileButtonProps {
  currentUserId?: string;
}

export function FloatingProfileButton({ currentUserId }: FloatingProfileButtonProps) {
  const { appUser } = useAuth();

  // Don't show if user is not logged in or if we're on mobile (buttons are in header now)
  if (!appUser || window.innerWidth < 1024) return null;

  return (
    <div 
      style={{
        position: 'fixed',
        bottom: '16px',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 9999
      }}
    >
      <a
        href={`/profile-wall/${appUser.id}`}
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '4px',
          padding: '6px 16px',
          borderRadius: '9999px',
          backgroundColor: '#3b82f6',
          color: 'white',
          fontWeight: '600',
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
          textDecoration: 'none',
          fontSize: '12px',
          whiteSpace: 'nowrap',
          animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite'
        }}
        onMouseEnter={(e) => (e.target as HTMLElement).style.backgroundColor = '#2563eb'}
        onMouseLeave={(e) => (e.target as HTMLElement).style.backgroundColor = '#3b82f6'}
      >
        <span>Go to Profile Wall</span>
      </a>
    </div>
  );
}