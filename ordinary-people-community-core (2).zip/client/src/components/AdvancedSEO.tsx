import { useEffect } from 'react';
import { useLocation } from 'wouter';

// Advanced SEO optimization component for maximum search rankings
export function AdvancedSEO() {
  const [location] = useLocation();

  useEffect(() => {
    // Add critical performance meta tags
    const viewport = document.querySelector('meta[name="viewport"]');
    if (!viewport) {
      const viewportMeta = document.createElement('meta');
      viewportMeta.name = 'viewport';
      viewportMeta.content = 'width=device-width, initial-scale=1, shrink-to-fit=no';
      document.head.appendChild(viewportMeta);
    }

    // Add web app manifest
    const manifest = document.createElement('link');
    manifest.rel = 'manifest';
    manifest.href = '/manifest.json';
    document.head.appendChild(manifest);

    // Add theme color for mobile browsers
    const themeColor = document.createElement('meta');
    themeColor.name = 'theme-color';
    themeColor.content = '#10b981';
    document.head.appendChild(themeColor);

    // Add apple touch icons
    const appleTouchIcon = document.createElement('link');
    appleTouchIcon.rel = 'apple-touch-icon';
    appleTouchIcon.href = '/icon-192x192.png';
    document.head.appendChild(appleTouchIcon);

    // Add robots meta tag for indexing
    const robots = document.createElement('meta');
    robots.name = 'robots';
    robots.content = 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    document.head.appendChild(robots);

    // Add author meta tag
    const author = document.createElement('meta');
    author.name = 'author';
    author.content = 'Ordinary People Community';
    document.head.appendChild(author);

    // Add generator meta tag
    const generator = document.createElement('meta');
    generator.name = 'generator';
    generator.content = 'Ordinary People Community Platform v1.0';
    document.head.appendChild(generator);

    // Add referrer policy for privacy
    const referrer = document.createElement('meta');
    referrer.name = 'referrer';
    referrer.content = 'strict-origin-when-cross-origin';
    document.head.appendChild(referrer);

    // Add format detection
    const formatDetection = document.createElement('meta');
    formatDetection.name = 'format-detection';
    formatDetection.content = 'telephone=yes';
    document.head.appendChild(formatDetection);

    // Add Google site verification
    const googleVerification = document.createElement('meta');
    googleVerification.name = 'google-site-verification';
    googleVerification.content = 'GOOGLE_VERIFICATION_CODE_TO_BE_ADDED';
    document.head.appendChild(googleVerification);

    // Add Bing site verification
    const bingVerification = document.createElement('meta');
    bingVerification.name = 'msvalidate.01';
    bingVerification.content = 'BING_VERIFICATION_CODE_TO_BE_ADDED';
    document.head.appendChild(bingVerification);

    // Add page-specific schema markup
    const pageSchema = {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "Ordinary People Community",
      "alternateName": "Community for Government, Health & Personal Views",
      "url": "https://gohealme.org",
      "description": "A platform for ordinary people to discuss government topics, personal views, and health advice. Connect with real people and share experiences away from the elites.",
      "potentialAction": {
        "@type": "SearchAction",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://gohealme.org/search?q={search_term_string}"
        },
        "query-input": "required name=search_term_string"
      },
      "sameAs": [
        "https://facebook.com/ordinarypeople",
        "https://twitter.com/ordinarypeople",
        "https://linkedin.com/company/ordinarypeople"
      ]
    };

    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.text = JSON.stringify(pageSchema);
    document.head.appendChild(schemaScript);

    return () => {
      try {
        document.head.removeChild(manifest);
        document.head.removeChild(themeColor);
        document.head.removeChild(appleTouchIcon);
        document.head.removeChild(robots);
        document.head.removeChild(author);
        document.head.removeChild(generator);
        document.head.removeChild(referrer);
        document.head.removeChild(formatDetection);
        document.head.removeChild(googleVerification);
        document.head.removeChild(bingVerification);
        document.head.removeChild(schemaScript);
      } catch (e) {
        // Ignore cleanup errors
      }
    };
  }, [location]);

  return null;
}

// Performance optimization for Core Web Vitals
export function CoreWebVitalsOptimizer() {
  useEffect(() => {
    // Preload critical resources
    const preloadFont = document.createElement('link');
    preloadFont.rel = 'preload';
    preloadFont.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
    preloadFont.as = 'style';
    document.head.appendChild(preloadFont);

    // Add resource hints for better performance
    const dnsRequests = [
      'https://fonts.googleapis.com',
      'https://fonts.gstatic.com',
      'https://www.google-analytics.com'
    ];

    dnsRequests.forEach(domain => {
      const link = document.createElement('link');
      link.rel = 'dns-prefetch';
      link.href = domain;
      document.head.appendChild(link);
    });

    // Optimize images with lazy loading
    const images = document.querySelectorAll('img:not([loading])');
    images.forEach(img => {
      img.setAttribute('loading', 'lazy');
    });

    // Add performance observer for monitoring
    if ('PerformanceObserver' in window) {
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'largest-contentful-paint') {
            console.log('LCP:', entry.startTime);
          }
          if (entry.entryType === 'first-input') {
            console.log('FID:', entry.processingStart - entry.startTime);
          }
        }
      });

      observer.observe({ entryTypes: ['largest-contentful-paint', 'first-input'] });
    }

    return () => {
      document.head.removeChild(preloadFont);
    };
  }, []);

  return null;
}