import { useEffect, useState } from "react";
import { AdCarousel } from "./AdCarousel";

interface MobileAwareAdCarouselProps {
  location?: string;
  scope?: "local" | "national";
  categoryId?: number;
  userId?: number;
  position: "left" | "right";
}

export function MobileAwareAdCarousel(props: MobileAwareAdCarouselProps) {
  const [isMobile, setIsMobile] = useState(true); // Start as mobile to prevent flash
  
  useEffect(() => {
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth <= 1024);
    };
    
    // Check immediately
    checkIsMobile();
    
    // Listen for resize events
    window.addEventListener('resize', checkIsMobile);
    
    return () => window.removeEventListener('resize', checkIsMobile);
  }, []);
  
  // Don't render anything on mobile to prevent hooks issues
  if (isMobile) {
    return null;
  }
  
  // Only render AdCarousel on desktop with proper defaults
  return <AdCarousel 
    location={props.location || "Nottingham"}
    scope={props.scope || "local"}
    categoryId={props.categoryId}
    userId={props.userId}
    position={props.position}
  />;
}