import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, ArrowRight, ArrowLeft, HelpCircle } from "lucide-react";
import { useTranslation } from "@/hooks/useTranslation";

interface TutorialStep {
  title: string;
  content: string;
  target?: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
  action?: string;
}

interface TutorialPopupProps {
  page: string;
  steps: TutorialStep[];
  onComplete: () => void;
  onSkip: () => void;
}

export function TutorialPopup({ page, steps, onComplete, onSkip }: TutorialPopupProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const { t } = useTranslation();

  if (!isVisible || steps.length === 0) return null;

  const current = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;
  const isFirstStep = currentStep === 0;

  const handleNext = () => {
    if (isLastStep) {
      setIsVisible(false);
      onComplete();
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (!isFirstStep) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSkip = () => {
    setIsVisible(false);
    onSkip();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md mx-auto bg-white shadow-xl">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-2">
              <HelpCircle className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg font-semibold">{current.title}</CardTitle>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSkip}
              className="h-8 w-8 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex space-x-1 mt-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`h-1.5 rounded-full flex-1 ${
                  index <= currentStep ? 'bg-primary' : 'bg-gray-200'
                }`}
              />
            ))}
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="text-gray-700 leading-relaxed">
            {current.content}
          </div>

          {current.action && (
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800 font-medium">
                💡 {t('tutorial.tryThis')}: {current.action}
              </p>
            </div>
          )}

          <div className="flex justify-between items-center pt-4">
            <div className="text-sm text-gray-500">
              {t('tutorial.step')} {currentStep + 1} {t('tutorial.of')} {steps.length}
            </div>
            
            <div className="flex space-x-2">
              {!isFirstStep && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePrevious}
                  className="flex items-center space-x-1"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>{t('tutorial.previous')}</span>
                </Button>
              )}
              
              <Button
                onClick={handleNext}
                size="sm"
                className="bg-primary hover:bg-primary/90 flex items-center space-x-1"
              >
                <span>{isLastStep ? t('tutorial.gotIt') : t('tutorial.next')}</span>
                {!isLastStep && <ArrowRight className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          <div className="pt-2 border-t">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSkip}
              className="w-full text-gray-500 hover:text-gray-700"
            >
{t('tutorial.skipTutorial')}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}