import { useState, useRef, useEffect } from 'react';
import { useDebounce } from '@/hooks/usePerformance';
import { Search, X, Clock, TrendingUp, User, Pill } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface SearchResult {
  id: string;
  type: 'user' | 'supplement' | 'discussion' | 'condition';
  title: string;
  description: string;
  url: string;
  metadata?: Record<string, string>;
}

interface SmartSearchProps {
  onResultSelect?: (result: SearchResult) => void;
  placeholder?: string;
  className?: string;
}

export function SmartSearch({ onResultSelect, placeholder = "Search anything...", className }: SmartSearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  
  const debouncedQuery = useDebounce(query, 300);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('recentSearches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  // Save recent searches to localStorage
  const saveRecentSearch = (searchQuery: string) => {
    if (searchQuery.trim()) {
      const updated = [searchQuery, ...recentSearches.filter(s => s !== searchQuery)].slice(0, 5);
      setRecentSearches(updated);
      localStorage.setItem('recentSearches', JSON.stringify(updated));
    }
  };

  // Perform search with debounced query
  useEffect(() => {
    if (debouncedQuery.length >= 2) {
      performSearch(debouncedQuery);
    } else {
      setResults([]);
    }
  }, [debouncedQuery]);

  const performSearch = async (searchQuery: string) => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) throw new Error('Search failed');
      
      const searchResults = await response.json();
      
      // Transform API response to SearchResult format
      const formattedResults: SearchResult[] = searchResults.map((item: any) => ({
        id: item.id.toString(),
        type: item.type as 'user' | 'supplement' | 'discussion' | 'condition',
        title: item.title || item.name,
        description: item.description || item.content?.substring(0, 100) || '',
        url: `/${item.type}s/${item.id}`,
        metadata: item.metadata || {}
      }));

      setResults(formattedResults);
    } catch (error) {
      console.error('Search error:', error);
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => Math.min(prev + 1, results.length - 1));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => Math.max(prev - 1, -1));
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && results[selectedIndex]) {
          handleResultSelect(results[selectedIndex]);
        } else if (query.trim()) {
          saveRecentSearch(query);
        }
        break;
      case 'Escape':
        setIsOpen(false);
        inputRef.current?.blur();
        break;
    }
  };

  const handleResultSelect = (result: SearchResult) => {
    saveRecentSearch(query);
    setQuery('');
    setIsOpen(false);
    onResultSelect?.(result);
  };

  const getResultIcon = (type: string) => {
    switch (type) {
      case 'supplement': return <Pill className="w-4 h-4 text-green-500" />;
      case 'user': return <User className="w-4 h-4 text-blue-500" />;
      case 'condition': return <TrendingUp className="w-4 h-4 text-orange-500" />;
      default: return <Search className="w-4 h-4 text-gray-500" />;
    }
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={searchRef} className={cn("relative", className)}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input
          ref={inputRef}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="pl-10 pr-10"
        />
        {query && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setQuery('');
              setResults([]);
              inputRef.current?.focus();
            }}
            className="absolute right-1 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
          >
            <X className="w-3 h-3" />
          </Button>
        )}
      </div>

      {isOpen && (
        <Card className="absolute top-full left-0 right-0 mt-1 z-50 max-h-96 overflow-y-auto">
          <CardContent className="p-0">
            {/* Recent searches */}
            {!query && recentSearches.length > 0 && (
              <div className="p-3 border-b">
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                  <Clock className="w-3 h-3" />
                  Recent searches
                </div>
                {recentSearches.map((search, index) => (
                  <button
                    key={index}
                    onClick={() => setQuery(search)}
                    className="block w-full text-left px-2 py-1 text-sm hover:bg-gray-50 rounded"
                  >
                    {search}
                  </button>
                ))}
              </div>
            )}

            {/* Search results */}
            {query && (
              <>
                {isLoading ? (
                  <div className="p-4 text-center text-sm text-gray-500">
                    Searching...
                  </div>
                ) : results.length > 0 ? (
                  <div className="py-2">
                    {results.map((result, index) => (
                      <button
                        key={result.id}
                        onClick={() => handleResultSelect(result)}
                        className={cn(
                          "w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-gray-50 transition-colors",
                          selectedIndex === index && "bg-gray-50"
                        )}
                      >
                        {getResultIcon(result.type)}
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm text-gray-900 truncate">
                            {result.title}
                          </div>
                          <div className="text-xs text-gray-500 mt-1 line-clamp-2">
                            {result.description}
                          </div>
                          {result.metadata && (
                            <div className="text-xs text-gray-400 mt-1">
                              {Object.entries(result.metadata)[0]?.[1]}
                            </div>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 text-center text-sm text-gray-500">
                    No results found for "{query}"
                  </div>
                )}
              </>
            )}

            {/* Quick suggestions */}
            {!query && recentSearches.length === 0 && (
              <div className="p-3">
                <div className="text-sm text-gray-600 mb-2">Try searching for:</div>
                <div className="space-y-1">
                  {['Vitamin D', 'Joint pain', 'Sleep supplements', 'Mental health'].map((suggestion) => (
                    <button
                      key={suggestion}
                      onClick={() => setQuery(suggestion)}
                      className="block w-full text-left px-2 py-1 text-sm hover:bg-gray-50 rounded text-gray-700"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}