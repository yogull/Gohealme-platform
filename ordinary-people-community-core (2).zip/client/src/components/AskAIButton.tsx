import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Bot, Send, Sparkles, Globe, Calculator, BookOpen, Lightbulb, Loader2 } from "lucide-react";

interface AskAIButtonProps {
  variant?: "default" | "outline" | "ghost" | "floating";
  size?: "sm" | "default" | "lg";
  className?: string;
}

export function AskAIButton({ variant = "default", size = "default", className = "" }: AskAIButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [question, setQuestion] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const { appUser } = useAuth();
  const { toast } = useToast();

  const askAIMutation = useMutation({
    mutationFn: async (userQuestion: string) => {
      const response = await apiRequest("POST", "/api/ai/general-question", {
        question: userQuestion,
        userId: appUser?.id || 0
      });
      return response.json();
    },
    onSuccess: (data) => {
      setAiResponse(data.response);
      toast({
        title: "AI Response Ready",
        description: "Your question has been answered!"
      });
    },
    onError: () => {
      toast({
        title: "Failed to get AI response",
        description: "Please try again or ask a different question",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    
    if (!appUser) {
      toast({
        title: "Please Sign In",
        description: "You need to be logged in to ask AI questions",
        variant: "destructive"
      });
      return;
    }

    askAIMutation.mutate(question.trim());
  };

  const handleReset = () => {
    setQuestion("");
    setAiResponse("");
  };

  const suggestedQuestions = [
    "How far is the Moon from Earth?",
    "What are the health benefits of vitamin D?",
    "How does meditation affect the brain?",
    "What causes the Northern Lights?",
    "How do probiotics work?",
    "Why do we dream?",
    "What is the speed of light?",
    "How does exercise improve mental health?"
  ];

  const getButtonContent = () => {
    if (variant === "floating") {
      return (
        <div className="flex items-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 text-white px-4 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
          <Bot className="w-5 h-5" />
          <Sparkles className="w-4 h-4" />
          <span className="font-medium">Ask AI Anything</span>
        </div>
      );
    }

    return (
      <>
        <Bot className="w-4 h-4 mr-2" />
        Ask AI Anything
        <Sparkles className="w-4 h-4 ml-1" />
      </>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant={variant === "floating" ? "ghost" : variant} 
          size={size}
          className={`${className} ${variant === "floating" ? "p-0 h-auto bg-transparent hover:bg-transparent" : ""}`}
        >
          {getButtonContent()}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Bot className="w-6 h-6 text-blue-600" />
            Ask AI Anything
            <Badge variant="secondary" className="ml-2">
              <Globe className="w-3 h-3 mr-1" />
              Any Topic
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded-lg border-l-4 border-blue-400">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="w-4 h-4 text-blue-600" />
              <span className="font-medium">Ask about anything!</span>
            </div>
            <p>Health, science, math, history, technology, space, nature - no topic is off limits. Get instant AI-powered answers to satisfy your curiosity.</p>
          </div>

          {/* Suggested Questions */}
          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-700">Quick suggestions:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.slice(0, 4).map((suggestion, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => setQuestion(suggestion)}
                  className="text-xs h-8"
                  disabled={askAIMutation.isPending}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>

          {/* Question Input */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Your Question
              </label>
              <Textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ask anything... How does photosynthesis work? What's the capital of Mars' colony? How do I improve my sleep? What causes rainbows?"
                className="min-h-[100px] resize-none"
                disabled={askAIMutation.isPending}
              />
            </div>

            <div className="flex gap-2">
              <Button 
                type="submit" 
                disabled={!question.trim() || askAIMutation.isPending}
                className="flex-1"
              >
                {askAIMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Getting Answer...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Ask AI
                  </>
                )}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleReset}
                disabled={askAIMutation.isPending}
              >
                Clear
              </Button>
            </div>
          </form>

          {/* AI Response */}
          {aiResponse && (
            <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-3">
                <Bot className="w-5 h-5 text-blue-600" />
                <span className="font-medium text-blue-900">AI Response</span>
                <Badge variant="secondary">
                  <Calculator className="w-3 h-3 mr-1" />
                  AI Generated
                </Badge>
              </div>
              <div className="prose prose-sm max-w-none">
                <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                  {aiResponse}
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-blue-200">
                <p className="text-xs text-blue-600 flex items-center gap-1">
                  <BookOpen className="w-3 h-3" />
                  AI responses are for informational purposes. For medical advice, consult a healthcare professional.
                </p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}