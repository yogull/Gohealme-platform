import { ArrowLeft, Home, MessageCircle, Bot } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  showBackButton?: boolean;
  backTo?: string;
  showDashboardButton?: boolean;
}

export function PageHeader({ title, subtitle, showBackButton = true, backTo = "/", showDashboardButton = true }: PageHeaderProps) {
  const [, setLocation] = useLocation();

  const handleBack = () => {
    // Use browser history to go back to previous page
    if (window.history.length > 1) {
      window.history.back();
    } else {
      // Fallback to backTo prop if no history
      setLocation(backTo);
    }
  };

  const handleHome = () => {
    setLocation("/");
  };

  const handleChat = () => {
    setLocation("/chat");
  };

  return (
    <div className="mb-6 w-full overflow-hidden">
      <div className="flex flex-col space-y-3 sm:flex-row sm:items-center sm:justify-between sm:space-y-0 mb-4">
        <div className="flex items-center space-x-2 sm:space-x-4">
          {showBackButton && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleBack}
              className="flex items-center space-x-1 sm:space-x-2 text-xs sm:text-sm px-2 sm:px-3"
            >
              <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Back</span>
            </Button>
          )}
          
          {showDashboardButton && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleHome}
              className="flex items-center space-x-1 sm:space-x-2 text-xs sm:text-sm px-2 sm:px-3"
            >
              <Home className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Dashboard</span>
            </Button>
          )}
        </div>
        
        <div className="flex flex-row space-x-2 sm:space-x-3 justify-center sm:justify-end w-full sm:w-auto">
          <Button
            variant="default"
            size="sm"
            onClick={handleChat}
            className="flex items-center space-x-1 bg-primary hover:bg-primary/90 text-white text-xs sm:text-sm px-2 sm:px-3 py-1 sm:py-2 flex-1 sm:flex-none justify-center"
          >
            <MessageCircle className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="whitespace-nowrap">Chat Users</span>
          </Button>
          
          <Button
            variant="default"
            size="sm"
            onClick={() => setLocation("/chat?ai=true")}
            className="flex items-center space-x-1 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm px-2 sm:px-3 py-1 sm:py-2 flex-1 sm:flex-none justify-center"
          >
            <Bot className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="whitespace-nowrap">Chat AI</span>
          </Button>
        </div>
      </div>
      
      <div className="w-full overflow-hidden">
        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 break-words">{title}</h1>
        {subtitle && (
          <p className="text-gray-600 mt-2 text-sm sm:text-base break-words">{subtitle}</p>
        )}
      </div>
    </div>
  );
}