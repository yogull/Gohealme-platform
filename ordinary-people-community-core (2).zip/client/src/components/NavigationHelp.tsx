import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { X, HelpCircle, ArrowRight, ArrowLeft, CheckCircle } from "lucide-react";

interface TutorialStep {
  title: string;
  content: string;
  target?: string;
  action?: string;
}

interface PageTutorial {
  title: string;
  description: string;
  steps: TutorialStep[];
}

const tutorials: Record<string, PageTutorial> = {
  "/": {
    title: "Dashboard - Your Health Overview",
    description: "Your central hub for tracking health progress, viewing supplement compliance, and accessing quick insights.",
    steps: [
      {
        title: "Welcome to Your Dashboard",
        content: "This is your personal health command center. Here you can see an overview of your supplement tracking, biometric data, and recent activity.",
      },
      {
        title: "Supplement Compliance",
        content: "Track your daily supplement intake and see your consistency streak. The higher your compliance, the better your health tracking becomes.",
      },
      {
        title: "Recent Activity",
        content: "Stay updated with your latest health entries, community posts, and supplement logs. This helps you maintain accountability.",
      },
      {
        title: "Quick Actions",
        content: "Use the quick action buttons to log supplements, add biometric data, or create new posts without navigating away from your dashboard.",
      }
    ]
  },
  "/supplements": {
    title: "Supplements - Manage Your Regimen",
    description: "Add, track, and monitor your supplement intake. Share experiences with the community about what works for your body.",
    steps: [
      {
        title: "Your Supplement Library",
        content: "Add all the supplements you take regularly. Include dosages, timing, and notes about how they make you feel.",
      },
      {
        title: "Daily Logging",
        content: "Log when you take each supplement. Consistency tracking helps you understand what's working and maintain your regimen.",
      },
      {
        title: "Supplement Details",
        content: "Click on any supplement to see detailed information, your usage history, and add personal notes about effects.",
      },
      {
        title: "Share Experiences",
        content: "Use the community features to share which supplements work for you, dosages, and timing strategies with other members.",
      }
    ]
  },
  "/biometrics": {
    title: "Biometrics - Track Your Health/Wellness Data",
    description: "Monitor vital signs, energy levels, sleep patterns, and other health/wellness metrics to understand your body's responses.",
    steps: [
      {
        title: "Health/Wellness Metrics Tracking",
        content: "Log daily metrics like weight, blood pressure, heart rate, steps, and sleep hours to monitor your health/wellness trends.",
      },
      {
        title: "Energy and Mood",
        content: "Track your energy levels and mood to correlate with supplement intake, sleep, and other lifestyle factors.",
      },
      {
        title: "Visual Trends",
        content: "View charts and graphs of your health data over time to identify patterns and improvements in your wellness journey.",
      },
      {
        title: "Data Insights",
        content: "Use your biometric data to make informed decisions about supplements, exercise, and health/wellness lifestyle changes.",
      }
    ]
  },
  "/illness-guides": {
    title: "Illness Guides - Understanding Health/Wellness Conditions",
    description: "Comprehensive information about various health/wellness conditions, symptoms, and how to support people affected by them.",
    steps: [
      {
        title: "Browse Health/Wellness Conditions",
        content: "Explore detailed guides for conditions like TBI, dementia, EMF sensitivity, and other health/wellness challenges affecting our community.",
      },
      {
        title: "Search for Information",
        content: "Use the search bar to quickly find information about specific symptoms, conditions, or treatment approaches.",
      },
      {
        title: "Support Guidelines",
        content: "Learn how to interact with and support people living with various health conditions - what to say and what to avoid.",
      },
      {
        title: "Community Resources",
        content: "Access external resources, support groups, and educational materials for each condition covered in our guides.",
      }
    ]
  },
  "/blog": {
    title: "Blog - Share Your Health Journey",
    description: "Write about your health experiences, supplement discoveries, recovery stories, and connect with others on similar paths.",
    steps: [
      {
        title: "Create Health Posts",
        content: "Share your supplement experiences, health discoveries, recovery progress, and wellness insights with the community.",
      },
      {
        title: "Read Others' Stories",
        content: "Learn from other community members' experiences with supplements, treatments, and health strategies.",
      },
      {
        title: "Engage with Content",
        content: "Like, comment, and support other members' posts. Building connections strengthens our community.",
      },
      {
        title: "Build Your Profile",
        content: "Regular posting helps establish your presence in the community and creates valuable health documentation.",
      }
    ]
  },
  "/social": {
    title: "Social - Connect with Ordinary People Community",
    description: "Build relationships with like-minded people, find support partners, and engage in open discussions.",
    steps: [
      {
        title: "Find Community Connections",
        content: "Search for people with similar interests in government topics, health advice, personal views, or general discussions.",
      },
      {
        title: "Send Connection Requests",
        content: "Reach out to community members whose views and experiences resonate with yours. Building connections provides mutual support.",
      },
      {
        title: "Private Messaging",
        content: "Communicate directly with connections to share detailed experiences, ask specific questions, or offer support.",
      },
      {
        title: "Support Network",
        content: "Build a network of people who share your interests and can provide encouragement, advice, and open discussion on various topics.",
      }
    ]
  },
  "/community": {
    title: "Community - Discussion Forums",
    description: "Join open discussions about government topics, personal views, health advice, and share knowledge with the community.",
    steps: [
      {
        title: "Browse Discussion Topics",
        content: "Explore conversations about government issues, personal views, health advice, supplement experiences, and general topics of interest.",
      },
      {
        title: "Join Conversations",
        content: "Participate in discussions by sharing your views on government, personal experiences, health advice, and offering support to other members.",
      },
      {
        title: "Create New Discussions",
        content: "Start new topic threads about government issues, personal views, health questions, or any experiences you want to share with the community.",
      },
      {
        title: "Location-Based Groups",
        content: "Find community members in your area for local support groups, in-person meetups, or regional health resources.",
      }
    ]
  },
  "/shop": {
    title: "Shop - Health Products & Supplements",
    description: "Browse curated health products and supplements with affiliate links. Support your health journey with quality products.",
    steps: [
      {
        title: "Browse Products",
        content: "Explore supplements and health products curated by the community. Each product includes detailed information and member reviews.",
      },
      {
        title: "Product Categories",
        content: "Filter products by category (vitamins, minerals, herbs, etc.) to find supplements that match your health goals.",
      },
      {
        title: "Affiliate Support",
        content: "Purchases through our affiliate links help support the GoHealMe community while getting you quality health products.",
      },
      {
        title: "Add to Your Regimen",
        content: "After purchasing, easily add new supplements to your tracking regimen to monitor their effects on your health.",
      }
    ]
  },
  "/profile": {
    title: "Profile - Your Health Identity",
    description: "Manage your personal information, upload photos, track your health journey, and showcase your wellness progress.",
    steps: [
      {
        title: "Personal Information",
        content: "Update your profile with health goals, current challenges, and background information to help others understand your journey.",
      },
      {
        title: "Photo Gallery",
        content: "Upload photos of your progress, supplement setups, healthy meals, or recovery milestones to document your health journey.",
      },
      {
        title: "Health Stats",
        content: "View your supplement compliance, posting activity, and community engagement statistics to track your platform usage.",
      },
      {
        title: "Privacy Settings",
        content: "Control who can see your information, connect with you, and access your health data to maintain your desired privacy level.",
      }
    ]
  }
};

export function NavigationHelp() {
  // Component disabled to prevent dialog conflicts with UniversalInstructionsButton
  return null;

  const currentTutorial = tutorials[location];

  useEffect(() => {
    // Check if user has seen tutorial for this page
    const seenTutorials = JSON.parse(localStorage.getItem('seenTutorials') || '{}');
    setHasSeenTutorial(seenTutorials);
  }, []);

  const markTutorialAsSeen = (path: string) => {
    const updated = { ...hasSeenTutorial, [path]: true };
    setHasSeenTutorial(updated);
    localStorage.setItem('seenTutorials', JSON.stringify(updated));
  };

  const openTutorial = () => {
    setCurrentStep(0);
    setIsOpen(true);
  };

  const closeTutorial = () => {
    setIsOpen(false);
    markTutorialAsSeen(location);
  };

  const nextStep = () => {
    if (currentTutorial && currentStep < currentTutorial.steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      closeTutorial();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  if (!currentTutorial) return null;

  return (
    <>
      {/* Help Button - Repositioned to avoid overlap with mobile nav */}
      <div className="fixed bottom-20 right-4 lg:bottom-4 lg:right-4 z-40">
        <Button
          onClick={openTutorial}
          className="rounded-full w-12 h-12 bg-blue-600 hover:bg-blue-700 shadow-lg"
          size="sm"
        >
          <HelpCircle className="w-5 h-5" />
        </Button>
        {!hasSeenTutorial[location] && (
          <div className="absolute -top-2 -right-2">
            <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse" />
          </div>
        )}
      </div>

      {/* Tutorial Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle className="text-xl font-bold text-gray-900">
                {currentTutorial.title}
              </DialogTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={closeTutorial}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <DialogDescription className="text-gray-600 mt-2">
              {currentTutorial.description}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Progress Indicator */}
            <div className="flex items-center justify-between">
              <div className="flex space-x-2">
                {currentTutorial.steps.map((_, index) => (
                  <div
                    key={index}
                    className={`w-3 h-3 rounded-full ${
                      index === currentStep
                        ? "bg-blue-600"
                        : index < currentStep
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  />
                ))}
              </div>
              <Badge variant="outline">
                Step {currentStep + 1} of {currentTutorial.steps.length}
              </Badge>
            </div>

            {/* Current Step Content */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  {currentStep === currentTutorial.steps.length - 1 ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <div className="w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
                      {currentStep + 1}
                    </div>
                  )}
                  {currentTutorial.steps[currentStep].title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  {currentTutorial.steps[currentStep].content}
                </p>
                {currentTutorial.steps[currentStep].action && (
                  <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-blue-800 font-medium">
                      💡 Try this: {currentTutorial.steps[currentStep].action}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Navigation Buttons */}
            <div className="flex justify-between">
              <Button
                variant="outline"
                onClick={prevStep}
                disabled={currentStep === 0}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>

              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  onClick={closeTutorial}
                >
                  Skip Tutorial
                </Button>
                <Button onClick={nextStep}>
                  {currentStep === currentTutorial.steps.length - 1 ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Complete
                    </>
                  ) : (
                    <>
                      Next
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}