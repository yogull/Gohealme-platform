import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { 
  Play, Image, Video, Heart, MessageCircle, Share2, 
  Eye, Grid3X3, List, Settings, ChevronDown 
} from 'lucide-react';
import GallerySelector from './GallerySelector';
import GalleryViewer from './GalleryViewer';

interface GalleryItem {
  id: number;
  caption?: string;
  likes: number;
  shares: number;
  views: number;
  createdAt: string;
  file: {
    id: number;
    mimeType: string;
    fileData: string;
    originalName: string;
  };
}

interface Gallery {
  id: number;
  name: string;
  description?: string;
  isDefault: boolean;
  privacyLevel: string;
  itemCount: number;
}

interface EnhancedGalleryProps {
  userId: number;
  isOwner: boolean;
  onUpload?: (galleryId: number) => void;
}

export default function EnhancedGallery({ userId, isOwner, onUpload }: EnhancedGalleryProps) {
  const { toast } = useToast();
  const [selectedGalleryId, setSelectedGalleryId] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [viewerItemId, setViewerItemId] = useState<number | null>(null);
  const [showAllGalleries, setShowAllGalleries] = useState(false);

  // Fetch user galleries
  const { data: galleries = [] } = useQuery({
    queryKey: ['/api/galleries', userId],
    queryFn: async () => {
      const response = await fetch(`/api/galleries/user/${userId}`);
      if (!response.ok) throw new Error('Failed to fetch galleries');
      return response.json();
    }
  });

  // Fetch items for selected gallery
  const { data: galleryItems = [], isLoading: itemsLoading } = useQuery({
    queryKey: ['/api/galleries', selectedGalleryId, 'items'],
    queryFn: async () => {
      const response = await fetch(`/api/galleries/${selectedGalleryId}/items`);
      if (!response.ok) throw new Error('Failed to fetch gallery items');
      return response.json();
    },
    enabled: !!selectedGalleryId
  });

  // Auto-select default gallery
  React.useEffect(() => {
    if (galleries.length > 0 && !selectedGalleryId) {
      const defaultGallery = galleries.find((g: Gallery) => g.isDefault) || galleries[0];
      setSelectedGalleryId(defaultGallery.id);
    }
  }, [galleries, selectedGalleryId]);

  const handleItemClick = (itemId: number) => {
    setViewerItemId(itemId);
    setIsViewerOpen(true);
  };

  const currentGallery = galleries.find((g: Gallery) => g.id === selectedGalleryId);

  const displayedGalleries = showAllGalleries ? galleries : galleries.slice(0, 3);

  return (
    <div className="space-y-4">
      {/* Gallery Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">My Photos & Videos</h2>
      </div>

      {/* Gallery Selector */}
      {isOwner && (
        <div className="flex flex-col space-y-3 sm:space-y-0 sm:flex-row sm:items-center sm:justify-between">
          <div className="w-full sm:w-auto">
            <GallerySelector
              userId={userId}
              onGallerySelect={setSelectedGalleryId}
              selectedGalleryId={selectedGalleryId || undefined}
            />
          </div>
          {currentGallery && onUpload && (
            <Button
              onClick={() => onUpload(currentGallery.id)}
              size="sm"
              className="bg-green-600 hover:bg-green-700 w-full sm:w-auto"
            >
              Upload to {currentGallery.name}
            </Button>
          )}
        </div>
      )}

      {/* Gallery Items */}
      {currentGallery && (
        <div className="space-y-4">

          {itemsLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="aspect-square bg-gray-200 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : galleryItems.length > 0 ? (
            <div className={
              viewMode === 'grid' 
                ? "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 sm:gap-4"
                : "space-y-4"
            }>
              {galleryItems.map((item: GalleryItem) => {
                const isVideo = item.file.mimeType.startsWith('video');
                const fileUrl = `data:${item.file.mimeType};base64,${item.file.fileData}`;

                return viewMode === 'grid' ? (
                  <div
                    key={item.id}
                    className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden cursor-pointer group hover:shadow-lg transition-all"
                    onClick={() => handleItemClick(item.id)}
                  >
                    {isVideo ? (
                      <div className="relative w-full h-full">
                        <video
                          src={fileUrl}
                          className="w-full h-full object-cover"
                          muted
                        />
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Play className="h-8 w-8 text-white" />
                        </div>
                        <div className="absolute top-2 right-2">
                          <Video className="h-4 w-4 text-white drop-shadow-lg" />
                        </div>
                      </div>
                    ) : (
                      <div className="relative w-full h-full">
                        <img
                          src={fileUrl}
                          alt={item.caption || item.file.originalName}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2 right-2">
                          <Image className="h-4 w-4 text-white drop-shadow-lg" />
                        </div>
                      </div>
                    )}

                    {/* Item stats overlay */}
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2">
                      <div className="flex items-center justify-between text-white text-xs">
                        <div className="flex items-center space-x-2">
                          <span className="flex items-center">
                            <Heart className="h-3 w-3 mr-1" />
                            {item.likes}
                          </span>
                          <span className="flex items-center">
                            <Eye className="h-3 w-3 mr-1" />
                            {item.views}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <Card key={item.id} className="cursor-pointer hover:shadow-md transition-all">
                    <CardContent className="p-4">
                      <div className="flex space-x-4">
                        <div className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                          {isVideo ? (
                            <video
                              src={fileUrl}
                              className="w-full h-full object-cover"
                              muted
                            />
                          ) : (
                            <img
                              src={fileUrl}
                              alt={item.caption || item.file.originalName}
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium text-sm truncate">
                              {item.caption || item.file.originalName}
                            </h4>
                            <div className="flex items-center">
                              {isVideo ? (
                                <Video className="h-4 w-4 text-gray-400" />
                              ) : (
                                <Image className="h-4 w-4 text-gray-400" />
                              )}
                            </div>
                          </div>
                          <p className="text-xs text-gray-500 mb-2">
                            {new Date(item.createdAt).toLocaleDateString()}
                          </p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <span className="flex items-center">
                              <Heart className="h-3 w-3 mr-1" />
                              {item.likes}
                            </span>
                            <span className="flex items-center">
                              <MessageCircle className="h-3 w-3 mr-1" />
                              0
                            </span>
                            <span className="flex items-center">
                              <Share2 className="h-3 w-3 mr-1" />
                              {item.shares}
                            </span>
                            <span className="flex items-center">
                              <Eye className="h-3 w-3 mr-1" />
                              {item.views}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Image className="h-16 w-16 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-600 mb-2">No items in this gallery</h3>
              <p className="text-gray-500">
                {isOwner 
                  ? "Upload your first photo or video to get started" 
                  : "This gallery is empty"
                }
              </p>
            </div>
          )}
        </div>
      )}

      {/* Gallery Viewer Modal */}
      {selectedGalleryId && (
        <GalleryViewer
          isOpen={isViewerOpen}
          onClose={() => setIsViewerOpen(false)}
          galleryId={selectedGalleryId}
          initialItemId={viewerItemId || undefined}
          currentUserId={userId}
        />
      )}
    </div>
  );
}