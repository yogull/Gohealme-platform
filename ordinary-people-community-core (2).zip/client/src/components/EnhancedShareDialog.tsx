import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Youtube, 
  Send,
  Users,
  Globe,
  Camera,
  Music,
  Video,
  Code,
  Palette,
  Phone,
  Edit,
  Hash,
  Copy,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface EnhancedShareDialogProps {
  isOpen: boolean;
  onClose: () => void;
  content: {
    title: string;
    text: string;
    url: string;
  };
}

export function EnhancedShareDialog({ isOpen, onClose, content }: EnhancedShareDialogProps) {
  const { toast } = useToast();
  const [showAllPlatforms, setShowAllPlatforms] = useState(false);

  // Main platforms shown by default
  const mainPlatforms = [
    {
      name: 'Facebook',
      icon: Facebook,
      color: 'bg-blue-600 hover:bg-blue-700',
      shareUrl: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(content.url)}&quote=${encodeURIComponent(content.text)}`
    },
    {
      name: 'Twitter',
      icon: Twitter,
      color: 'bg-sky-500 hover:bg-sky-600',
      shareUrl: `https://twitter.com/intent/tweet?text=${encodeURIComponent(content.text)}&url=${encodeURIComponent(content.url)}`
    },
    {
      name: 'LinkedIn',
      icon: Linkedin,
      color: 'bg-blue-700 hover:bg-blue-800',
      shareUrl: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(content.url)}&title=${encodeURIComponent(content.title)}`
    },
    {
      name: 'WhatsApp',
      icon: Phone,
      color: 'bg-green-500 hover:bg-green-600',
      shareUrl: `https://wa.me/?text=${encodeURIComponent(content.text + ' ' + content.url)}`
    }
  ];

  // Additional platforms shown when expanded
  const additionalPlatforms = [
    {
      name: 'Instagram',
      icon: Instagram,
      color: 'bg-gradient-to-r from-purple-500 to-pink-500',
      shareUrl: 'https://www.instagram.com/'
    },
    {
      name: 'YouTube',
      icon: Youtube,
      color: 'bg-red-600 hover:bg-red-700',
      shareUrl: 'https://www.youtube.com/'
    },
    {
      name: 'TikTok',
      icon: Music,
      color: 'bg-black hover:bg-gray-800',
      shareUrl: 'https://www.tiktok.com/'
    },
    {
      name: 'Snapchat',
      icon: Camera,
      color: 'bg-yellow-500 hover:bg-yellow-600',
      shareUrl: 'https://www.snapchat.com/'
    },
    {
      name: 'Discord',
      icon: Users,
      color: 'bg-indigo-600 hover:bg-indigo-700',
      shareUrl: 'https://discord.com/'
    },
    {
      name: 'Reddit',
      icon: Globe,
      color: 'bg-orange-600 hover:bg-orange-700',
      shareUrl: `https://www.reddit.com/submit?url=${encodeURIComponent(content.url)}&title=${encodeURIComponent(content.title)}`
    },
    {
      name: 'Pinterest',
      icon: Palette,
      color: 'bg-red-500 hover:bg-red-600',
      shareUrl: `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(content.url)}&description=${encodeURIComponent(content.text)}`
    },
    {
      name: 'Tumblr',
      icon: Globe,
      color: 'bg-blue-900 hover:bg-blue-950',
      shareUrl: `https://www.tumblr.com/widgets/share/tool?canonicalUrl=${encodeURIComponent(content.url)}&title=${encodeURIComponent(content.title)}`
    },
    {
      name: 'Twitch',
      icon: Video,
      color: 'bg-purple-600 hover:bg-purple-700',
      shareUrl: 'https://www.twitch.tv/'
    },
    {
      name: 'Medium',
      icon: Edit,
      color: 'bg-gray-800 hover:bg-gray-900',
      shareUrl: 'https://medium.com/'
    },
    {
      name: 'GitHub',
      icon: Code,
      color: 'bg-gray-900 hover:bg-black',
      shareUrl: 'https://github.com/'
    },
    {
      name: 'Telegram',
      icon: Send,
      color: 'bg-blue-500 hover:bg-blue-600',
      shareUrl: `https://t.me/share/url?url=${encodeURIComponent(content.url)}&text=${encodeURIComponent(content.text)}`
    },
    {
      name: 'Spotify',
      icon: Music,
      color: 'bg-green-600 hover:bg-green-700',
      shareUrl: 'https://open.spotify.com/'
    },
    {
      name: 'Vimeo',
      icon: Video,
      color: 'bg-blue-500 hover:bg-blue-600',
      shareUrl: 'https://vimeo.com/'
    },
    {
      name: 'Flickr',
      icon: Camera,
      color: 'bg-pink-600 hover:bg-pink-700',
      shareUrl: 'https://www.flickr.com/'
    },
    {
      name: 'Skype',
      icon: Phone,
      color: 'bg-blue-400 hover:bg-blue-500',
      shareUrl: 'https://web.skype.com/'
    }
  ];

  const handlePlatformShare = (platform: any) => {
    if (platform.shareUrl.includes('instagram.com') || platform.shareUrl.includes('tiktok.com') || 
        platform.shareUrl.includes('youtube.com') || platform.shareUrl.includes('snapchat.com') ||
        platform.shareUrl.includes('discord.com') || platform.shareUrl.includes('twitch.tv') ||
        platform.shareUrl.includes('medium.com') || platform.shareUrl.includes('github.com') ||
        platform.shareUrl.includes('spotify.com') || platform.shareUrl.includes('vimeo.com') ||
        platform.shareUrl.includes('flickr.com') || platform.shareUrl.includes('skype.com')) {
      // For platforms without direct URL sharing, open platform and copy text
      window.open(platform.shareUrl, '_blank');
      navigator.clipboard.writeText(content.text + ' ' + content.url);
      toast({ 
        title: `Opening ${platform.name}`, 
        description: "Content copied to clipboard - paste it in the app!" 
      });
    } else {
      // For platforms with direct URL sharing
      window.open(platform.shareUrl, '_blank', 'width=600,height=400');
      toast({ 
        title: `Shared to ${platform.name}`, 
        description: "Opening share dialog" 
      });
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(content.url);
    toast({ 
      title: "Link copied!", 
      description: "Share link copied to clipboard" 
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto">
        <DialogHeader>
          <DialogTitle className="text-center">Share Content</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Main platforms - always visible */}
          <div className="grid grid-cols-2 gap-3">
            {mainPlatforms.map((platform) => {
              const Icon = platform.icon;
              return (
                <button
                  key={platform.name}
                  onClick={() => handlePlatformShare(platform)}
                  className={`flex items-center justify-center gap-2 p-3 text-white rounded-lg transition-colors ${platform.color}`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{platform.name}</span>
                </button>
              );
            })}
          </div>

          {/* Choose different platform button */}
          <button
            onClick={() => setShowAllPlatforms(!showAllPlatforms)}
            className="w-full flex items-center justify-center gap-2 p-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
          >
            <span className="text-sm font-medium">Choose a different platform</span>
            {showAllPlatforms ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </button>

          {/* Additional platforms - shown when expanded */}
          {showAllPlatforms && (
            <div className="grid grid-cols-2 gap-2 pt-2 border-t">
              {additionalPlatforms.map((platform) => {
                const Icon = platform.icon;
                return (
                  <button
                    key={platform.name}
                    onClick={() => handlePlatformShare(platform)}
                    className={`flex items-center justify-center gap-2 p-2 text-white rounded-lg transition-colors text-xs ${platform.color}`}
                  >
                    <Icon className="w-3 h-3" />
                    <span className="font-medium">{platform.name}</span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Copy link button - separate card */}
          <div className="border-t pt-4">
            <button
              onClick={handleCopyLink}
              className="w-full flex items-center justify-center gap-2 p-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg transition-colors border border-blue-200"
            >
              <Copy className="w-4 h-4" />
              <span className="text-sm font-medium">Copy Link</span>
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}