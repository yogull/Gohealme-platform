import React, { useState } from 'react';
import { MessageCircle, Brain, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

interface ClaudeBrainButtonProps {
  variant?: 'default' | 'compact' | 'floating';
  className?: string;
  position?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
}

export function ClaudeBrainButton({ 
  variant = 'default', 
  className = '',
  position = 'bottom-right'
}: ClaudeBrainButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [question, setQuestion] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState('');
  const { toast } = useToast();

  const handleAskClaude = async () => {
    if (!question.trim()) {
      toast({
        title: "Please ask a question",
        description: "Type your question before submitting",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/claude-brain/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: question.trim() })
      });

      if (!res.ok) {
        throw new Error('Failed to get response');
      }

      const data = await res.json();
      setResponse(data.response || 'I received your question and am processing it.');
      
      toast({
        title: "Claude Brain Response",
        description: "Got a response from Claude Brain",
      });
    } catch (error) {
      console.error('Claude Brain error:', error);
      setResponse("I'm currently having trouble connecting. Let me try to help you anyway - what specifically would you like to know about the platform?");
    } finally {
      setIsLoading(false);
    }
  };

  const positionClasses = {
    'top-left': 'fixed top-4 left-4 z-50',
    'top-right': 'fixed top-4 right-4 z-50',
    'bottom-left': 'fixed bottom-4 left-4 z-50',
    'bottom-right': 'fixed bottom-4 right-4 z-50'
  };

  if (variant === 'floating') {
    return (
      <div className={`${positionClasses[position]} ${className}`}>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button 
              size="lg"
              className="rounded-full shadow-lg bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
            >
              <Brain className="h-5 w-5 mr-2" />
              Ask Claude
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-purple-600" />
                Claude Brain Assistant
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Textarea
                placeholder="Ask Claude anything about the platform, features, or get help..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="min-h-[100px]"
              />
              <Button 
                onClick={handleAskClaude} 
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                {isLoading ? 'Thinking...' : 'Ask Claude'}
              </Button>
              {response && (
                <div className="p-4 bg-gray-50 rounded-lg border">
                  <p className="text-sm text-gray-700">{response}</p>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button 
            size="sm" 
            variant="outline"
            className={`bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200 hover:from-purple-100 hover:to-blue-100 ${className}`}
          >
            <Brain className="h-4 w-4 mr-1" />
            Claude
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-purple-600" />
              Claude Brain Assistant
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="Ask Claude anything..."
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              className="min-h-[80px]"
            />
            <Button 
              onClick={handleAskClaude} 
              disabled={isLoading}
              size="sm"
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {isLoading ? 'Thinking...' : 'Ask'}
            </Button>
            {response && (
              <div className="p-3 bg-gray-50 rounded-lg border">
                <p className="text-xs text-gray-700">{response}</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Default variant
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          className={`bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white ${className}`}
        >
          <Brain className="h-5 w-5 mr-2" />
          Ask Claude Brain
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-600" />
            Claude Brain Assistant
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Textarea
            placeholder="Ask Claude anything about the platform, troubleshooting, features, or get personalized help..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            className="min-h-[120px]"
          />
          <Button 
            onClick={handleAskClaude} 
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            {isLoading ? (
              <>
                <MessageCircle className="h-4 w-4 mr-2 animate-spin" />
                Claude is thinking...
              </>
            ) : (
              <>
                <Brain className="h-4 w-4 mr-2" />
                Ask Claude Brain
              </>
            )}
          </Button>
          {response && (
            <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200">
              <div className="flex items-start gap-2">
                <Sparkles className="h-4 w-4 text-purple-600 mt-1 flex-shrink-0" />
                <p className="text-sm text-gray-700">{response}</p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}