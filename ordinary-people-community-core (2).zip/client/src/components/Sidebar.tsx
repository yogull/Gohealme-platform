import { User } from "@shared/schema";
import { signOut } from "@/lib/auth";
import { useLocation } from "wouter";
import { LanguageSelector } from "./LanguageSelector";
import { ShareButton } from "@/components/ShareButton";
import { AskAIButton } from "@/components/AskAIButton";
import { LogOut, Phone, Video } from "lucide-react";
import { useTranslation } from "@/hooks/useTranslation";
import NotificationCenter from "@/components/NotificationCenter";

interface SidebarProps {
  user: User;
}

export function Sidebar({ user }: SidebarProps) {
  const [location, setLocation] = useLocation();
  const { t } = useTranslation();
  
  const handleSignOut = async () => {
    try {
      await signOut();
      // Clear any cached user data
      localStorage.clear();
      sessionStorage.clear();
      // Force page reload to ensure clean state
      window.location.href = "/login";
    } catch (error) {
      console.error("Sign out failed:", error);
      // Fallback: force redirect even if sign out fails
      window.location.href = "/login";
    }
  };

  const baseNavItems = [
    { href: "/profile", icon: "fas fa-user-cog", label: t('nav.profileSettings'), active: location === "/profile" },
    { href: "/profile-wall", icon: "fas fa-user", label: "Profile Wall", active: location === "/profile-wall" },
    { href: "/", icon: "fas fa-chart-line", label: t('nav.dashboard'), active: location === "/" },
    { href: "/personal-shop", icon: "fas fa-store", label: "My Personal Shop", active: location === "/personal-shop" },
    { href: "/personal-shop-search", icon: "fas fa-search", label: "Search Personal Shops", active: location === "/personal-shop-search" },
    { href: "/health-hub", icon: "fas fa-heartbeat", label: "Health", active: location.includes("/supplements") || location.includes("/daily-log") || location.includes("/biometrics") || location.includes("/illness-guides") || location === "/health-hub" },
    { href: "/business-directory", icon: "fas fa-building", label: "Business Directory", active: location === "/business-directory" },
    { href: "/business-profile", icon: "fas fa-building", label: "Business Profile", active: location === "/business-profile" },
    { href: "/location-ads", icon: "fas fa-map-marker-alt", label: "Find Local Businesses", active: location === "/location-ads" },
    { href: "/daily-news", icon: "fas fa-newspaper", label: "Daily News", active: location === "/daily-news" },
    { href: "/social", icon: "fas fa-users", label: t('nav.social'), active: location === "/social" },
    { href: "/community", icon: "fas fa-comments", label: "Community Blog", active: location === "/community" },
    { href: "/shop", icon: "fas fa-shopping-cart", label: t('nav.shop'), active: location === "/shop" },
    { href: "/about", icon: "fas fa-info-circle", label: "About Us", active: location === "/about" },
    { href: "/contact", icon: "fas fa-envelope", label: t('nav.contact'), active: location === "/contact" },
  ];

  // For admin users, insert Admin link and reorganize menu to match mobile
  const navItems = user.isAdmin 
    ? [
        { href: "/profile", icon: "fas fa-user-cog", label: t('nav.profileSettings'), active: location === "/profile" },
        { href: "/profile-wall", icon: "fas fa-user", label: "Profile Wall", active: location === "/profile-wall" },
        { href: "/business-profile", icon: "fas fa-building", label: "Business Profile", active: location === "/business-profile" },
        { href: "/", icon: "fas fa-chart-line", label: t('nav.dashboard'), active: location === "/" },
        { href: "/personal-shop", icon: "fas fa-store", label: "My Personal Shop", active: location === "/personal-shop" },
        { href: "/personal-shop-search", icon: "fas fa-search", label: "Search Personal Shops", active: location === "/personal-shop-search" },
        { href: "/health-hub", icon: "fas fa-heartbeat", label: "Health", active: location.includes("/supplements") || location.includes("/daily-log") || location.includes("/biometrics") || location.includes("/illness-guides") || location === "/health-hub" },
        { href: "/business-directory", icon: "fas fa-building", label: "Business Directory", active: location === "/business-directory" },
        { href: "/location-ads", icon: "fas fa-map-marker-alt", label: "Find Local Businesses", active: location === "/location-ads" },
        { href: "/daily-news", icon: "fas fa-newspaper", label: "Daily News", active: location === "/daily-news" },
        { href: "/social", icon: "fas fa-users", label: t('nav.social'), active: location === "/social" },
        { href: "/community", icon: "fas fa-comments", label: "Community Blog", active: location === "/community" },
        { href: "/shop", icon: "fas fa-shopping-cart", label: t('nav.shop'), active: location === "/shop" },
        { href: "/admin-dashboard", icon: "fas fa-shield-alt", label: "Admin Dashboard", active: location === "/admin-dashboard" || location === "/super-admin" || location === "/admin" },
        { href: "/about", icon: "fas fa-info-circle", label: "About Us", active: location === "/about" },
        { href: "/contact", icon: "fas fa-envelope", label: t('nav.contact'), active: location === "/contact" },
      ]
    : baseNavItems;



  return (
    <aside className="hidden lg:block w-64 bg-white shadow-sm border-r border-gray-200 h-screen flex flex-col">
      <div className="p-6 border-b border-gray-200 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-lg overflow-hidden border-2 border-primary">
              <img 
                src="/yogull-health.jpg" 
                alt="Yogull.com / GoHealMe"
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  target.parentElement!.innerHTML = '<div class="w-full h-full bg-primary flex items-center justify-center text-white font-bold text-xl">Y</div>';
                }}
              />
            </div>
            <div>
              <h1 className="font-bold text-xl text-primary-dark">Ordinary People</h1>
              <p className="text-sm text-primary font-medium">Community</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <NotificationCenter user={user} />
            <LanguageSelector variant="compact" />
          </div>
        </div>
      </div>
      
      {/* Large Share Button */}
      <div className="px-4 py-3 border-b border-gray-200">
        <ShareButton className="w-full" />
      </div>
      
      {/* Ask AI Anything Button */}
      <div className="px-4 py-3 border-b border-gray-200">
        <AskAIButton 
          variant="default" 
          size="default" 
          className="w-full bg-orange-500 hover:bg-orange-600 text-white border-none shadow-md"
        />
      </div>
      
      {/* Go to Profile Button */}
      <div className="px-4 py-3 border-b border-gray-200">
        <a
          href={`/profile-wall/${user.id}`}
          className="flex items-center justify-center space-x-2 w-full px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors font-medium"
        >
          <i className="fas fa-user text-lg"></i>
          <span>Go to Profile</span>
        </a>
      </div>
      
      {/* WhatsApp and Messenger Communication Buttons */}
      <div className="px-4 py-3 border-b border-gray-200">
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              // For mobile devices, try direct WhatsApp calling
              if (/Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                // Try direct WhatsApp call protocol first, fallback to message
                try {
                  window.open('whatsapp://call?phone=447711776304', '_blank');
                } catch (e) {
                  // Fallback to WhatsApp with call request message
                  window.open('whatsapp://send?phone=447711776304&text=Please%20call%20me', '_blank');
                }
              } else {
                // For desktop, open WhatsApp Web with direct call option
                window.open('https://web.whatsapp.com/send?phone=447711776304&text=Please%20call%20me%20-%20clicking%20this%20for%20voice%20call', '_blank');
              }
            }}
            className="flex items-center justify-center gap-2 px-3 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg font-medium text-sm transition-colors"
          >
            <Phone className="w-4 h-4" />
            Call WhatsApp
          </button>
          <button
            onClick={() => {
              // For mobile devices, try Messenger app with video call intent
              if (/Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                // Try to open Messenger with video call intent
                window.open('fb-messenger://user/100000000000000', '_blank');
              } else {
                // For desktop, open Messenger Web
                window.open('https://www.messenger.com/', '_blank');
              }
            }}
            className="flex items-center justify-center gap-2 px-3 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-medium text-sm transition-colors"
          >
            <Video className="w-4 h-4" />
            Video Call
          </button>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {navItems.map((item) => (
          <a
            key={item.href}
            href={item.href}
            className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
              item.active
                ? "bg-primary-light text-primary-dark font-semibold"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            <i className={`${item.icon} text-lg`}></i>
            <span>{item.label}</span>
          </a>
        ))}
        
        {/* Chat Buttons */}
        <div className="px-4 pb-4 space-y-2">
          <a
            href="/chat"
            className="flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors bg-primary hover:bg-primary/90 text-white"
          >
            <i className="fas fa-users text-lg"></i>
            <span className="font-medium">Chat with Users</span>
          </a>
          
          <a
            href="/chat?ai=true"
            className="flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors bg-blue-900 hover:bg-blue-800 text-white"
          >
            <i className="fas fa-robot text-lg"></i>
            <span className="font-medium">Chat with AI</span>
          </a>
        </div>
      </nav>
      

      
      <div className="p-4 flex-shrink-0">
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <span className="text-white font-semibold text-sm">
                {user?.name?.charAt(0)?.toUpperCase() || 'U'}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm text-gray-900">{user?.name || 'User'}</p>
              <p className="text-xs text-gray-500 truncate">{user?.email || ''}</p>
            </div>
          </div>
          <button 
            onClick={handleSignOut}
            className="w-full mt-3 py-2 px-3 bg-red-50 text-red-600 rounded-md text-sm font-medium hover:bg-red-100 transition-colors flex items-center justify-center"
          >
            <LogOut className="w-4 h-4 mr-2" />
            {t('nav.signOut')}
          </button>
        </div>
      </div>

    </aside>
  );
}
