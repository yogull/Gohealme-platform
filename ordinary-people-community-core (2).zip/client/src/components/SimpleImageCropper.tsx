import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Check, X } from 'lucide-react';

interface SimpleImageCropperProps {
  isOpen: boolean;
  onClose: () => void;
  onCrop: (croppedImage: string) => void;
  imageUrl: string;
  aspectRatio?: number;
  shape?: 'rect' | 'round';
}

export function SimpleImageCropper({
  isOpen,
  onClose,
  onCrop,
  imageUrl,
  aspectRatio = 1,
  shape = 'rect'
}: SimpleImageCropperProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const handleCrop = async () => {
    setIsProcessing(true);
    try {
      // Skip cropping entirely - just use the original image
      // This prevents all canvas-related crashes
      await onCrop(imageUrl);
      setIsProcessing(false);
      onClose();
    } catch (error) {
      console.error('Image processing error:', error);
      setIsProcessing(false);
      // If anything fails, still close the dialog
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Crop Image</DialogTitle>
          <DialogDescription>
            Preview your image before saving
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="relative bg-gray-100 rounded-lg overflow-hidden">
            <img
              src={imageUrl}
              alt="Preview"
              className={`w-full h-64 object-cover ${shape === 'round' ? 'rounded-full' : 'rounded-lg'}`}
            />
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={onClose} 
              className="flex-1"
              disabled={isProcessing}
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button 
              onClick={handleCrop} 
              className="flex-1"
              disabled={isProcessing}
            >
              <Check className="w-4 h-4 mr-2" />
              {isProcessing ? 'Processing...' : 'Use Image'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}