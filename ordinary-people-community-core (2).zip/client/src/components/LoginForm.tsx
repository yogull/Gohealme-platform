import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { signIn, signUp, resendVerificationEmail, resetPassword } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/hooks/useTranslation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Leaf, Loader2, Mail } from "lucide-react";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const signUpSchema = loginSchema.extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormData = z.infer<typeof loginSchema>;
type SignUpFormData = z.infer<typeof signUpSchema>;

interface LoginFormProps {
  onSuccess: () => void;
}

export function LoginForm({ onSuccess }: LoginFormProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showResendVerification, setShowResendVerification] = useState(false);
  const [pendingVerificationEmail, setPendingVerificationEmail] = useState("");
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const { toast } = useToast();
  const { t, language } = useTranslation();



  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const signUpForm = useForm<SignUpFormData>({
    resolver: zodResolver(signUpSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  const handleLogin = async (data: LoginFormData) => {
    setIsLoading(true);
    try {
      const user = await signIn(data.email, data.password);
      console.log("Sign in successful:", user.uid);
      toast({
        title: "Welcome back!",
        description: "You've been successfully signed in.",
      });
      // Force immediate navigation to dashboard
      window.location.href = '/dashboard';
    } catch (error: any) {
      console.error("Sign in error:", error);
      // Check if error is about email verification
      if (error.message.includes("verify your email")) {
        setPendingVerificationEmail(data.email);
        setShowResendVerification(true);
        toast({
          title: "Email Verification Required",
          description: "Please check your email and click the verification link to activate your account.",
          variant: "destructive",
          duration: 8000,
        });
      } else {
        toast({
          title: "Sign in failed",
          description: error.message || "Please check your credentials and try again.",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUp = async (data: SignUpFormData) => {
    setIsLoading(true);
    try {
      const result = await signUp(data.email, data.password, data.name, language);
      
      // Account created successfully - show success message
      toast({
        title: "Account Created Successfully!",
        description: "Welcome to Ordinary People Community! You can now sign in and start using the platform.",
        duration: 6000,
      });
      
      // Auto-switch to sign in mode for immediate access
      setIsSignUp(false);
      signUpForm.reset();
      
      // Pre-fill login form with the email they just used
      loginForm.setValue("email", data.email);
      
      // Show helpful message about platform features immediately
      toast({
        title: "Ready to Explore!",
        description: "Your account is active. Sign in to access discussions, AI health chat, supplement tracking, and connect with the community.",
      });
      
      if (result.needsVerification) {
        // Show verification info immediately
        alert(`Welcome to Ordinary People Community!

Your account has been created successfully. Here's what you need to do next:

CHECK YOUR EMAIL
• We've sent a verification email to: ${data.email}
• Look for an email from Ordinary People Community (check spam folder too)

CLICK THE VERIFICATION LINK
• Click the verification link in the email
• This will bring you back to the site and activate your account

THEN YOU CAN ACCESS:
• Your personal community dashboard
• Discussion forums on government and daily life topics
• Community discussions and AI health support
• Social features and profile wall
• Shop for recommended supplements

Can't find the email? Check your spam folder or contact us for help.

Welcome to the ordinary people community!`);
      } else {
        // If no verification needed, they can use the platform immediately
        setPendingVerificationEmail(data.email);
        setShowResendVerification(true);
        return;
      }
      
      onSuccess();
    } catch (error: any) {
      toast({
        title: "Sign up failed",
        description: error.message || "Failed to create account. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendVerification = async () => {
    try {
      await resendVerificationEmail();
      toast({
        title: "Verification Email Sent",
        description: `A new verification email has been sent to ${pendingVerificationEmail}`,
      });
    } catch (error: any) {
      toast({
        title: "Failed to Resend",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    }
  };

  const handleForgotPassword = async () => {
    if (!resetEmail) {
      toast({
        title: "Email Required",
        description: "Please enter your email address to reset your password.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      await resetPassword(resetEmail);
      toast({
        title: "Password Reset Email Sent",
        description: `A password reset link has been sent to ${resetEmail}. Check your email and follow the instructions.`,
        duration: 8000,
      });
      setShowForgotPassword(false);
      setResetEmail("");
    } catch (error: any) {
      toast({
        title: "Reset Failed",
        description: error.message || "Failed to send reset email. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-white shadow-lg">
        <CardHeader className="space-y-1">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 rounded-xl overflow-hidden border-2 border-primary">
              <img 
                src="/yogull-health.jpg" 
                alt="Yogull Health / GoHealMe"
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  target.parentElement!.innerHTML = '<div class="w-full h-full bg-primary flex items-center justify-center"><div class="w-6 h-6 text-white">Y</div></div>';
                }}
              />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-center text-primary-dark">
            {isSignUp ? t('createAccount') : t('welcomeBack')}
          </CardTitle>
          <CardDescription className="text-center">
            {isSignUp 
              ? t('startHealthJourney') 
              : t('signInAccess')
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isSignUp ? (
            <form onSubmit={signUpForm.handleSubmit(handleSignUp)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">{t('fullName')}</Label>
                <Input
                  id="name"
                  placeholder={t('enterFullName')}
                  {...signUpForm.register("name")}
                />
                {signUpForm.formState.errors.name && (
                  <p className="text-sm text-red-600">{signUpForm.formState.errors.name.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">{t('email')}</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder={t('enterEmail')}
                  {...signUpForm.register("email")}
                />
                {signUpForm.formState.errors.email && (
                  <p className="text-sm text-red-600">{signUpForm.formState.errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">{t('password')}</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder={t('enterPassword')}
                  {...signUpForm.register("password")}
                />
                {signUpForm.formState.errors.password && (
                  <p className="text-sm text-red-600">{signUpForm.formState.errors.password.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">{t('confirmPassword')}</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder={t('confirmPasswordPlaceholder')}
                  {...signUpForm.register("confirmPassword")}
                />
                {signUpForm.formState.errors.confirmPassword && (
                  <p className="text-sm text-red-600">{signUpForm.formState.errors.confirmPassword.message}</p>
                )}
              </div>

              <Button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700 text-white" 
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {t('common.loading')}
                  </>
                ) : (
                  t('signUp')
                )}
              </Button>
            </form>
          ) : (
            <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">{t('email')}</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder={t('enterEmail')}
                  {...loginForm.register("email")}
                />
                {loginForm.formState.errors.email && (
                  <p className="text-sm text-red-600">{loginForm.formState.errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">{t('password')}</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder={t('enterPassword')}
                  {...loginForm.register("password")}
                />
                {loginForm.formState.errors.password && (
                  <p className="text-sm text-red-600">{loginForm.formState.errors.password.message}</p>
                )}
              </div>

              {/* Forgot Password Link */}
              <div className="text-right">
                <button
                  type="button"
                  onClick={() => setShowForgotPassword(true)}
                  className="text-sm text-blue-600 hover:text-blue-800 underline"
                >
                  {t('forgotPassword')}
                </button>
              </div>

              <button 
                type="button"
                onClick={async (e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  
                  // Get form values directly from DOM
                  const emailInput = document.querySelector('input[type="email"]') as HTMLInputElement;
                  const passwordInput = document.querySelector('input[type="password"]') as HTMLInputElement;
                  
                  if (emailInput?.value && passwordInput?.value) {
                    await handleLogin({
                      email: emailInput.value,
                      password: passwordInput.value
                    });
                  } else {
                    alert('Please enter email and password');
                  }
                }}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-6 rounded-lg cursor-pointer"
                style={{ 
                  border: 'none',
                  outline: 'none',
                  pointerEvents: 'auto',
                  zIndex: 9999,
                  position: 'relative'
                }}
              >
                {isLoading ? 'Loading...' : 'SIGN IN NOW'}
              </button>
              

            </form>
          )}

          {/* Email Verification Notice */}
          {showResendVerification && (
            <div className="mt-4 p-4 border-l-4 border-yellow-400 rounded bg-yellow-50 border border-yellow-300" style={{
              backgroundColor: '#fefce8 !important',
              border: '2px solid #eab308 !important',
              opacity: '1 !important',
              zIndex: '9999'
            }}>
              <div className="flex items-center">
                <Mail className="w-5 h-5 text-yellow-600 mr-2" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-yellow-800">
                    Email Verification Required
                  </p>
                  <p className="text-sm text-yellow-700 mt-1">
                    Check your email ({pendingVerificationEmail}) for the verification link.
                  </p>
                </div>
              </div>
              <div className="mt-3">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleResendVerification}
                  className="text-yellow-800 border-yellow-400 hover:bg-yellow-100"
                  style={{
                    backgroundColor: 'white',
                    borderColor: '#eab308'
                  }}
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Resend Verification Email
                </Button>
              </div>
            </div>
          )}

          {/* Forgot Password Modal */}
          {showForgotPassword && (
            <div className="mt-4 p-4 border-l-4 border-blue-400 rounded bg-blue-50 border border-blue-300" style={{
              backgroundColor: '#eff6ff !important',
              border: '2px solid #3b82f6 !important',
              opacity: '1 !important',
              zIndex: '9999'
            }}>
              <div className="flex items-center mb-3">
                <Mail className="w-5 h-5 text-blue-600 mr-2" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-blue-800">
                    Reset Your Password
                  </p>
                  <p className="text-sm text-blue-700 mt-1">
                    Enter your email address and we'll send you a password reset link.
                  </p>
                </div>
              </div>
              
              <div className="space-y-3">
                <Input
                  type="email"
                  placeholder="Enter your email address"
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  className="w-full"
                />
                
                <div className="flex gap-2">
                  <Button
                    type="button"
                    onClick={handleForgotPassword}
                    disabled={isLoading}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Mail className="w-4 h-4 mr-2" />
                        Send Reset Email
                      </>
                    )}
                  </Button>
                  
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowForgotPassword(false);
                      setResetEmail("");
                    }}
                    className="text-blue-800 border-blue-400"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}

          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setShowResendVerification(false);
                setPendingVerificationEmail("");
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-bold text-lg w-full transition-colors"
              disabled={isLoading}
            >
              {isSignUp 
                ? `${t('alreadyHaveAccount')} ${t('clickHereSignIn')}`
                : `${t('needAccount')} ${t('clickHereSignUp')}`
              }
            </button>
          </div>
        </CardContent>
      </Card>
  );
}
