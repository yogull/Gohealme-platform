import { useQuery } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { User } from "@shared/schema";
import { useLocation } from "wouter";

interface Notification {
  id: number;
  type: string;
  title: string;
  message: string;
  relatedUserId?: number;
  relatedUserName?: string;
  relatedPostId?: number;
  relatedCategoryId?: number;
  relatedCategoryName?: string;
  isRead: boolean;
  createdAt: string;
}

interface NotificationCenterProps {
  user: User;
}

export default function NotificationCenter({ user }: NotificationCenterProps) {
  const [, setLocation] = useLocation();

  const { data: notificationList = [] } = useQuery({
    queryKey: [`/api/notifications/${user.id}`],
    enabled: !!user,
  });

  const notifications = notificationList as Notification[];
  const unreadCount = notifications.filter((n: Notification) => !n.isRead).length;

  const handleNotificationClick = () => {
    setLocation('/notifications');
  };

  if (!user) return null;

  return (
    <div className="relative z-10">
      <button
        onClick={handleNotificationClick}
        className="relative p-2 rounded bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer z-20"
        title="View Notifications"
        type="button"
      >
        <Bell className="h-4 w-4 pointer-events-none" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 text-white rounded-full text-xs flex items-center justify-center font-bold pointer-events-none">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>
    </div>
  );
}