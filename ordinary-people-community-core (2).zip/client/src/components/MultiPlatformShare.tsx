import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Share, Facebook, Twitter, Instagram, Linkedin, Youtube, MessageCircle, Send, Github, Globe, Camera, Music, Video, Code, Palette, Users } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface MultiPlatformShareProps {
  content: string;
  url: string;
  title?: string;
  userSocialLinks?: any;
  className?: string;
}

const socialPlatforms = [
  {
    name: 'Facebook',
    key: 'facebookUrl',
    icon: Facebook,
    color: 'text-blue-600',
    shareUrl: (url: string, text: string) => `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}`
  },
  {
    name: 'Twitter',
    key: 'twitterUrl', 
    icon: Twitter,
    color: 'text-blue-400',
    shareUrl: (url: string, text: string) => `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`
  },
  {
    name: 'LinkedIn',
    key: 'linkedinUrl',
    icon: Linkedin,
    color: 'text-blue-700',
    shareUrl: (url: string, text: string) => `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}&summary=${encodeURIComponent(text)}`
  },
  {
    name: 'WhatsApp',
    key: 'whatsappUrl',
    icon: MessageCircle,
    color: 'text-green-600',
    shareUrl: (url: string, text: string) => `https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`
  },
  {
    name: 'Telegram',
    key: 'telegramUrl',
    icon: Send,
    color: 'text-blue-500',
    shareUrl: (url: string, text: string) => `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`
  },
  {
    name: 'Instagram',
    key: 'instagramUrl',
    icon: Instagram,
    color: 'text-pink-600',
    shareUrl: (url: string, text: string) => `https://www.instagram.com/` // Instagram doesn't support direct URL sharing
  },
  {
    name: 'TikTok',
    key: 'tiktokUrl',
    icon: Video,
    color: 'text-black',
    shareUrl: (url: string, text: string) => `https://www.tiktok.com/` // TikTok doesn't support direct URL sharing
  },
  {
    name: 'YouTube',
    key: 'youtubeUrl',
    icon: Youtube,
    color: 'text-red-600',
    shareUrl: (url: string, text: string) => `https://www.youtube.com/` // YouTube doesn't support direct URL sharing
  },
  {
    name: 'Snapchat',
    key: 'snapchatUrl',
    icon: Camera,
    color: 'text-yellow-500',
    shareUrl: (url: string, text: string) => `https://www.snapchat.com/` // Snapchat doesn't support direct URL sharing
  },
  {
    name: 'Discord',
    key: 'discordUrl',
    icon: Users,
    color: 'text-indigo-600',
    shareUrl: (url: string, text: string) => `https://discord.com/` // Discord doesn't support direct URL sharing
  },
  {
    name: 'Reddit',
    key: 'redditUrl',
    icon: Globe,
    color: 'text-orange-600',
    shareUrl: (url: string, text: string) => `https://www.reddit.com/submit?url=${encodeURIComponent(url)}&title=${encodeURIComponent(text)}`
  },
  {
    name: 'Pinterest',
    key: 'pinterestUrl',
    icon: Palette,
    color: 'text-red-500',
    shareUrl: (url: string, text: string) => `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(url)}&description=${encodeURIComponent(text)}`
  },
  {
    name: 'Tumblr',
    key: 'tumblrUrl',
    icon: Globe,
    color: 'text-blue-900',
    shareUrl: (url: string, text: string) => `https://www.tumblr.com/widgets/share/tool?posttype=link&title=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`
  },
  {
    name: 'Twitch',
    key: 'twitchUrl',
    icon: Video,
    color: 'text-purple-600',
    shareUrl: (url: string, text: string) => `https://www.twitch.tv/` // Twitch doesn't support direct URL sharing
  },
  {
    name: 'Spotify',
    key: 'spotifyUrl',
    icon: Music,
    color: 'text-green-600',
    shareUrl: (url: string, text: string) => `https://open.spotify.com/` // Spotify doesn't support direct URL sharing
  },
  {
    name: 'Medium',
    key: 'mediumUrl',
    icon: Globe,
    color: 'text-gray-800',
    shareUrl: (url: string, text: string) => `https://medium.com/` // Medium doesn't support direct URL sharing
  },
  {
    name: 'GitHub',
    key: 'githubUrl',
    icon: Github,
    color: 'text-gray-900',
    shareUrl: (url: string, text: string) => `https://github.com/` // GitHub doesn't support direct URL sharing
  }
];

export function MultiPlatformShare({ content, url, title = "Check this out!", userSocialLinks, className = "" }: MultiPlatformShareProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const { toast } = useToast();

  const handlePlatformToggle = (platformKey: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platformKey) 
        ? prev.filter(p => p !== platformKey)
        : [...prev, platformKey]
    );
  };

  const handleShareAll = () => {
    if (selectedPlatforms.length === 0) {
      toast({
        title: "No Platforms Selected",
        description: "Please select at least one platform to share to.",
        variant: "destructive"
      });
      return;
    }

    let sharedCount = 0;
    
    selectedPlatforms.forEach(platformKey => {
      const platform = socialPlatforms.find(p => p.key === platformKey);
      if (platform) {
        const shareUrl = platform.shareUrl(url, `${title} - ${content}`);
        
        // For platforms that support direct URL sharing, open in new window
        if (platform.name === 'Facebook' || platform.name === 'Twitter' || platform.name === 'LinkedIn' || 
            platform.name === 'WhatsApp' || platform.name === 'Telegram' || platform.name === 'Reddit' || 
            platform.name === 'Pinterest' || platform.name === 'Tumblr') {
          window.open(shareUrl, '_blank', 'width=600,height=400');
          sharedCount++;
        } else {
          // For platforms without direct sharing, copy to clipboard and open platform
          navigator.clipboard.writeText(`${title} - ${content} ${url}`);
          window.open(shareUrl, '_blank');
          sharedCount++;
        }
      }
    });

    toast({
      title: "Shared Successfully!",
      description: `Content shared to ${sharedCount} platform${sharedCount > 1 ? 's' : ''}. For platforms like Instagram, TikTok, and YouTube, the content has been copied to your clipboard.`,
    });
    
    setIsOpen(false);
    setSelectedPlatforms([]);
  };

  const handleShareToSingle = (platform: any) => {
    const shareUrl = platform.shareUrl(url, `${title} - ${content}`);
    
    if (platform.name === 'Facebook' || platform.name === 'Twitter' || platform.name === 'LinkedIn' || 
        platform.name === 'WhatsApp' || platform.name === 'Telegram' || platform.name === 'Reddit' || 
        platform.name === 'Pinterest' || platform.name === 'Tumblr') {
      window.open(shareUrl, '_blank', 'width=600,height=400');
    } else {
      navigator.clipboard.writeText(`${title} - ${content} ${url}`);
      window.open(shareUrl, '_blank');
      toast({
        title: "Content Copied!",
        description: `Content copied to clipboard. Paste it on ${platform.name} after the page opens.`,
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className={`${className}`}>
          <Share className="w-4 h-4 mr-2" />
          Multi-Share to All Platforms ({socialPlatforms.length})
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Share to Multiple Social Media Platforms</DialogTitle>
          <p className="text-sm text-gray-600 mt-2">
            Share your content to {socialPlatforms.length}+ social media platforms including Facebook, Twitter, Instagram, TikTok, Snapchat, Discord, Reddit, Pinterest, LinkedIn, YouTube, and more!
          </p>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="text-sm text-gray-600">
            Select platforms to share to, then click "Share to Selected" or click individual platform buttons.
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {socialPlatforms.map((platform) => {
              const Icon = platform.icon;
              const isSelected = selectedPlatforms.includes(platform.key);
              
              return (
                <div key={platform.key} className="space-y-2">
                  <div
                    className={`p-3 border rounded-lg cursor-pointer transition-all ${
                      isSelected ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => handlePlatformToggle(platform.key)}
                  >
                    <Icon className={`w-6 h-6 ${platform.color} mx-auto mb-2`} />
                    <div className="text-xs text-center font-medium">{platform.name}</div>
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full text-xs"
                    onClick={() => handleShareToSingle(platform)}
                  >
                    Share Now
                  </Button>
                </div>
              );
            })}
          </div>
          
          <div className="flex gap-4 pt-4 border-t">
            <Button
              onClick={handleShareAll}
              disabled={selectedPlatforms.length === 0}
              className="flex-1"
            >
              Share to Selected ({selectedPlatforms.length})
            </Button>
            
            <Button
              variant="outline"
              onClick={() => setSelectedPlatforms(socialPlatforms.map(p => p.key))}
              className="flex-1"
            >
              Select All
            </Button>
            
            <Button
              variant="outline"
              onClick={() => setSelectedPlatforms([])}
              className="flex-1"
            >
              Clear All
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}