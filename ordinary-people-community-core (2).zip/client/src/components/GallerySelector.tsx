import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Plus, FolderPlus } from 'lucide-react';

interface Gallery {
  id: number;
  name: string;
  description?: string;
  isDefault: boolean;
  privacyLevel: string;
  itemCount: number;
}

interface GallerySelectorProps {
  userId: number;
  onGallerySelect: (galleryId: number) => void;
  selectedGalleryId?: number;
}

export default function GallerySelector({ userId, onGallerySelect, selectedGalleryId }: GallerySelectorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newGalleryName, setNewGalleryName] = useState('');
  const [newGalleryDescription, setNewGalleryDescription] = useState('');
  const [newGalleryPrivacy, setNewGalleryPrivacy] = useState('public');

  const { data: galleries = [], isLoading } = useQuery({
    queryKey: ['/api/galleries', userId],
    queryFn: async () => {
      const response = await fetch(`/api/galleries/user/${userId}`);
      if (!response.ok) throw new Error('Failed to fetch galleries');
      return response.json();
    }
  });

  const createGalleryMutation = useMutation({
    mutationFn: async (galleryData: any) => {
      const response = await fetch('/api/galleries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(galleryData)
      });
      if (!response.ok) throw new Error('Failed to create gallery');
      return response.json();
    },
    onSuccess: (newGallery) => {
      toast({
        title: "Gallery Created",
        description: `"${newGallery.name}" has been created successfully.`
      });
      queryClient.invalidateQueries({ queryKey: ['/api/galleries', userId] });
      onGallerySelect(newGallery.id);
      setIsCreateDialogOpen(false);
      setNewGalleryName('');
      setNewGalleryDescription('');
      setNewGalleryPrivacy('public');
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Create Gallery",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleCreateGallery = () => {
    if (!newGalleryName.trim()) {
      toast({
        title: "Gallery Name Required",
        description: "Please enter a name for your gallery.",
        variant: "destructive"
      });
      return;
    }

    createGalleryMutation.mutate({
      userId,
      name: newGalleryName.trim(),
      description: newGalleryDescription.trim() || null,
      privacyLevel: newGalleryPrivacy,
      isDefault: galleries.length === 0
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center space-x-2">
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-900"></div>
        <span className="text-sm text-gray-600">Loading galleries...</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-2 w-full">
      <Select 
        value={selectedGalleryId?.toString() || ''} 
        onValueChange={(value) => onGallerySelect(parseInt(value))}
      >
        <SelectTrigger className="w-full sm:w-48">
          <SelectValue placeholder="Select a gallery" />
        </SelectTrigger>
        <SelectContent>
          {galleries.map((gallery: Gallery) => (
            <SelectItem key={gallery.id} value={gallery.id.toString()}>
              {gallery.name}
              {gallery.isDefault && " (Default)"}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" className="w-full sm:w-auto">
            <FolderPlus className="h-4 w-4 mr-1" />
            New Gallery
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Gallery</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="gallery-name">Gallery Name</Label>
              <Input
                id="gallery-name"
                placeholder="Enter gallery name"
                value={newGalleryName}
                onChange={(e) => setNewGalleryName(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="gallery-description">Description (Optional)</Label>
              <Textarea
                id="gallery-description"
                placeholder="Describe your gallery"
                value={newGalleryDescription}
                onChange={(e) => setNewGalleryDescription(e.target.value)}
                rows={2}
              />
            </div>
            <div>
              <Label htmlFor="gallery-privacy">Privacy Level</Label>
              <Select value={newGalleryPrivacy} onValueChange={setNewGalleryPrivacy}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">Public - Anyone can view</SelectItem>
                  <SelectItem value="friends">Friends Only</SelectItem>
                  <SelectItem value="private">Private - Only you</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setIsCreateDialogOpen(false)}
                disabled={createGalleryMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                onClick={handleCreateGallery}
                disabled={createGalleryMutation.isPending}
              >
                {createGalleryMutation.isPending ? 'Creating...' : 'Create Gallery'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}