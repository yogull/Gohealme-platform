import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Youtube, 
  Send,
  Users,
  Globe
} from "lucide-react";

interface ShareContent {
  title: string;
  description: string;
  url: string;
  imageUrl?: string;
}

interface MultiShareDialogProps {
  isOpen: boolean;
  onClose: () => void;
  content: ShareContent;
}

interface ConnectedUser {
  id: number;
  name: string;
  profileImageUrl?: string;
  connectedPlatforms: string[];
}

export function MultiShareDialog({ isOpen, onClose, content }: MultiShareDialogProps) {
  const { toast } = useToast();
  const { appUser } = useAuth();
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<number[]>([]);
  const [customMessage, setCustomMessage] = useState(content.title);
  const [shareToConnectedUsers, setShareToConnectedUsers] = useState(false);

  // Get connected users with social media accounts
  const { data: connectedUsers = [] } = useQuery<ConnectedUser[]>({
    queryKey: ["/api/connected-users", appUser?.id],
    enabled: !!appUser?.id,
    queryFn: async () => {
      // Mock data for now - would fetch from API
      return [
        {
          id: 1,
          name: "Sarah Mitchell",
          profileImageUrl: "/avatar1.jpg",
          connectedPlatforms: ["facebook", "twitter", "instagram"]
        },
        {
          id: 2,
          name: "Mike Johnson",
          profileImageUrl: "/avatar2.jpg",
          connectedPlatforms: ["facebook", "linkedin", "youtube"]
        },
        {
          id: 3,
          name: "Emma Davis",
          profileImageUrl: "/avatar3.jpg",
          connectedPlatforms: ["twitter", "instagram", "linkedin"]
        }
      ];
    },
  });

  const socialPlatforms = [
    { id: "facebook", name: "Facebook", icon: Facebook, color: "#1877f2" },
    { id: "twitter", name: "Twitter", icon: Twitter, color: "#1da1f2" },
    { id: "instagram", name: "Instagram", icon: Instagram, color: "#e4405f" },
    { id: "linkedin", name: "LinkedIn", icon: Linkedin, color: "#0077b5" },
    { id: "youtube", name: "YouTube", icon: Youtube, color: "#ff0000" },
  ];

  const handlePlatformToggle = (platformId: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platformId) 
        ? prev.filter(p => p !== platformId)
        : [...prev, platformId]
    );
  };

  const handleUserToggle = (userId: number) => {
    setSelectedUsers(prev => 
      prev.includes(userId) 
        ? prev.filter(u => u !== userId)
        : [...prev, userId]
    );
  };

  const handleShare = async () => {
    if (selectedPlatforms.length === 0 && (!shareToConnectedUsers || selectedUsers.length === 0)) {
      toast({
        title: "No Sharing Options Selected",
        description: "Please select at least one platform or connected user to share to.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Share to selected social media platforms
      for (const platform of selectedPlatforms) {
        await shareToSocialMedia(platform, {
          ...content,
          description: customMessage
        });
      }

      // Share to connected users' social media accounts
      if (shareToConnectedUsers && selectedUsers.length > 0) {
        for (const userId of selectedUsers) {
          const user = connectedUsers.find(u => u.id === userId);
          if (user) {
            // Share to all of this user's connected platforms
            for (const platform of user.connectedPlatforms) {
              await shareToUserSocialMedia(userId, platform, {
                ...content,
                description: `${user.name} shared: ${customMessage}`
              });
            }
          }
        }
      }

      toast({
        title: "Shared Successfully!",
        description: `Content shared to ${selectedPlatforms.length} platforms${shareToConnectedUsers ? ` and ${selectedUsers.length} connected users` : ''}.`,
      });

      onClose();
    } catch (error) {
      toast({
        title: "Sharing Failed",
        description: "Some shares may not have completed. Please try again.",
        variant: "destructive",
      });
    }
  };

  const shareToSocialMedia = async (platform: string, shareContent: ShareContent) => {
    const shareText = encodeURIComponent(shareContent.description);
    const shareUrl = encodeURIComponent(shareContent.url);
    
    let shareLink = "";
    switch (platform) {
      case "facebook":
        shareLink = `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}&quote=${shareText}`;
        break;
      case "twitter":
        shareLink = `https://twitter.com/intent/tweet?text=${shareText}&url=${shareUrl}`;
        break;
      case "linkedin":
        shareLink = `https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}&summary=${shareText}`;
        break;
      case "instagram":
        // Instagram doesn't support direct sharing, copy to clipboard
        navigator.clipboard.writeText(`${shareContent.description}\n\n${shareContent.url}`);
        toast({
          title: "Instagram Share",
          description: "Content copied to clipboard! Paste it in Instagram.",
        });
        return;
      default:
        return;
    }
    
    if (shareLink) {
      window.open(shareLink, "_blank", "width=600,height=400");
    }
  };

  const shareToUserSocialMedia = async (userId: number, platform: string, shareContent: ShareContent) => {
    // This would make an API call to share on behalf of connected users
    // For now, we'll simulate the action
    console.log(`Sharing to user ${userId} on ${platform}:`, shareContent);
    
    // In reality, this would use OAuth tokens stored for each user's social media accounts
    // and post to their feeds with their permission
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto bg-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-center flex items-center justify-center gap-2">
            <Send className="h-5 w-5" />
            Multi-Share Content
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Custom Message */}
          <div>
            <label className="text-sm font-medium mb-2 block">Custom Message</label>
            <Textarea
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              placeholder="Add your message..."
              className="min-h-[80px]"
            />
          </div>

          {/* Direct Social Media Sharing */}
          <div>
            <label className="text-sm font-medium mb-3 block flex items-center gap-2">
              <Globe className="h-4 w-4" />
              Share to Your Social Media
            </label>
            <div className="grid grid-cols-2 gap-3">
              {socialPlatforms.map((platform) => {
                const Icon = platform.icon;
                return (
                  <div
                    key={platform.id}
                    className={`flex items-center space-x-2 p-3 border rounded-lg cursor-pointer transition-all ${
                      selectedPlatforms.includes(platform.id)
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => handlePlatformToggle(platform.id)}
                  >
                    <Checkbox
                      checked={selectedPlatforms.includes(platform.id)}
                      onChange={() => {}}
                    />
                    <Icon className="h-5 w-5" style={{ color: platform.color }} />
                    <span className="text-sm font-medium">{platform.name}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Connected Users Sharing */}
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <Checkbox
                checked={shareToConnectedUsers}
                onChange={() => setShareToConnectedUsers(!shareToConnectedUsers)}
              />
              <label className="text-sm font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                Also share to connected users' social media
              </label>
            </div>
            
            {shareToConnectedUsers && (
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {connectedUsers.map((user) => (
                  <div
                    key={user.id}
                    className={`flex items-center space-x-3 p-2 border rounded-lg cursor-pointer transition-all ${
                      selectedUsers.includes(user.id)
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => handleUserToggle(user.id)}
                  >
                    <Checkbox
                      checked={selectedUsers.includes(user.id)}
                      onChange={() => {}}
                    />
                    <img
                      src={user.profileImageUrl || "/default-avatar.png"}
                      alt={user.name}
                      className="w-8 h-8 rounded-full"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{user.name}</p>
                      <div className="flex gap-1">
                        {user.connectedPlatforms.map((platform) => {
                          const platformConfig = socialPlatforms.find(p => p.id === platform);
                          if (!platformConfig) return null;
                          const Icon = platformConfig.icon;
                          return (
                            <Icon
                              key={platform}
                              className="h-3 w-3"
                              style={{ color: platformConfig.color }}
                            />
                          );
                        })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Share Button */}
          <div className="flex gap-3 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button onClick={handleShare} className="flex-1 bg-green-600 hover:bg-green-700">
              <Send className="h-4 w-4 mr-2" />
              Share Now
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}