import { createRoot } from "react-dom/client";
import "./index.css";

console.log("=== React Debug Start ===");
console.log("DOM ready:", document.readyState);
console.log("Root element:", document.getElementById("root"));

function DebugApp() {
  console.log("DebugApp rendering");
  return (
    <div style={{ 
      padding: '20px', 
      backgroundColor: '#f0f0f0', 
      minHeight: '100vh',
      fontFamily: 'Arial, sans-serif'
    }}>
      <h1 style={{ color: '#333', marginBottom: '20px' }}>GoHealMe Debug Mode</h1>
      <p style={{ color: '#666' }}>React app is now mounting successfully!</p>
      <div style={{ 
        backgroundColor: 'white', 
        padding: '15px', 
        borderRadius: '8px',
        marginTop: '20px'
      }}>
        <h2 style={{ color: '#2563eb' }}>Application Status</h2>
        <ul style={{ lineHeight: '1.6' }}>
          <li>✅ React DOM is working</li>
          <li>✅ CSS styles are loading</li>
          <li>✅ JavaScript execution is successful</li>
          <li>⏳ Ready to load full application</li>
        </ul>
      </div>
    </div>
  );
}

try {
  const rootElement = document.getElementById("root");
  if (!rootElement) {
    throw new Error("Root element not found");
  }
  
  console.log("Creating React root...");
  const root = createRoot(rootElement);
  
  console.log("Rendering DebugApp...");
  root.render(<DebugApp />);
  
  console.log("=== React Debug Success ===");
} catch (error) {
  console.error("=== React Debug Error ===", error);
  document.body.innerHTML = `
    <div style="padding: 20px; background: #fee; color: #900; font-family: Arial;">
      <h1>React Error</h1>
      <p>Error: ${error.message}</p>
      <pre>${error.stack}</pre>
    </div>
  `;
}