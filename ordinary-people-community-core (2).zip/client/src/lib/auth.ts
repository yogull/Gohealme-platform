import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  User as FirebaseUser
} from "firebase/auth";
import { auth } from "./firebase";
import { apiRequest } from "./queryClient";
import { User } from "@shared/schema";

export interface AuthState {
  user: FirebaseUser | null;
  appUser: User | null;
  loading: boolean;
}

export async function signIn(email: string, password: string): Promise<FirebaseUser> {
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  
  // Refresh the user token to get latest emailVerified status
  await userCredential.user.reload();
  
  // For existing users, allow sign in even if email not verified
  // Email verification is only required during initial signup
  return userCredential.user;
}

export async function signUp(email: string, password: string, name: string, language: string = 'en'): Promise<{ user: User; needsVerification: boolean }> {
  try {
    console.log("Starting signup process for:", email);
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    console.log("Firebase user created successfully:", userCredential.user.uid);
    
    // Send email verification with robust error handling
    try {
      await sendEmailVerification(userCredential.user, {
        url: `${window.location.origin}/login?verified=true`,
        handleCodeInApp: true
      });
      console.log("Verification email sent successfully");
    } catch (emailError) {
      console.warn("Email verification failed, but continuing signup:", emailError);
      // Don't fail signup if email verification fails
    }
    
    // Create user in our database with retry logic
    let retryCount = 0;
    const maxRetries = 3;
    
    while (retryCount < maxRetries) {
      try {
        console.log(`Creating database user (attempt ${retryCount + 1}/${maxRetries})`);
        const response = await apiRequest("POST", "/api/users", {
          firebaseUid: userCredential.user.uid,
          email: userCredential.user.email || email,
          name,
          language
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          console.error("Database user creation failed:", errorData);
          
          // If user already exists in database but Firebase auth succeeded, that's okay
          if (response.status === 409 && errorData.error?.includes('already exists')) {
            console.log("User already exists in database, fetching existing user");
            const existingUserResponse = await apiRequest("GET", `/api/users/firebase/${userCredential.user.uid}`);
            if (existingUserResponse.ok) {
              const existingUser = await existingUserResponse.json();
              console.log("Successfully retrieved existing user");
              return { user: existingUser, needsVerification: false };
            }
          }
          
          // Only throw error on last retry
          if (retryCount === maxRetries - 1) {
            throw new Error(errorData.error || "Failed to create user account");
          }
        } else {
          const user = await response.json();
          console.log("Database user created successfully:", user.id);
          return { user, needsVerification: false };
        }
      } catch (dbError: any) {
        console.error(`Database operation failed (attempt ${retryCount + 1}):`, dbError);
        if (retryCount === maxRetries - 1) {
          throw dbError;
        }
        // Wait before retry
        await new Promise(resolve => setTimeout(resolve, 1000 * (retryCount + 1)));
      }
      retryCount++;
    }
    
    throw new Error("Failed to create user after multiple attempts");
  } catch (error: any) {
    console.error("Sign up error:", error);
    
    // Provide user-friendly error messages
    if (error.code === 'auth/email-already-in-use') {
      throw new Error("An account with this email already exists. Please try signing in instead.");
    } else if (error.code === 'auth/weak-password') {
      throw new Error("Password is too weak. Please use at least 6 characters.");
    } else if (error.code === 'auth/invalid-email') {
      throw new Error("Please enter a valid email address.");
    } else if (error.code === 'auth/network-request-failed') {
      throw new Error("Network connection issue. Please check your internet and try again.");
    } else if (error.message?.includes('duplicate key') || error.message?.includes('already exists')) {
      throw new Error("This email is already registered. Please try signing in instead.");
    } else if (error.message?.includes('Failed to fetch') || error.message?.includes('Network')) {
      throw new Error("Connection issue during signup. Please try again or check your internet connection.");
    }
    
    throw error;
  }
}

export async function signOut(): Promise<void> {
  await firebaseSignOut(auth);
}

export async function resetPassword(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email, {
    url: `${window.location.origin}/login?reset=true`,
    handleCodeInApp: false
  });
}

export async function resendVerificationEmail(): Promise<void> {
  const user = auth.currentUser;
  if (user && !user.emailVerified) {
    await sendEmailVerification(user, {
      url: `${window.location.origin}/login?verified=true`,
      handleCodeInApp: true
    });
  } else {
    throw new Error("No user found or email already verified");
  }
}

export async function changePassword(currentPassword: string, newPassword: string): Promise<void> {
  const user = auth.currentUser;
  if (!user || !user.email) {
    throw new Error("No user is currently signed in");
  }

  // Re-authenticate user before changing password
  const credential = EmailAuthProvider.credential(user.email, currentPassword);
  await reauthenticateWithCredential(user, credential);
  
  // Update password
  await updatePassword(user, newPassword);
}

export async function getCurrentAppUser(firebaseUid: string): Promise<User | null> {
  try {
    const response = await apiRequest("GET", `/api/users/firebase/${firebaseUid}`);
    return response; // apiRequest already parses JSON
  } catch (error) {
    console.error("Failed to fetch app user:", error);
    return null;
  }
}

export function onAuthStateChange(callback: (user: FirebaseUser | null) => void) {
  return onAuthStateChanged(auth, callback);
}
