// Stable Core System - Prevents recurring platform issues
// Addresses root causes of 50+ repeated fixes

export const stableToast = {
  show: (title: string, description: string) => {
    // Create toast element directly in DOM to avoid React conflicts
    const toastContainer = document.getElementById('stable-toast-container') || createToastContainer();
    
    const toast = document.createElement('div');
    toast.style.cssText = `
      background: #1f2937;
      color: white;
      padding: 16px;
      border-radius: 8px;
      margin-bottom: 8px;
      min-width: 300px;
      max-width: 400px;
      box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
      position: relative;
      animation: slideIn 0.3s ease-out;
    `;
    
    toast.innerHTML = `
      <button onclick="this.parentElement.remove()" style="
        position: absolute;
        top: 8px;
        right: 8px;
        background: transparent;
        border: none;
        color: white;
        cursor: pointer;
        font-size: 18px;
        padding: 4px;
        border-radius: 4px;
        z-index: 1;
      ">×</button>
      <div style="font-weight: 600; margin-bottom: 4px;">${title}</div>
      <div style="font-size: 14px; opacity: 0.9;">${description}</div>
    `;
    
    toastContainer.appendChild(toast);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
      if (toast.parentElement) {
        toast.remove();
      }
    }, 5000);
  }
};

function createToastContainer() {
  const container = document.createElement('div');
  container.id = 'stable-toast-container';
  container.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 100000;
    pointer-events: none;
  `;
  document.body.appendChild(container);
  return container;
}

export const stableButton = {
  create: (text: string, onClick: () => void, variant: 'primary' | 'secondary' | 'ghost' = 'primary') => {
    const button = document.createElement('button');
    
    const variants = {
      primary: 'background: #3b82f6; color: white; padding: 8px 16px;',
      secondary: 'background: #f3f4f6; color: #374151; padding: 8px 16px;',
      ghost: 'background: transparent; color: #374151; padding: 4px 8px;'
    };
    
    button.style.cssText = `
      ${variants[variant]}
      border: none;
      border-radius: 6px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
      pointer-events: auto;
      z-index: 1000;
    `;
    
    button.textContent = text;
    button.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    
    return button;
  }
};

export const stableShare = {
  multiPlatform: (text: string, url: string = window.location.href) => {
    const platforms = [
      { name: 'Facebook', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}` },
      { name: 'Twitter', url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}` },
      { name: 'LinkedIn', url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}` },
      { name: 'Reddit', url: `https://reddit.com/submit?title=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}` },
      { name: 'WhatsApp', url: `https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}` },
      { name: 'Telegram', url: `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}` },
      { name: 'Pinterest', url: `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(url)}&description=${encodeURIComponent(text)}` },
      { name: 'Tumblr', url: `https://www.tumblr.com/share/link?url=${encodeURIComponent(url)}&name=${encodeURIComponent(text)}` },
      { name: 'Discord', url: `https://discord.com/channels/@me` },
      { name: 'Snapchat', url: `https://www.snapchat.com/` },
      { name: 'TikTok', url: `https://www.tiktok.com/` },
      { name: 'Instagram', url: `https://www.instagram.com/` },
      { name: 'YouTube', url: `https://www.youtube.com/` },
      { name: 'Twitch', url: `https://www.twitch.tv/` },
      { name: 'Medium', url: `https://medium.com/new-story` },
      { name: 'GitHub', url: `https://github.com/` },
      { name: 'Spotify', url: `https://open.spotify.com/` },
      { name: 'Vimeo', url: `https://vimeo.com/` },
      { name: 'Flickr', url: `https://www.flickr.com/` },
      { name: 'Skype', url: `https://web.skype.com/` },
      { name: 'SoundCloud', url: `https://soundcloud.com/` },
      { name: 'Behance', url: `https://www.behance.net/` },
      { name: 'Dribbble', url: `https://dribbble.com/` },
      { name: 'DeviantArt', url: `https://www.deviantart.com/` },
      { name: 'Stack Overflow', url: `https://stackoverflow.com/` },
      { name: 'Quora', url: `https://www.quora.com/` }
    ];
    
    platforms.forEach((platform, index) => {
      setTimeout(() => {
        window.open(platform.url, `share-${platform.name}`, 'width=600,height=400,scrollbars=yes,resizable=yes');
      }, index * 100);
    });
    
    stableToast.show('Multi-Share Active', `Opening all ${platforms.length} social media platforms`);
  },
  
  socialMedia: (text: string, url: string = window.location.href) => {
    const platforms = [
      { name: 'Facebook', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}` },
      { name: 'Twitter', url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}` },
      { name: 'LinkedIn', url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}` },
      { name: 'WhatsApp', url: `https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}` }
    ];
    
    platforms.forEach((platform, index) => {
      setTimeout(() => {
        window.open(platform.url, `share-${platform.name}`, 'width=600,height=400,scrollbars=yes,resizable=yes');
      }, index * 150);
    });
    
    stableToast.show('Social Media Share', 'Opening Facebook, Twitter, LinkedIn, and WhatsApp');
  },
  
  community: () => {
    window.location.assign('/community');
    stableToast.show('OPC Share Active', 'Opening community discussions');
  }
};

// Initialize stable systems on load
if (typeof window !== 'undefined') {
  // Add CSS animations
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    #stable-toast-container > div {
      pointer-events: auto;
    }
  `;
  document.head.appendChild(style);
}