import { auth } from './firebase';

// Simple test to verify Firebase connection
export async function testFirebaseConnection() {
  try {
    console.log('Testing Firebase connection...');
    console.log('Auth object:', auth);
    console.log('Current user:', auth.currentUser);
    
    // Try to get the current auth state
    return new Promise((resolve) => {
      const unsubscribe = auth.onAuthStateChanged((user) => {
        console.log('Auth state changed:', user);
        unsubscribe();
        resolve(user);
      });
    });
  } catch (error) {
    console.error('Firebase connection test failed:', error);
    return null;
  }
}