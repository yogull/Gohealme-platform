import { useState, useEffect } from "react";

interface TutorialStep {
  title: string;
  content: string;
  action?: string;
}

interface TutorialData {
  [page: string]: TutorialStep[];
}

const tutorialData: TutorialData = {
  "/": [
    {
      title: "Welcome to Ordinary People Community!",
      content: "This is your community dashboard. Here you can see an overview of your supplements, biometrics, and daily compliance at a glance.",
      action: "Look at the cards showing your recent activity and health metrics."
    },
    {
      title: "Communication Features",
      content: "Use the WhatsApp Call/Video and Messenger Call/Video buttons for instant communication with community members.",
      action: "Try the green WhatsApp or blue Messenger buttons for direct communication."
    },
    {
      title: "Quick Actions",
      content: "Use the dashboard to quickly log today's supplements or add new biometric readings without navigating to other pages.",
      action: "Try clicking on any of the quick action buttons."
    },
    {
      title: "Navigation Help",
      content: "DESKTOP: Use the sidebar on the left to navigate between different sections. MOBILE: Use the three-line dropdown menu in the top right. Each page has its own specific purpose for tracking your community experience."
    }
  ],
  "/supplements": [
    {
      title: "Your Supplement Tracker",
      content: "This page lets you add and manage all your supplements - whether you bought them from our shop or anywhere else.",
      action: "Click 'Add New Supplement' to create your first entry."
    },
    {
      title: "Adding Any Supplement",
      content: "You can add ANY supplement here - liver capsules, methylene blue, vitamins, prescriptions, herbs - anything you take regularly.",
      action: "Fill in the supplement name, dosage (like '2 capsules' or '1000mg'), and when you take it."
    },
    {
      title: "Setting Your Schedule",
      content: "Choose how often you take it (daily, twice daily, etc.) and the specific time. This creates your personal supplement diary.",
      action: "Set specific times like '8:00 AM' for reminders and tracking."
    },
    {
      title: "Personal Notes",
      content: "Add notes about each supplement - special instructions, why you take it, or dosage adjustments your doctor recommended."
    }
  ],
  "/daily-log": [
    {
      title: "Daily Supplement Logging",
      content: "This is where you check off supplements as you take them each day. It's like a daily checklist for your health routine.",
      action: "Mark supplements as 'taken' by clicking the checkboxes."
    },
    {
      title: "Building Streaks",
      content: "Track your compliance and build streaks. The system shows you which supplements you've missed and celebrates your consistency.",
      action: "Try to maintain daily streaks for better health / wellness outcomes."
    },
    {
      title: "Visual Progress",
      content: "See your daily, weekly, and monthly progress with visual indicators. Green checkmarks show completed doses."
    }
  ],
  "/biometrics": [
    {
      title: "Health Metrics Tracking",
      content: "Log important health / wellness measurements like weight, blood pressure, sleep hours, and daily steps.",
      action: "Click 'Add New Reading' to log today's measurements."
    },
    {
      title: "Trend Analysis",
      content: "View charts showing your health / wellness trends over time. This helps you see how your supplements and lifestyle changes affect your health / wellness.",
      action: "Look at the graphs to spot patterns in your health / wellness data."
    },
    {
      title: "Comprehensive Tracking",
      content: "Track various health / wellness metrics including vital signs, body measurements, sleep quality, and activity levels all in one place."
    }
  ],
  "/shop": [
    {
      title: "Supplement Shop",
      content: "Browse high-quality supplements with affiliate links. These are carefully selected products that integrate with your tracking system.",
      action: "Browse the available supplements and read detailed descriptions."
    },
    {
      title: "Easy Integration",
      content: "Supplements purchased here can be automatically added to your tracking system with pre-filled dosage information.",
      action: "Click on any product to see detailed information and dosage recommendations."
    },
    {
      title: "Quality Products",
      content: "All products are researched and selected for quality. You can still track any supplements you buy elsewhere in your diary."
    }
  ],
  "/illness-guides": [
    {
      title: "Health / Wellness Information Hub",
      content: "Access comprehensive guides about various health / wellness conditions including symptoms, treatments, and support resources.",
      action: "Click on any condition to read detailed information."
    },
    {
      title: "Support Guidelines",
      content: "Each health / wellness guide includes what to say and what not to say when supporting someone with that condition, plus helpful resources.",
      action: "Use the search box to find specific conditions or browse by category."
    },
    {
      title: "Community Discussions",
      content: "Join discussions about each health / wellness condition and connect with others who have similar experiences."
    }
  ],
  "/blog": [
    {
      title: "Ordinary People Community Blog",
      content: "Share your views and experiences, read others' stories, and participate in open discussions on government, health, and personal topics.",
      action: "Click 'Create New Post' to share your own stories, views, or insights on any topic."
    },
    {
      title: "Connect & Support",
      content: "Like, comment, and support other community members. Building connections helps everyone share their views and experiences.",
      action: "Read a few posts and leave encouraging comments."
    }
  ],
  "/social": [
    {
      title: "Connect with Others",
      content: "Find and connect with other community members interested in government topics, health advice, and personal views. Build your support network.",
      action: "Use the search to find people with similar interests in government, health, or personal topics."
    },
    {
      title: "Community Connections",
      content: "Send connection requests to people whose views on government, health, or personal topics inspire you or who might offer mutual support."
    }
  ],
  "/community": [
    {
      title: "Community Discussions",
      content: "Join location-based and topic-based discussions on government, personal views, and health advice. Connect with people in your area or with shared interests.",
      action: "Browse discussions by category or create a new discussion topic."
    },
    {
      title: "Real-Time Chat",
      content: "Participate in real-time discussions on government, health advice, and personal topics. Share experiences, ask questions, and support each other.",
      action: "Join an active discussion and introduce yourself."
    }
  ],
  "/profile": [
    {
      title: "Your Community Profile",
      content: "Manage your profile information, upload photos, and share your interests in government topics, health advice, and personal views.",
      action: "Update your profile with your interests in government topics, health advice, and personal views."
    },
    {
      title: "Privacy Settings",
      content: "Control what information you share with the community and adjust your privacy preferences for discussions and connections.",
      action: "Review and adjust your privacy settings as needed."
    }
  ],
  "/admin": [
    {
      title: "Admin Dashboard",
      content: "Manage shop products, user content, and platform settings. Add new products and moderate community content.",
      action: "Use the product management tools to add new supplements to the shop."
    }
  ]
};

export function useTutorial() {
  const [completedTutorials, setCompletedTutorials] = useState<string[]>(() => {
    const saved = localStorage.getItem('gohealme-completed-tutorials');
    return saved ? JSON.parse(saved) : [];
  });

  const markTutorialComplete = (page: string) => {
    const updated = [...completedTutorials, page];
    setCompletedTutorials(updated);
    localStorage.setItem('gohealme-completed-tutorials', JSON.stringify(updated));
  };

  const resetTutorials = () => {
    setCompletedTutorials([]);
    localStorage.removeItem('gohealme-completed-tutorials');
  };

  const isTutorialComplete = (page: string) => {
    return completedTutorials.includes(page);
  };

  const getTutorialSteps = (page: string) => {
    return tutorialData[page] || [];
  };

  const shouldShowTutorial = (page: string) => {
    return !isTutorialComplete(page) && getTutorialSteps(page).length > 0;
  };

  return {
    markTutorialComplete,
    resetTutorials,
    isTutorialComplete,
    getTutorialSteps,
    shouldShowTutorial,
    completedTutorials
  };
}