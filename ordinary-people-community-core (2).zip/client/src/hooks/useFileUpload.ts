import { useMutation, useQueryClient } from '@tanstack/react-query';
import { uploadFile as uploadFileAPI } from '@/lib/queryClient';

interface FileUploadData {
  file: File;
  galleryName?: string;
  caption?: string;
  isProfileImage?: boolean;
}

interface UserFile {
  id: number;
  fileName: string;
  originalName: string;
  fileType: string;
  cropData: any;
  createdAt: string;
  dataUrl: string;
}

export function useFileUpload() {
  const queryClient = useQueryClient();

  const uploadFile = useMutation({
    mutationFn: async ({ file, galleryName, caption, isProfileImage }: FileUploadData) => {
      return await uploadFileAPI(file, {
        galleryName,
        caption,
        isProfileImage
      });
    },
    onSuccess: () => {
      // Invalidate and refetch relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      queryClient.invalidateQueries({ queryKey: ['/api/gallery'] });
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall'] });
    },
  });

  const getUserFiles = async (userId: number, fileType?: string): Promise<UserFile[]> => {
    const url = fileType 
      ? `/api/files/user/${userId}?fileType=${fileType}`
      : `/api/files/user/${userId}`;
    
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch user files');
    return response.json();
  };

  return {
    uploadFile,
    getUserFiles,
    isUploading: uploadFile.isPending,
    uploadError: uploadFile.error,
  };
}