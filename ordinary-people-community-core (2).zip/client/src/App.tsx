/**
 * Copyright (c) 2025 John Proctor. All rights reserved.
 * The People's Health Community Platform
 * Unauthorized copying, distribution, or modification is strictly prohibited.
 */

import React from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TranslationProvider } from "@/hooks/useTranslation";
import { SupportBanner } from "@/components/SupportBanner";
import { CookieConsent } from "@/components/CookieConsent";
import { PWAInstallPrompt } from "@/components/PWAInstallPrompt";
import { Footer } from "@/components/Footer";
import { SEOBooster, usePageSpeed } from "@/components/SEOBooster";
import { GoogleAnalytics } from "@/components/GoogleAnalytics";
import { AdvancedSEO, CoreWebVitalsOptimizer } from "@/components/AdvancedSEO";
// Brain system temporarily disabled to prevent login form interference
// import { applyUniversalButtonFix } from "@/utils/universalButtonFix";
// Button monitoring systems temporarily disabled for development
// import "@/utils/buttonFailureDetection";
// import "@/utils/accountSettingsButtonFix";
// import "@/utils/profileButtonBrainFix";

// Brain system temporarily disabled to prevent login form interference
// Live button monitor for auto-deployment triggers
// import "@/utils/liveButtonMonitor";

// ErrorAutoFixer disabled to prevent login interference
// import { ErrorAutoFixer } from "@/components/ErrorAutoFixer";
import ErrorBoundary from "@/components/ErrorBoundary";
// import { RealTimeButtonFixer } from "@/components/RealTimeButtonFixer";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import BasicLogin from "@/pages/BasicLogin";
import { SimpleLogin } from "@/components/SimpleLogin";
import { AuthWrapper } from "@/components/AuthWrapper";
import { DirectLogin } from "@/components/DirectLogin";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import Supplements from "@/pages/Supplements";
import Biometrics from "@/pages/Biometrics";
import Profile from "@/pages/Profile";
import ProfileSettings from "@/pages/ProfileSettings";
import UserProfile from "@/pages/UserProfile";
import ProfileWallRedirect from "@/pages/ProfileWallRedirect";
import SocialMediaView from "@/pages/SocialMediaView";
import Shop from "@/pages/ShopFixed";
import Admin from "@/pages/Admin";
import MainAdmin from "@/pages/MainAdmin";
import Blog from "@/pages/Blog";
import BlogCategory from "@/pages/BlogCategory";
import Social from "@/pages/Social";
import CommunitySimple from "@/pages/CommunitySimple";
import CommunityDirect from "@/pages/CommunityDirect";
import ProfileWallDirect from "@/pages/ProfileWallDirect";
import EmergencyAccess from "@/pages/EmergencyAccess";
import CategoryDiscussionV2 from "@/pages/CategoryDiscussionV2";
import IllnessGuides from "@/pages/IllnessGuides";
import IllnessDetail from "@/pages/IllnessDetail";
import IllnessAdmin from "@/pages/IllnessAdmin";
import HealthHub from "@/pages/HealthHub";
import Terms from "@/pages/Terms";
import Privacy from "@/pages/Privacy";
import Chat from "@/pages/Chat";
import Contact from "@/pages/Contact";
import AboutUs from "@/pages/AboutUs";
import Disclosures from "@/pages/Disclosures";
import Donate from "@/pages/Donate";
import DonateSuccess from "@/pages/DonateSuccess";
import AdvertisePayment from "@/pages/AdvertisePayment";
import AdvertiseSuccess from "@/pages/AdvertiseSuccess";
import AdvertiserPortal from "@/pages/AdvertiserPortal";
import CompanyStorefront from "@/pages/CompanyStorefront";
import AdminFeedsFixed from "@/pages/AdminFeedsFixed";
import AdminCategories from "@/pages/AdminCategories";
import SuperAdmin from "@/pages/SuperAdmin";
import LocationAds from "@/pages/LocationAds";
import BusinessProfile from "@/pages/BusinessProfile";
import Notifications from "@/pages/Notifications";
import DailyNews from "@/pages/DailyNews";
import PersonalShopSimple from "@/pages/PersonalShopSimple";
import PersonalShopSearch from "@/pages/PersonalShopSearch";
import PersonalShopView from "@/pages/PersonalShopView";
import PersonalShopManage from "@/pages/PersonalShopManage";
import SocialHub from "@/pages/SocialHub";
import BusinessDirectory from "@/pages/BusinessDirectory";
import AdminAffiliateShopsFixed from "@/pages/AdminAffiliateShopsFixed";
import AdminDashboard from "@/pages/AdminDashboard";
import AdminAnalytics from "@/pages/AdminAnalytics";
import InvitationAnalytics from "@/pages/InvitationAnalytics";

import ProfileWallWorkingFixed from "@/pages/ProfileWallWorkingFixed";
import SocialMediaViewer from "@/pages/SocialMediaViewer";
import SocialNetworkView from "@/pages/SocialNetworkView";
import GallerySimple from "@/pages/GallerySimple";
import NotFound from "@/pages/not-found";

function Router() {
  usePageSpeed(); // Performance optimization hook
  
  // Brain system temporarily disabled to prevent login form interference  
  // React.useEffect(() => {
  //   applyUniversalButtonFix();
  // }, []);
  
  return (
    <Switch>
      <Route path="/" component={EmergencyAccess} />
      <Route path="/dashboard">
        {() => {
          // Simple dashboard route without complex auth checks
          return <Home />;
        }}
      </Route>
      <Route path="/login" component={SimpleLogin} />
      <Route path="/basic-login" component={BasicLogin} />
      <Route path="/supplements">
        {() => (
          <ProtectedRoute>
            {(user) => <Supplements />}
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/daily-log">
        {() => (
          <ProtectedRoute>
            {(user) => <Supplements />}
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/biometrics">
        {() => (
          <ProtectedRoute>
            {(user) => <Biometrics />}
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/profile">
        {() => (
          <ProtectedRoute>
            {(user) => <Profile />}
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/profile-settings">
        {() => (
          <ProtectedRoute>
            {(user) => <ProfileSettings />}
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/settings">
        {() => (
          <ProtectedRoute>
            {(user) => <ProfileSettings />}
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/users/:userId" component={UserProfile} />
      <Route path="/gallery" component={GallerySimple} />
      <Route path="/gallery/:userId" component={GallerySimple} />
      <Route path="/profile-wall">
        {() => (
          <ProtectedRoute>
            {(user) => <ProfileWallWorkingFixed key={`profile-wall-${Date.now()}`} />}
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/profile-wall/:userId">
        {() => (
          <ProtectedRoute>
            {(user) => <ProfileWallWorkingFixed key={`profile-wall-${Date.now()}`} />}
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/social/:userId/:platform" component={SocialMediaView} />
      <Route path="/social-media/:platform" component={SocialMediaViewer} />
      <Route path="/social-network/:platform" component={SocialNetworkView} />
      <Route path="/shop" component={Shop} />

      <Route path="/social" component={Social} />
      <Route path="/community" component={CommunitySimple} />
      <Route path="/community-direct" component={CommunityDirect} />
      <Route path="/profile-wall-direct" component={ProfileWallDirect} />
      <Route path="/emergency" component={EmergencyAccess} />
      <Route path="/community/category/:categoryId" component={CategoryDiscussionV2} />
      <Route path="/illness-guides" component={IllnessGuides} />
      <Route path="/illness-guides/:illnessId" component={IllnessDetail} />
      <Route path="/illness-admin" component={IllnessAdmin} />
      <Route path="/health-hub" component={HealthHub} />
      <Route path="/chat" component={Chat} />
      <Route path="/news" component={DailyNews} />
      <Route path="/contact" component={Contact} />
      <Route path="/about" component={AboutUs} />
      <Route path="/donate" component={Donate} />
      <Route path="/donate-success" component={DonateSuccess} />
      <Route path="/advertise-payment" component={AdvertisePayment} />
      <Route path="/advertise-success" component={AdvertiseSuccess} />
      <Route path="/advertiser-portal" component={AdvertiserPortal} />
      <Route path="/location-ads" component={LocationAds} />
      <Route path="/business/:id" component={BusinessProfile} />
      <Route path="/business-profile/:id" component={BusinessProfile} />
      <Route path="/business-profile" component={BusinessProfile} />
      <Route path="/personal-shop" component={PersonalShopSimple} />
      <Route path="/personal-shop-search" component={PersonalShopSearch} />
      <Route path="/personal-shop-view/:shopId" component={PersonalShopView} />
      <Route path="/personal-shop-manage/:shopId" component={PersonalShopManage} />
      <Route path="/social-hub" component={SocialHub} />
      <Route path="/business-directory" component={BusinessDirectory} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/daily-news" component={DailyNews} />
      <Route path="/terms" component={Terms} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/disclosures" component={Disclosures} />
      <Route path="/admin" component={MainAdmin} />
      <Route path="/shop-admin" component={Admin} />
      <Route path="/admin/feeds" component={AdminFeedsFixed} />
      <Route path="/admin/categories" component={AdminCategories} />
      <Route path="/admin/affiliate-shops" component={AdminAffiliateShopsFixed} />
      <Route path="/admin-dashboard" component={AdminDashboard} />
      <Route path="/admin-analytics" component={AdminAnalytics} />
      <Route path="/invitation-analytics" component={InvitationAnalytics} />
      <Route path="/super-admin">
        {() => <div>Super Admin - Coming Soon</div>}
      </Route>
      <Route path="/company/:companyId" component={CompanyStorefront} />
      <Route path="/company/:companyId/purchase-success" component={() => 
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-3xl font-bold text-green-600 mb-4">Purchase Successful!</h1>
          <p className="text-lg text-gray-600">Thank you for your purchase. You will receive an email confirmation shortly.</p>
        </div>
      } />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Code protection disabled for user access

  return (
    <QueryClientProvider client={queryClient}>
      <TranslationProvider>
        <TooltipProvider>
          <SEOBooster />
          <GoogleAnalytics />
          <AdvancedSEO />
          <CoreWebVitalsOptimizer />
          <Router />
          {/* <RealTimeButtonFixer enabled={true} /> */}
          {/* <ErrorAutoFixer /> - Disabled to prevent login interference */}
          <Toaster />
          <CookieConsent />
          <PWAInstallPrompt />
        </TooltipProvider>
      </TranslationProvider>
    </QueryClientProvider>
  );
}

export default App;
