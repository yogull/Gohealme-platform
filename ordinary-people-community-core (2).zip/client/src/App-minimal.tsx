import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./lib/firebase";
import { LoginForm } from "@/components/LoginForm";
import { Loader2, Leaf } from "lucide-react";

function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Leaf className="w-8 h-8 text-green-600 mr-2" />
            <h1 className="text-3xl font-bold text-gray-900">GoHealMe</h1>
          </div>
          <p className="text-gray-600">Your health tracking platform is ready</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Supplements</h3>
            <p className="text-gray-600 text-sm mb-4">Track your daily supplements</p>
            <button className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors">
              Manage Supplements
            </button>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Biometrics</h3>
            <p className="text-gray-600 text-sm mb-4">Log health metrics</p>
            <button className="w-full bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700 transition-colors">
              View Metrics
            </button>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Community</h3>
            <p className="text-gray-600 text-sm mb-4">Connect with others</p>
            <button className="w-full bg-purple-600 text-white py-2 px-4 rounded hover:bg-purple-700 transition-colors">
              Join Community
            </button>
          </div>
        </div>
        
        <div className="text-center">
          <button 
            onClick={async () => {
              await auth.signOut();
              window.location.reload();
            }}
            className="text-gray-600 hover:text-gray-700 underline"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading GoHealMe...</p>
        </div>
      </div>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      {user ? (
        <Dashboard />
      ) : (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center mb-8">
              <div className="flex items-center justify-center mb-4">
                <Leaf className="w-8 h-8 text-green-600 mr-2" />
                <h1 className="text-3xl font-bold text-gray-900">GoHealMe</h1>
              </div>
              <p className="text-gray-600">Your comprehensive health tracking platform</p>
            </div>
            <LoginForm onSuccess={() => window.location.reload()} />
          </div>
        </div>
      )}
    </QueryClientProvider>
  );
}

export default App;