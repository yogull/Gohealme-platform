import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Users, 
  MousePointer, 
  Target, 
  TrendingUp, 
  Mail, 
  ExternalLink,
  BarChart3,
  PieChart,
  Activity
} from 'lucide-react';

interface InvitationAnalytics {
  totalInvitations: number;
  totalClicks: number;
  totalConversions: number;
  conversionRate: number;
  clickRate: number;
  platformBreakdown: Array<{
    platform: string;
    invitations: number;
    clicks: number;
    conversions: number;
    conversionRate: number;
  }>;
  businessEmailTracking: Array<{
    businessId: number;
    emailType: string;
    status: string;
    sentAt: string;
    openedAt?: string;
    clickedAt?: string;
    respondedAt?: string;
  }>;
  recentActivity: Array<{
    type: 'invitation' | 'click' | 'conversion' | 'business_email';
    platform: string;
    target: string;
    timestamp: string;
  }>;
}

interface TopPlatform {
  platform: string;
  conversionRate: number;
  totalConversions: number;
  totalInvitations: number;
}

interface BusinessStatus {
  businessId: number;
  emailType: string;
  status: string;
  daysSinceLastEmail: number;
  responseRate: number;
}

export default function InvitationAnalytics() {
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d' | 'all'>('7d');

  // Fetch comprehensive analytics
  const { data: analytics, isLoading: analyticsLoading } = useQuery<InvitationAnalytics>({
    queryKey: ['/api/tracking/analytics'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch top performing platforms
  const { data: topPlatforms, isLoading: platformsLoading } = useQuery<TopPlatform[]>({
    queryKey: ['/api/tracking/top-platforms'],
    refetchInterval: 60000,
  });

  // Fetch business response status for follow-up campaigns
  const { data: businessStatus, isLoading: businessLoading } = useQuery<BusinessStatus[]>({
    queryKey: ['/api/tracking/business-status'],
    refetchInterval: 120000,
  });

  if (analyticsLoading || platformsLoading || businessLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto p-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <Activity className="h-8 w-8 animate-spin mx-auto mb-2" />
              <p>Loading comprehensive analytics...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => window.history.back()}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-medium transition-colors inline-flex items-center"
              >
                ← Back
              </button>
              <button
                onClick={() => window.location.assign('/dashboard')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors inline-flex items-center"
              >
                Dashboard
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto p-4 space-y-4 max-w-7xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">📊 Invitation Tracking Analytics</h1>
            <p className="text-gray-600">Complete conversion tracking across all 26+ platforms</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={timeframe === '24h' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTimeframe('24h')}
            >
              24h
            </Button>
            <Button
              variant={timeframe === '7d' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTimeframe('7d')}
            >
              7d
            </Button>
            <Button
              variant={timeframe === '30d' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTimeframe('30d')}
            >
              30d
            </Button>
            <Button
              variant={timeframe === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTimeframe('all')}
            >
              All
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Invitations</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics?.totalInvitations || 0}</div>
              <p className="text-xs text-muted-foreground">
                Across 26+ platforms
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Click-Through Rate</CardTitle>
              <MousePointer className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics?.clickRate.toFixed(1) || 0}%</div>
              <p className="text-xs text-muted-foreground">
                {analytics?.totalClicks || 0} total clicks
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics?.conversionRate.toFixed(1) || 0}%</div>
              <p className="text-xs text-muted-foreground">
                {analytics?.totalConversions || 0} new users
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Business Responses</CardTitle>
              <Mail className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {businessStatus?.filter(b => b.status === 'responded').length || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                Active business leads
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Top Performing Platforms */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Top Performing Platforms
            </CardTitle>
            <CardDescription>Highest conversion rates and user acquisition</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topPlatforms?.slice(0, 10).map((platform, index) => (
                <div key={platform.platform} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="w-8 h-8 rounded-full flex items-center justify-center">
                      {index + 1}
                    </Badge>
                    <div>
                      <p className="font-medium capitalize">{platform.platform}</p>
                      <p className="text-sm text-muted-foreground">
                        {platform.totalConversions} conversions from {platform.totalInvitations} invitations
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-lg">{platform.conversionRate.toFixed(1)}%</p>
                    <Progress value={platform.conversionRate} className="w-24 h-2" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Platform Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Complete Platform Breakdown
            </CardTitle>
            <CardDescription>Performance across all 26+ social media platforms</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {analytics?.platformBreakdown.map((platform) => (
                <div key={platform.platform} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium capitalize">{platform.platform}</h4>
                    <Badge variant={platform.conversionRate > 5 ? 'default' : 'secondary'}>
                      {platform.conversionRate.toFixed(1)}%
                    </Badge>
                  </div>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Invitations:</span>
                      <span>{platform.invitations}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Clicks:</span>
                      <span>{platform.clicks}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Conversions:</span>
                      <span className="font-medium text-foreground">{platform.conversions}</span>
                    </div>
                  </div>
                  <Progress value={platform.conversionRate} className="mt-2 h-1" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Recent Activity
            </CardTitle>
            <CardDescription>Live tracking of invitations, clicks, and conversions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {analytics?.recentActivity?.slice(0, 20).map((activity, index) => (
                <div key={index} className="flex items-center justify-between p-2 border-l-2 border-l-blue-500 pl-4">
                  <div className="flex items-center gap-3">
                    {activity.type === 'invitation' && <Users className="h-4 w-4 text-blue-500" />}
                    {activity.type === 'click' && <MousePointer className="h-4 w-4 text-green-500" />}
                    {activity.type === 'conversion' && <Target className="h-4 w-4 text-purple-500" />}
                    {activity.type === 'business_email' && <Mail className="h-4 w-4 text-orange-500" />}
                    <div>
                      <p className="text-sm font-medium">
                        {activity.type === 'invitation' && 'Invitation sent'}
                        {activity.type === 'click' && 'Link clicked'}
                        {activity.type === 'conversion' && 'User converted'}
                        {activity.type === 'business_email' && 'Business email'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {activity.platform} • {activity.target}
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {new Date(activity.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Export and Refresh */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <Button variant="outline" className="flex items-center gap-2">
            <ExternalLink className="h-4 w-4" />
            Export Analytics Report
          </Button>
          <Button onClick={() => window.location.reload()} className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Refresh Data
          </Button>
        </div>
      </div>
    </div>
  );
}