import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Camera, Upload, Star, Trash2, User, MapPin, Calendar, Heart, MessageCircle } from "lucide-react";

interface UserProfileImage {
  id: number;
  userId: number;
  imageUrl: string;
  caption?: string;
  isProfilePicture: boolean;
  createdAt: string;
}

interface User {
  id: number;
  username: string;
  email: string;
  fullName?: string;
  location?: string;
  bio?: string;
  createdAt: string;
}

interface ProfileStats {
  totalPosts: number;
  totalConnections: number;
  joinedDate: string;
}

export default function UserProfile() {
  const { userId } = useParams();
  const { toast } = useToast();
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [imageUrl, setImageUrl] = useState("");
  const [caption, setCaption] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch user data
  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });

  // Fetch user profile images
  const { data: images = [], isLoading: imagesLoading } = useQuery<UserProfileImage[]>({
    queryKey: [`/api/users/${userId}/profile-images`],
    enabled: !!userId,
  });

  // Upload image mutation
  const uploadImageMutation = useMutation({
    mutationFn: async (data: { imageUrl: string; caption?: string }) => {
      return apiRequest("POST", `/api/users/${userId}/profile-images`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/profile-images`] });
      setIsUploadOpen(false);
      setImageUrl("");
      setCaption("");
      toast({
        title: "Image Uploaded",
        description: "Your image has been added to your profile gallery.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload image",
        variant: "destructive",
      });
    },
  });

  // Delete image mutation
  const deleteImageMutation = useMutation({
    mutationFn: async (imageId: number) => {
      return apiRequest("DELETE", `/api/profile-images/${imageId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/profile-images`] });
      toast({
        title: "Image Deleted",
        description: "Image removed from your gallery.",
      });
    },
  });

  // Set profile picture mutation
  const setProfilePictureMutation = useMutation({
    mutationFn: async (imageId: number) => {
      return apiRequest("POST", `/api/users/${userId}/set-profile-picture/${imageId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/profile-images`] });
      toast({
        title: "Profile Picture Updated",
        description: "Your profile picture has been updated.",
      });
    },
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // For demo purposes, we'll use a placeholder URL
      // In production, you'd upload to a cloud storage service
      const url = `https://images.unsplash.com/photo-${Date.now()}?w=400&h=400&fit=crop`;
      setImageUrl(url);
    }
  };

  const handleUpload = () => {
    if (!imageUrl.trim()) {
      toast({
        title: "Missing Image",
        description: "Please provide an image URL or upload a file.",
        variant: "destructive",
      });
      return;
    }

    uploadImageMutation.mutate({
      imageUrl: imageUrl.trim(),
      caption: caption.trim() || undefined,
    });
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">User Not Found</h2>
          <p className="text-gray-600">The profile you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  const profilePicture = images.find(img => img.isProfilePicture);
  const galleryImages = images.filter(img => !img.isProfilePicture);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Profile Header */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <div className="relative">
                <div className="w-32 h-32 rounded-full bg-gray-200 overflow-hidden">
                  {profilePicture ? (
                    <img
                      src={profilePicture.imageUrl}
                      alt={`${user.username} profile`}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <User className="w-16 h-16 text-gray-400" />
                    </div>
                  )}
                </div>
              </div>

              <div className="flex-1">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{user.fullName || user.username}</h1>
                <p className="text-gray-600 mb-2">@{user.username}</p>
                
                {user.location && (
                  <div className="flex items-center text-gray-600 mb-2">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{user.location}</span>
                  </div>
                )}

                <div className="flex items-center text-gray-600 mb-4">
                  <Calendar className="w-4 h-4 mr-1" />
                  <span>Joined {new Date(user.createdAt).toLocaleDateString()}</span>
                </div>

                {user.bio && (
                  <p className="text-gray-700 mb-4">{user.bio}</p>
                )}

                <div className="flex gap-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Heart className="w-4 h-4 mr-1" />
                    <span>{images.length} Photos</span>
                  </div>
                  <div className="flex items-center">
                    <MessageCircle className="w-4 h-4 mr-1" />
                    <span>Health Enthusiast</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      Upload Photo
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Upload New Photo</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="file-upload">Upload File</Label>
                        <Input
                          id="file-upload"
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          ref={fileInputRef}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="image-url">Or paste image URL</Label>
                        <Input
                          id="image-url"
                          type="url"
                          placeholder="https://example.com/image.jpg"
                          value={imageUrl}
                          onChange={(e) => setImageUrl(e.target.value)}
                        />
                      </div>

                      <div>
                        <Label htmlFor="caption">Caption (optional)</Label>
                        <Textarea
                          id="caption"
                          placeholder="Add a caption for your photo..."
                          value={caption}
                          onChange={(e) => setCaption(e.target.value)}
                          rows={3}
                        />
                      </div>

                      <div className="flex gap-2 justify-end">
                        <Button
                          variant="outline"
                          onClick={() => setIsUploadOpen(false)}
                        >
                          Cancel
                        </Button>
                        <Button
                          onClick={handleUpload}
                          disabled={uploadImageMutation.isPending}
                        >
                          {uploadImageMutation.isPending ? "Uploading..." : "Upload"}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Photo Gallery */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5" />
              Photo Gallery ({images.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {imagesLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin w-6 h-6 border-4 border-primary border-t-transparent rounded-full" />
              </div>
            ) : images.length === 0 ? (
              <div className="text-center py-12">
                <Camera className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Photos Yet</h3>
                <p className="text-gray-600 mb-4">Start building your photo gallery by uploading your first image.</p>
                <Button onClick={() => setIsUploadOpen(true)}>
                  Upload First Photo
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {images.map((image) => (
                  <div key={image.id} className="relative group">
                    <div className="aspect-square bg-gray-200 rounded-lg overflow-hidden">
                      <img
                        src={image.imageUrl}
                        alt={image.caption || "Profile photo"}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                      />
                    </div>
                    
                    {/* Image overlay with actions */}
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-200 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
                      <div className="flex gap-2">
                        {!image.isProfilePicture && (
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => setProfilePictureMutation.mutate(image.id)}
                            disabled={setProfilePictureMutation.isPending}
                          >
                            <Star className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => deleteImageMutation.mutate(image.id)}
                          disabled={deleteImageMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Profile picture badge */}
                    {image.isProfilePicture && (
                      <div className="absolute top-2 left-2">
                        <div className="bg-primary text-white px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                          <Star className="w-3 h-3" />
                          Profile
                        </div>
                      </div>
                    )}

                    {/* Caption */}
                    {image.caption && (
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-3 rounded-b-lg">
                        <p className="text-white text-sm">{image.caption}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}