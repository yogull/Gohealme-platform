import { User, Biometric } from "@shared/schema";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBiometricSchema } from "@shared/schema";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useTutorial } from "@/hooks/useTutorial";
import { useLocation } from "wouter";
import { Sidebar } from "@/components/Sidebar";
import { MobileNav } from "@/components/MobileNav";
import { BiometricChart } from "@/components/BiometricChart";
import { PageHeader } from "@/components/PageHeader";
import { TutorialPopup } from "@/components/TutorialPopup";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useEffect } from "react";

const biometricFormSchema = insertBiometricSchema.extend({
  steps: z.number().min(0, "Steps must be a positive number").optional(),
  sleepHours: z.number().min(0, "Sleep hours must be positive").max(24, "Sleep cannot exceed 24 hours").optional(),
  weight: z.number().min(0, "Weight must be positive").optional(),
  heartRate: z.number().min(30, "Heart rate seems too low").max(220, "Heart rate seems too high").optional(),
});

type BiometricFormData = z.infer<typeof biometricFormSchema>;

export default function Biometrics() {
  const { appUser, loading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [location] = useLocation();
  const { shouldShowTutorial, getTutorialSteps, markTutorialComplete } = useTutorial();

  const form = useForm<BiometricFormData>({
    resolver: zodResolver(biometricFormSchema),
    defaultValues: {
      userId: appUser?.id || 0,
      date: new Date(),
      steps: undefined,
      sleepHours: undefined,
      weight: undefined,
      heartRate: undefined,
    },
  });

  // Update userId when appUser changes
  useEffect(() => {
    if (appUser) {
      form.setValue("userId", appUser.id);
    }
  }, [appUser, form]);

  const { data: biometrics, isLoading: biometricsLoading } = useQuery<Biometric[]>({
    queryKey: [`/api/biometrics/${appUser?.id}`],
    enabled: !!appUser?.id,
  });

  const { data: latestBiometric } = useQuery<Biometric>({
    queryKey: [`/api/biometrics/${appUser?.id}/latest`],
    enabled: !!appUser?.id,
  });

  const createBiometricMutation = useMutation({
    mutationFn: async (data: BiometricFormData) => {
      // Convert weight to grams and sleep to minutes for storage
      const processedData = {
        ...data,
        date: new Date(data.date!).toISOString(),
        weight: data.weight ? Math.round(data.weight * 1000) : undefined, // kg to grams
        sleepHours: data.sleepHours ? Math.round(data.sleepHours * 60) : undefined, // hours to minutes
      };
      return apiRequest("POST", "/api/biometrics", processedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/biometrics/${appUser?.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/biometrics/${appUser?.id}/latest`] });
      queryClient.invalidateQueries({ queryKey: [`/api/dashboard/${appUser?.id}`] });
      toast({
        title: "Biometric data saved!",
        description: "Your health data has been recorded successfully.",
      });
      form.reset({
        userId: appUser?.id || 0,
        date: new Date().toISOString().split('T')[0],
        steps: undefined,
        sleepHours: undefined,
        weight: undefined,
        heartRate: undefined,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save biometric data. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    createBiometricMutation.mutate(data);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-pulse text-center">
          <div className="w-16 h-16 bg-gray-200 rounded-xl mx-auto mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-32 mx-auto"></div>
        </div>
      </div>
    );
  }

  if (!appUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Please sign in</h2>
          <a href="/login" className="text-primary hover:text-primary/80">
            Go to login page
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="lg:flex lg:h-screen">
      <Sidebar user={appUser} />
      <MobileNav user={appUser} />
      
      <main className="flex-1 overflow-auto">
        <div className="bg-white border-b border-gray-200 px-4 lg:px-8 py-6">
          <PageHeader 
            title="Biometric Data" 
            subtitle="Track your daily health metrics"
          />
        </div>

        <div className="p-4 lg:p-8 space-y-8 pb-20 lg:pb-8">
          {/* Current Stats Overview */}
          {latestBiometric && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-walking text-blue-600 text-lg"></i>
                  </div>
                  <p className="text-2xl font-bold text-gray-900">
                    {latestBiometric.steps?.toLocaleString() || 'N/A'}
                  </p>
                  <p className="text-sm text-gray-600">Steps Today</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-moon text-purple-600 text-lg"></i>
                  </div>
                  <p className="text-2xl font-bold text-gray-900">
                    {latestBiometric.sleepHours ? `${(latestBiometric.sleepHours / 60).toFixed(1)}h` : 'N/A'}
                  </p>
                  <p className="text-sm text-gray-600">Sleep Duration</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-weight text-green-600 text-lg"></i>
                  </div>
                  <p className="text-2xl font-bold text-gray-900">
                    {latestBiometric.weight ? `${(latestBiometric.weight / 1000).toFixed(1)} kg` : 'N/A'}
                  </p>
                  <p className="text-sm text-gray-600">Weight</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-heartbeat text-red-600 text-lg"></i>
                  </div>
                  <p className="text-2xl font-bold text-gray-900">
                    {latestBiometric.heartRate || 'N/A'}
                  </p>
                  <p className="text-sm text-gray-600">Heart Rate (BPM)</p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Add New Biometric Data */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <i className="fas fa-plus-circle text-primary"></i>
                <span>Log Today's Metrics</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      {...form.register("date")}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="steps">Steps</Label>
                    <Input
                      id="steps"
                      type="number"
                      placeholder="e.g., 8500"
                      {...form.register("steps", { valueAsNumber: true })}
                    />
                    {form.formState.errors.steps && (
                      <p className="text-sm text-red-600">{form.formState.errors.steps.message}</p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sleepHours">Sleep Duration (hours)</Label>
                    <Input
                      id="sleepHours"
                      type="number"
                      step="0.5"
                      placeholder="e.g., 7.5"
                      {...form.register("sleepHours", { valueAsNumber: true })}
                    />
                    {form.formState.errors.sleepHours && (
                      <p className="text-sm text-red-600">{form.formState.errors.sleepHours.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      step="0.1"
                      placeholder="e.g., 70.5"
                      {...form.register("weight", { valueAsNumber: true })}
                    />
                    {form.formState.errors.weight && (
                      <p className="text-sm text-red-600">{form.formState.errors.weight.message}</p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="heartRate">Resting Heart Rate (BPM)</Label>
                    <Input
                      id="heartRate"
                      type="number"
                      placeholder="e.g., 65"
                      {...form.register("heartRate", { valueAsNumber: true })}
                    />
                    {form.formState.errors.heartRate && (
                      <p className="text-sm text-red-600">{form.formState.errors.heartRate.message}</p>
                    )}
                  </div>
                </div>

                <div className="flex space-x-4">
                  <Button 
                    type="submit" 
                    className="bg-primary hover:bg-primary/90 flex-1"
                    disabled={createBiometricMutation.isPending}
                  >
                    {createBiometricMutation.isPending ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Saving...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-save mr-2"></i>
                        Save Metrics
                      </>
                    )}
                  </Button>
                  
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => form.reset()}
                    disabled={createBiometricMutation.isPending}
                  >
                    Clear
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Charts */}
          {biometrics && biometrics.length > 0 && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <BiometricChart 
                title="Activity Trends"
                subtitle="Your daily steps over time"
                data={biometrics}
                type="biometrics"
              />
              <BiometricChart 
                title="Health Overview"
                subtitle="Sleep and activity patterns"
                data={biometrics}
                type="compliance"
              />
            </div>
          )}

          {/* Recent Entries */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Entries</CardTitle>
            </CardHeader>
            <CardContent>
              {biometricsLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                      <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : !biometrics || biometrics.length === 0 ? (
                <div className="text-center py-8">
                  <i className="fas fa-chart-line text-4xl text-gray-300 mb-4"></i>
                  <h4 className="text-lg font-medium text-gray-900 mb-2">No biometric data yet</h4>
                  <p className="text-gray-600">Start logging your health metrics to see trends and insights.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {biometrics.slice(0, 5).map((entry) => (
                    <div key={entry.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                      <div className="w-12 h-12 bg-primary-light rounded-lg flex items-center justify-center">
                        <i className="fas fa-chart-line text-primary-dark text-lg"></i>
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">
                          {new Date(entry.date).toLocaleDateString('en-US', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric'
                          })}
                        </p>
                        <div className="text-sm text-gray-600 mt-1">
                          {entry.steps && <span className="mr-4">🚶 {entry.steps.toLocaleString()} steps</span>}
                          {entry.sleepHours && <span className="mr-4">😴 {(entry.sleepHours / 60).toFixed(1)}h sleep</span>}
                          {entry.weight && <span className="mr-4">⚖️ {(entry.weight / 1000).toFixed(1)} kg</span>}
                          {entry.heartRate && <span>❤️ {entry.heartRate} BPM</span>}
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {biometrics.length > 5 && (
                    <div className="text-center pt-4">
                      <p className="text-sm text-gray-500">
                        Showing 5 of {biometrics.length} entries
                      </p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Tutorial popup for first-time visitors */}
      {shouldShowTutorial(location) && (
        <TutorialPopup
          page={location}
          steps={getTutorialSteps(location)}
          onComplete={() => markTutorialComplete(location)}
          onSkip={() => markTutorialComplete(location)}
        />
      )}
    </div>
  );
}
