import React from 'react';

export default function SimpleWorking() {
  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#f8fafc',
      padding: '20px',
      fontFamily: 'Arial, sans-serif'
    }}>
      {/* Header */}
      <div style={{
        backgroundColor: 'white',
        padding: '15px',
        borderRadius: '8px',
        marginBottom: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button 
            onClick={() => window.location.href = '/dashboard'}
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              border: 'none',
              padding: '8px 16px',
              borderRadius: '6px',
              cursor: 'pointer'
            }}
          >
            ← Back to Dashboard
          </button>
          <button 
            onClick={() => window.location.href = '/social'}
            style={{
              backgroundColor: '#16a34a',
              color: 'white',
              border: 'none',
              padding: '8px 16px',
              borderRadius: '6px',
              cursor: 'pointer'
            }}
          >
            Social Hub
          </button>
        </div>
      </div>

      {/* Cover Photo */}
      <div style={{
        height: '200px',
        background: 'linear-gradient(45deg, #3b82f6, #8b5cf6)',
        borderRadius: '12px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: '60px',
        position: 'relative',
        cursor: 'pointer'
      }}
      onClick={() => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.onchange = async (e) => {
          const file = (e.target as HTMLInputElement).files?.[0];
          if (!file) return;
          
          const reader = new FileReader();
          reader.onload = async (e) => {
            const base64 = e.target?.result as string;
            try {
              await fetch('/api/files/upload', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  fileName: `cover_${Date.now()}.jpg`,
                  fileData: base64,
                  userId: 4
                })
              });
              alert('Cover photo uploaded! Refreshing...');
              window.location.reload();
            } catch (error) {
              alert('Upload failed');
            }
          };
          reader.readAsDataURL(file);
        };
        input.click();
      }}>
        <div style={{ textAlign: 'center', color: 'white' }}>
          <div style={{ fontSize: '48px', marginBottom: '10px' }}>📷</div>
          <h2 style={{ margin: '0 0 8px 0', fontSize: '24px' }}>Add Cover Photo</h2>
          <p style={{ margin: 0, fontSize: '16px', opacity: 0.9 }}>Click to upload</p>
        </div>
      </div>

      {/* Profile Section */}
      <div style={{ marginTop: '-40px', paddingLeft: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'end', marginBottom: '20px' }}>
          <div 
            style={{
              width: '120px',
              height: '120px',
              borderRadius: '50%',
              background: 'linear-gradient(45deg, #3b82f6, #8b5cf6)',
              border: '4px solid white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
              fontSize: '48px',
              fontWeight: 'bold',
              cursor: 'pointer',
              position: 'relative'
            }}
            onClick={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = 'image/*';
              input.onchange = async (e) => {
                const file = (e.target as HTMLInputElement).files?.[0];
                if (!file) return;
                
                const reader = new FileReader();
                reader.onload = async (e) => {
                  const base64 = e.target?.result as string;
                  try {
                    await fetch('/api/files/upload', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        fileName: `profile_${Date.now()}.jpg`,
                        fileData: base64,
                        userId: 4
                      })
                    });
                    alert('Profile photo uploaded! Refreshing...');
                    window.location.reload();
                  } catch (error) {
                    alert('Upload failed');
                  }
                };
                reader.readAsDataURL(file);
              };
              input.click();
            }}
          >
            J
          </div>
          
          <div style={{ marginLeft: '20px', paddingBottom: '10px' }}>
            <h1 style={{ 
              margin: '0 0 8px 0', 
              fontSize: '32px', 
              color: '#1f2937' 
            }}>
              John Proctor
            </h1>
            <p style={{ 
              margin: '0 0 8px 0', 
              fontSize: '18px', 
              color: '#6b7280' 
            }}>
              Community Leader & Platform Creator
            </p>
            <p style={{ 
              margin: 0, 
              fontSize: '14px', 
              color: '#9ca3af' 
            }}>
              Ordinary People Community - Away from Elite Control
            </p>
          </div>
        </div>

        {/* Money Making Card */}
        <div style={{
          backgroundColor: '#f0fdf4',
          border: '2px solid #16a34a',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '30px'
        }}>
          <h3 style={{ 
            margin: '0 0 12px 0', 
            color: '#15803d', 
            fontSize: '20px' 
          }}>
            💰 Start Making Money Today!
          </h3>
          <p style={{ 
            margin: '0 0 16px 0', 
            color: '#166534', 
            fontSize: '16px' 
          }}>
            Personal Affiliate Shop: Add your Amazon/eBay links and earn commissions. £1 per link for first 20!
          </p>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button 
              onClick={() => window.location.href = '/shop'}
              style={{
                backgroundColor: '#16a34a',
                color: 'white',
                border: 'none',
                padding: '12px 20px',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight: 'bold'
              }}
            >
              Set Up My Shop
            </button>
            <button 
              onClick={() => window.location.href = '/location-ads'}
              style={{
                backgroundColor: 'white',
                color: '#16a34a',
                border: '2px solid #16a34a',
                padding: '12px 20px',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '16px'
              }}
            >
              Browse Businesses
            </button>
          </div>
        </div>

        {/* Three Share Buttons */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '30px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ 
            margin: '0 0 16px 0', 
            fontSize: '24px', 
            color: '#1f2937' 
          }}>
            Share Content
          </h2>
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', 
            gap: '12px' 
          }}>
            <button style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              border: 'none',
              padding: '16px',
              borderRadius: '8px',
              cursor: 'pointer',
              textAlign: 'center',
              fontSize: '14px',
              fontWeight: 'bold'
            }}>
              🌍<br/>OPC Wall
            </button>
            <button style={{
              backgroundColor: '#16a34a',
              color: 'white',
              border: 'none',
              padding: '16px',
              borderRadius: '8px',
              cursor: 'pointer',
              textAlign: 'center',
              fontSize: '14px',
              fontWeight: 'bold'
            }}>
              👤<br/>My Wall
            </button>
            <button style={{
              backgroundColor: '#8b5cf6',
              color: 'white',
              border: 'none',
              padding: '16px',
              borderRadius: '8px',
              cursor: 'pointer',
              textAlign: 'center',
              fontSize: '14px',
              fontWeight: 'bold'
            }}>
              🚀<br/>Multi-Share
            </button>
          </div>
        </div>

        {/* Posts Section */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '30px',
          textAlign: 'center',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ 
            margin: '0 0 20px 0', 
            fontSize: '24px', 
            color: '#1f2937' 
          }}>
            Ready to Launch Your Success
          </h2>
          <div style={{ 
            fontSize: '64px', 
            marginBottom: '16px' 
          }}>
            🚀
          </div>
          <p style={{ 
            margin: '0 0 20px 0', 
            fontSize: '18px', 
            color: '#6b7280' 
          }}>
            Platform is operational and ready for money-making!
          </p>
          <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
            <button 
              onClick={() => window.location.href = '/community'}
              style={{
                backgroundColor: '#3b82f6',
                color: 'white',
                border: 'none',
                padding: '12px 24px',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '16px'
              }}
            >
              Browse Discussions
            </button>
            <button 
              onClick={() => window.location.href = '/shop'}
              style={{
                backgroundColor: '#16a34a',
                color: 'white',
                border: 'none',
                padding: '12px 24px',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '16px'
              }}
            >
              Start Earning
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}