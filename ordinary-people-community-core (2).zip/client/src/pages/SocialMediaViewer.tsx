import { useParams, Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowLeft, ExternalLink, Users, MessageSquare, Heart, Share2 } from 'lucide-react';
import { useState } from 'react';

const platformData = {
  facebook: {
    name: 'Facebook',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    description: 'Connect with friends and the world around you on Facebook.',
    url: 'https://facebook.com'
  },
  twitter: {
    name: 'Twitter',
    color: 'text-blue-400',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    description: 'See what\'s happening in the world right now.',
    url: 'https://twitter.com'
  },
  instagram: {
    name: 'Instagram',
    color: 'text-pink-600',
    bgColor: 'bg-pink-50',
    borderColor: 'border-pink-200',
    description: 'Explore photos and videos from friends and discover new accounts.',
    url: 'https://instagram.com'
  },
  linkedin: {
    name: 'LinkedIn',
    color: 'text-blue-700',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    description: 'Connect with professionals and advance your career.',
    url: 'https://linkedin.com'
  },
  youtube: {
    name: 'YouTube',
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200',
    description: 'Watch, share and discover videos from creators worldwide.',
    url: 'https://youtube.com'
  },
  tiktok: {
    name: 'TikTok',
    color: 'text-black',
    bgColor: 'bg-gray-50',
    borderColor: 'border-gray-300',
    description: 'Discover short-form videos and join the global TikTok community.',
    url: 'https://tiktok.com'
  },
  rumble: {
    name: 'Rumble',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200',
    description: 'Free speech video platform - share and discover uncensored content.',
    url: 'https://rumble.com'
  },
  telegram: {
    name: 'Telegram',
    color: 'text-blue-500',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    description: 'Fast, secure messaging and channels for communities worldwide.',
    url: 'https://telegram.org'
  }
};

export default function SocialMediaViewer() {
  const { platform } = useParams();
  const platformInfo = platformData[platform as keyof typeof platformData];
  const [handle, setHandle] = useState('');

  if (!platformInfo) {
    return (
      <div className="w-full mx-auto p-4 bg-white min-h-screen">
        <Card>
          <CardContent className="p-8 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Platform Not Found</h1>
            <p className="text-gray-600 mb-6">The social media platform you're looking for doesn't exist.</p>
            <Link href="/profile-wall/4">
              <Button>Return to Profile Wall</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="w-full mx-auto p-4 bg-white min-h-screen">
      {/* Navigation Header */}
      <Card className="mb-6 bg-white border shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/profile-wall/4">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Profile Wall
                </Button>
              </Link>
              <h1 className={`text-2xl font-bold ${platformInfo.color}`}>
                {platformInfo.name} on OPC
              </h1>
            </div>
            
            <Button
              onClick={() => window.open(platformInfo.url, '_blank')}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Open {platformInfo.name}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Platform Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-6">
          <Card className={`${platformInfo.bgColor} ${platformInfo.borderColor} border-2`}>
            <CardHeader>
              <CardTitle className={platformInfo.color}>
                Welcome to {platformInfo.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4">{platformInfo.description}</p>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.open(platformInfo.url, '_blank')}
                >
                  Visit {platformInfo.name}
                </Button>
                <Button variant="outline" size="sm">
                  Connect Account
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Sample Social Media Feed */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">
              {platformInfo.name} Integration Preview
            </h3>
            
            {[1, 2, 3].map((post) => (
              <Card key={post} className="bg-white border shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold">U</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h4 className="font-medium">Sample User</h4>
                        <span className="text-sm text-gray-500">2h ago</span>
                      </div>
                      <p className="text-gray-800 mb-3">
                        This is a sample post showing how {platformInfo.name} content would appear in OPC.
                        Cross-posting from Profile Wall enables seamless social media integration.
                      </p>
                      <div className="flex items-center space-x-6 text-gray-500">
                        <button className="flex items-center space-x-1 hover:text-red-500">
                          <Heart className="h-4 w-4" />
                          <span>12</span>
                        </button>
                        <button className="flex items-center space-x-1 hover:text-blue-500">
                          <MessageSquare className="h-4 w-4" />
                          <span>3</span>
                        </button>
                        <button className="flex items-center space-x-1 hover:text-green-500">
                          <Share2 className="h-4 w-4" />
                          <span>Share</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card className="bg-white border shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">OPC Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded">
                <Users className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">Community Members</p>
                  <p className="text-sm text-gray-600">Connect with OPC users</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded">
                <MessageSquare className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">Cross-Platform Chat</p>
                  <p className="text-sm text-gray-600">Unified messaging system</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded">
                <Share2 className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="font-medium">Multi-Share Posts</p>
                  <p className="text-sm text-gray-600">Post to all platforms at once</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link href="/profile-wall/4">
                <Button variant="outline" className="w-full justify-start">
                  Return to Profile Wall
                </Button>
              </Link>
              <Link href="/community">
                <Button variant="outline" className="w-full justify-start">
                  Community Discussions
                </Button>
              </Link>
              <Link href="/chat">
                <Button variant="outline" className="w-full justify-start">
                  Chat & Messaging
                </Button>
              </Link>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.open(platformInfo.url, '_blank')}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Open {platformInfo.name}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Connect your Media Section */}
      <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200">
        <CardHeader>
          <CardTitle className="text-xl text-center text-blue-700">
            Connect your Media
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-center text-gray-700 mb-4">
            Connect your {platformInfo.name} account to enable cross-posting from OPC Profile Wall
          </p>
          
          <div className="flex flex-col space-y-3">
            <div className="flex items-center space-x-3">
              <label className="w-20 text-sm font-medium text-gray-700">Handle:</label>
              <Input
                type="text"
                placeholder={`Your ${platformInfo.name} username`}
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                className="flex-1"
              />
            </div>
            
            <div className="flex justify-center space-x-3">
              <Button 
                className="bg-blue-600 hover:bg-blue-700 text-white"
                onClick={() => {
                  if (handle.trim()) {
                    // Store handle for cross-posting functionality
                    localStorage.setItem(`${platform}_handle`, handle.trim());
                    alert(`${platformInfo.name} handle saved: @${handle.trim()}`);
                  } else {
                    alert('Please enter your username/handle');
                  }
                }}
              >
                Connect Account
              </Button>
              
              <Button 
                variant="outline"
                onClick={() => {
                  const savedHandle = localStorage.getItem(`${platform}_handle`);
                  if (savedHandle) {
                    setHandle(savedHandle);
                    alert(`Loaded saved handle: @${savedHandle}`);
                  } else {
                    alert('No saved handle found');
                  }
                }}
              >
                Load Saved
              </Button>
            </div>
          </div>
          
          <div className="mt-4 p-3 bg-white rounded border">
            <h4 className="font-medium text-gray-900 mb-2">How it works:</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Enter your {platformInfo.name} username/handle above</li>
              <li>• Click "Connect Account" to save your credentials</li>
              <li>• Use Multi-Share from Profile Wall to post simultaneously</li>
              <li>• Your posts will open {platformInfo.name} with pre-filled content</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}