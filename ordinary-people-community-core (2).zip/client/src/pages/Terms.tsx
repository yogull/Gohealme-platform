/**
 * Copyright (c) 2025 John Proctor. All rights reserved.
 * The People's Health Community Platform
 * Terms of Service - Legal Protection Document
 */

import { PageHeader } from "@/components/PageHeader";
import { useTranslation } from "@/hooks/useTranslation";

export default function Terms() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gray-50">
      <PageHeader
        title="Terms of Service"
        subtitle="Legal Terms and Intellectual Property Rights"
      />
      
      <div className="max-w-4xl mx-auto px-4 py-8 protected-content">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <div className="prose max-w-none">
            
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Intellectual Property Rights</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  <strong>Platform Ownership:</strong> The People's Health Community platform, including all software, 
                  source code, algorithms, user interfaces, designs, graphics, text, and functionality 
                  (collectively, the "Platform") is owned by John Proctor and protected by copyright, 
                  trademark, and other intellectual property laws.
                </p>
                <p>
                  <strong>Copyright Notice:</strong> © 2025 John Proctor. All rights reserved. 
                  The Platform is protected under UK and international copyright law.
                </p>
                <p>
                  <strong>Prohibited Uses:</strong> You may not reproduce, distribute, modify, create derivative works, 
                  publicly display, publicly perform, republish, download, store, or transmit any portion of the Platform, 
                  except as permitted by these Terms.
                </p>
                <p>
                  <strong>Code Protection:</strong> Any attempt to reverse engineer, decompile, disassemble, 
                  or otherwise attempt to derive the source code of the Platform is strictly prohibited 
                  and may result in legal action.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">2. User License</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  Subject to these Terms, we grant you a limited, non-exclusive, non-transferable, 
                  non-sublicensable license to access and use the Platform solely for your personal, 
                  non-commercial use.
                </p>
                <p>
                  This license does not include any right to: (a) resell or make commercial use of the Platform; 
                  (b) modify or make derivative works of the Platform; (c) use data mining, robots, or 
                  similar data gathering tools; or (d) download any portion of the Platform except as 
                  expressly permitted.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">3. User Content and Data</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  <strong>Content Ownership:</strong> You retain ownership of any content you submit, 
                  including health data, posts, comments, and images. However, by submitting content, 
                  you grant us a worldwide, royalty-free license to use, display, and distribute 
                  your content in connection with the Platform.
                </p>
                <p>
                  <strong>Health Data:</strong> We treat your health information with the highest level 
                  of security and privacy. Your health data remains your property and is protected 
                  according to our Privacy Policy.
                </p>
                <p>
                  <strong>Community Guidelines:</strong> All user-generated content must comply with 
                  our community standards and applicable laws.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Commercial Use and Advertising</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  <strong>Business Advertising:</strong> Business users may purchase advertising packages 
                  for £24/year to promote their products and services on the Platform.
                </p>
                <p>
                  <strong>Affiliate Marketing:</strong> The Platform may contain affiliate links to 
                  third-party products and services. We may receive commissions from purchases made 
                  through these links.
                </p>
                <p>
                  <strong>Revenue Sharing:</strong> Any revenue generated through the Platform remains 
                  the property of John Proctor and the Platform operators.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">5. DMCA and Copyright Protection</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  We respect intellectual property rights and expect users to do the same. 
                  If you believe your copyrighted work has been infringed, please contact us at 
                  gohealme.org@gmail.com with the following information:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Description of the copyrighted work claimed to be infringed</li>
                  <li>Location of the infringing material on the Platform</li>
                  <li>Your contact information</li>
                  <li>Statement of good faith belief that use is not authorized</li>
                  <li>Statement of accuracy and authority to act on behalf of copyright owner</li>
                  <li>Physical or electronic signature</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Prohibited Activities</h2>
              <div className="space-y-4 text-gray-700">
                <p>You agree not to:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Copy, reproduce, or distribute any part of the Platform's source code</li>
                  <li>Attempt to reverse engineer or decompile the Platform</li>
                  <li>Use automated systems to access the Platform without permission</li>
                  <li>Interfere with the Platform's security features</li>
                  <li>Create derivative works based on the Platform</li>
                  <li>Use the Platform for any illegal or unauthorized purpose</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Termination</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  We may terminate or suspend your access to the Platform immediately, without prior notice, 
                  if you breach these Terms or engage in prohibited activities.
                </p>
                <p>
                  Upon termination, your right to use the Platform ceases immediately, and you must 
                  destroy all copies of Platform materials in your possession.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Governing Law</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  These Terms are governed by the laws of England and Wales. Any disputes will be 
                  resolved in the courts of England and Wales.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Contact Information</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  For questions about these Terms or to report copyright infringement, contact us at:
                </p>
                <p>
                  <strong>Email:</strong> ordinarypeoplecommunity.com@gmail.com<br/>
                  <strong>Website:</strong> ordinarypeoplecommunity.com<br/>
                  <strong>Owner:</strong> John Proctor
                </p>
              </div>
            </section>

            <div className="mt-8 pt-6 border-t border-gray-200">
              <p className="text-sm text-gray-500">
                Last updated: June 19, 2025<br/>
                © 2025 John Proctor - Ordinary People Community. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}