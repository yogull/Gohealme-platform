import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MessageSquare, Users, Plus, Share2, Search, Calendar, Filter, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';

interface Discussion {
  id: number;
  userId: number;
  categoryId: number;
  title: string;
  description: string;
  location?: string;
  tags: string[] | null;
  participantCount?: number;
  messageCount?: number;
  isActive?: boolean;
  createdAt: string;
  updatedAt?: string;
  autoCategory?: string;
  subcategory?: string;
}

const categories = [
  { id: 1, name: 'Government & Politics', icon: '🏛️', keywords: ['government', 'politics', 'election', 'policy', 'minister', 'mp', 'council', 'tax', 'voting', 'parliament'] },
  { id: 2, name: 'Health & Wellness', icon: '🏥', keywords: ['health', 'medical', 'doctor', 'hospital', 'nhs', 'medicine', 'treatment', 'wellness', 'fitness', 'mental'] },
  { id: 3, name: 'Environment & Climate', icon: '🌍', keywords: ['environment', 'climate', 'pollution', 'green', 'sustainability', 'recycling', 'carbon', 'energy', 'weather'] },
  { id: 4, name: 'Technology & Digital', icon: '💻', keywords: ['technology', 'digital', 'internet', 'computer', 'software', 'app', 'online', 'tech', 'ai', 'data'] },
  { id: 5, name: 'Community & Social', icon: '🤝', keywords: ['community', 'social', 'local', 'neighborhood', 'volunteer', 'charity', 'help', 'support', 'events'] },
  { id: 6, name: 'Education & Learning', icon: '📚', keywords: ['education', 'school', 'university', 'learning', 'teaching', 'student', 'course', 'training', 'study'] },
  { id: 7, name: 'Economy & Finance', icon: '💰', keywords: ['economy', 'finance', 'money', 'business', 'job', 'work', 'employment', 'cost', 'price', 'budget'] },
  { id: 8, name: 'Transport & Travel', icon: '🚗', keywords: ['transport', 'travel', 'bus', 'train', 'car', 'road', 'traffic', 'journey', 'airport', 'station'] },
];

// Auto-categorization function
const autoDetectCategory = (title: string, description: string) => {
  const text = (title + ' ' + description).toLowerCase();
  for (const category of categories) {
    for (const keyword of category.keywords) {
      if (text.includes(keyword)) {
        return {
          categoryId: category.id,
          categoryName: category.name,
          detectedKeyword: keyword
        };
      }
    }
  }
  return { categoryId: 5, categoryName: 'Community & Social', detectedKeyword: 'general' }; // Default
};

export default function CommunityFixed() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isCreating, setIsCreating] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [selectedDiscussion, setSelectedDiscussion] = useState<string>('');
  const [discussions, setDiscussions] = useState<Discussion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [newDiscussion, setNewDiscussion] = useState({
    title: '',
    description: '',
    categoryId: '',
    location: '',
    tags: ''
  });

  // Fetch discussions
  useEffect(() => {
    const loadDiscussions = async () => {
      try {
        setIsLoading(true);
        const response = await fetch('/api/discussions');
        if (response.ok) {
          const data = await response.json();
          
          // Apply sliding window: keep latest 50, archive older ones
          const latestDiscussions = data.slice(0, 50);
          
          // Auto-categorize discussions
          const categorizedDiscussions = latestDiscussions.map((discussion: Discussion) => {
            const autoCategory = autoDetectCategory(discussion.title, discussion.description);
            return {
              ...discussion,
              autoCategory: autoCategory.categoryName,
              subcategory: autoCategory.detectedKeyword,
              categoryId: autoCategory.categoryId
            };
          });
          
          setDiscussions(categorizedDiscussions);
          console.log(`✅ Loaded ${categorizedDiscussions.length} discussions with auto-categorization`);
          
          // Archive older discussions to brain storage
          if (data.length > 50) {
            const archivedDiscussions = data.slice(50);
            await archiveDiscussions(archivedDiscussions);
          }
        } else {
          setError('Failed to load discussions');
        }
      } catch (err) {
        setError('Network error loading discussions');
        console.error('Error loading discussions:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadDiscussions();
  }, []);

  // Archive discussions to brain storage
  const archiveDiscussions = async (oldDiscussions: Discussion[]) => {
    try {
      const categorizedArchive = oldDiscussions.map(discussion => {
        const autoCategory = autoDetectCategory(discussion.title, discussion.description);
        return {
          ...discussion,
          category: autoCategory.categoryName,
          subcategory: autoCategory.detectedKeyword,
          archivedDate: new Date().toISOString()
        };
      });

      await fetch('/api/brain/archive-discussions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ discussions: categorizedArchive })
      });
      
      console.log(`📚 Archived ${oldDiscussions.length} discussions to brain storage`);
    } catch (error) {
      console.error('Failed to archive discussions:', error);
    }
  };

  const communityPosts: Discussion[] = discussions;

  // Enhanced filtering with category/subcategory support
  const filteredPosts = communityPosts.filter(post => {
    const matchesCategory = selectedCategory === 'all' || post.categoryId === parseInt(selectedCategory);
    const matchesSearch = !searchTerm || 
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (post.autoCategory && post.autoCategory.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (post.subcategory && post.subcategory.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesDate = !dateFilter || post.createdAt.includes(dateFilter);
    const matchesDiscussion = !selectedDiscussion || post.id.toString() === selectedDiscussion;
    return matchesCategory && matchesSearch && matchesDate && matchesDiscussion;
  });

  // Discussion dropdown options (latest 30 for dropdown)
  const discussionOptions = discussions.slice(0, 30).map(discussion => ({
    value: discussion.id.toString(),
    label: discussion.title.length > 50 ? 
      discussion.title.substring(0, 50) + '...' : 
      discussion.title
  }));

  const handleCreateDiscussion = async () => {
    if (!newDiscussion.title.trim() || !newDiscussion.description.trim()) {
      alert('Please fill in both title and description');
      return;
    }

    try {
      // Auto-detect category before submitting
      const autoCategory = autoDetectCategory(newDiscussion.title, newDiscussion.description);
      
      const response = await fetch('/api/discussions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newDiscussion,
          categoryId: autoCategory.categoryId,
          tags: newDiscussion.tags ? newDiscussion.tags.split(',').map(t => t.trim()) : [autoCategory.detectedKeyword],
        }),
      });

      if (response.ok) {
        alert(`Discussion created in "${autoCategory.categoryName}" category!`);
        setNewDiscussion({ title: '', description: '', categoryId: '', location: '', tags: '' });
        setIsCreating(false);
        window.location.reload();
      } else {
        throw new Error('Failed to create discussion');
      }
    } catch (error) {
      alert('Failed to create discussion. Please try again.');
    }
  };

  // Search archived discussions
  const searchArchive = async (searchQuery: string) => {
    try {
      const response = await fetch(`/api/brain/search-archive?q=${encodeURIComponent(searchQuery)}`);
      if (response.ok) {
        const archived = await response.json();
        console.log(`🔍 Found ${archived.length} archived discussions matching "${searchQuery}"`);
        return archived;
      }
    } catch (error) {
      console.error('Error searching archive:', error);
    }
    return [];
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Community Discussions</h1>
          <p className="text-gray-600">Smart categorization • Latest 50 active • Searchable archive</p>
        </div>

        {/* Enhanced Search and Filter Bar */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search discussions, categories..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category.id} value={category.id.toString()}>
                      {category.icon} {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedDiscussion} onValueChange={setSelectedDiscussion}>
                <SelectTrigger>
                  <SelectValue placeholder="Jump to discussion" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Discussions</SelectItem>
                  {discussionOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                placeholder="Filter by date"
              />
            </div>
            
            <div className="flex justify-between items-center mt-4">
              <Button onClick={() => setIsCreating(true)} className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Create Discussion
              </Button>
              <Button 
                variant="outline" 
                onClick={() => searchArchive(searchTerm)}
                className="flex items-center gap-2"
              >
                <Search className="w-4 h-4" />
                Search Archive
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Create Discussion Form */}
        {isCreating && (
          <Card className="mb-6">
            <CardHeader>
              <h3 className="text-lg font-semibold">Create New Discussion</h3>
              <p className="text-sm text-gray-600">Category will be automatically detected from your content</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Title</label>
                  <Input
                    placeholder="What would you like to discuss?"
                    value={newDiscussion.title}
                    onChange={(e) => setNewDiscussion({...newDiscussion, title: e.target.value})}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <Textarea
                    placeholder="Provide details about your discussion topic..."
                    value={newDiscussion.description}
                    onChange={(e) => setNewDiscussion({...newDiscussion, description: e.target.value})}
                    rows={4}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Location (Optional)</label>
                    <Input
                      placeholder="e.g., London, UK"
                      value={newDiscussion.location}
                      onChange={(e) => setNewDiscussion({...newDiscussion, location: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Additional Tags</label>
                    <Input
                      placeholder="e.g., urgent, local, community"
                      value={newDiscussion.tags}
                      onChange={(e) => setNewDiscussion({...newDiscussion, tags: e.target.value})}
                    />
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button onClick={handleCreateDiscussion} className="flex-1">
                    Create Discussion (Auto-Categorized)
                  </Button>
                  <Button variant="outline" onClick={() => setIsCreating(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Discussions Display */}
        <div className="space-y-6">
          {isLoading ? (
            <Card>
              <CardContent className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                Loading community discussions...
              </CardContent>
            </Card>
          ) : error ? (
            <Card>
              <CardContent className="text-center py-8">
                <h3 className="text-lg font-semibold mb-2 text-red-600">Unable to load discussions</h3>
                <p className="text-gray-600 mb-4">{error}</p>
                <Button onClick={() => window.location.reload()}>
                  Refresh Page
                </Button>
              </CardContent>
            </Card>
          ) : filteredPosts.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <h3 className="text-lg font-semibold mb-2">No discussions found</h3>
                <p className="text-gray-600 mb-4">
                  {searchTerm ? "No discussions match your search. Try the archive search." : "Be the first to start a discussion!"}
                </p>
                <Button onClick={() => setIsCreating(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Discussion
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <div className="flex justify-between items-center">
                  <div>
                    <strong>✅ Smart Community Loaded!</strong>
                    <p>Showing {filteredPosts.length} discussions • Auto-categorized • Archive searchable</p>
                  </div>
                  <div className="text-right text-sm">
                    <p>Latest 50 active</p>
                    <p>Older archived to brain</p>
                  </div>
                </div>
              </div>
              
              {filteredPosts.map((post) => (
                <Card key={post.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                          {post.title.charAt(0)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">{post.title}</h3>
                          <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                            {post.autoCategory && (
                              <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                                {post.autoCategory}
                              </span>
                            )}
                            {post.subcategory && (
                              <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                                {post.subcategory}
                              </span>
                            )}
                            {post.location && <span>📍 {post.location}</span>}
                            <span>🗓️ {format(new Date(post.createdAt), 'MMM d, yyyy')}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <Users className="w-4 h-4" />
                        <span>{post.participantCount || 0}</span>
                        <MessageSquare className="w-4 h-4" />
                        <span>{post.messageCount || 0}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-4">{post.description}</p>
                    {post.tags && post.tags.length > 0 && (
                      <div className="flex flex-wrap gap-2 mb-4">
                        {post.tags.map((tag, index) => (
                          <span
                            key={index}
                            className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          window.location.href = `/category-discussion/${post.categoryId}?discussionId=${post.id}`;
                        }}
                      >
                        <MessageSquare className="w-4 h-4 mr-2" />
                        Join Discussion
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          navigator.clipboard.writeText(window.location.origin + `/category-discussion/${post.categoryId}?discussionId=${post.id}`);
                          alert('Discussion link copied!');
                        }}
                      >
                        <Share2 className="w-4 h-4 mr-2" />
                        Share
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
}