import { AdminCategoryManager } from "@/components/AdminCategoryManager";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function AdminCategories() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-2 md:p-4">
      <div className="max-w-[95vw] md:max-w-6xl mx-auto">
        <div className="mb-6">
          <Link href="/dashboard" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Admin: Discussion Categories</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Manage discussion categories for the community platform. Create, edit, and organize topics for user discussions.
          </p>
        </div>

        <div className="grid gap-6">
          <AdminCategoryManager />
          
          <Card>
            <CardHeader>
              <CardTitle>Category Management Guide</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Creating Categories</h3>
                <ul className="list-disc list-inside text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>Choose clear, descriptive names that users will understand</li>
                  <li>Add descriptions to help users know what belongs in each category</li>
                  <li>Select appropriate colors and icons for visual organization</li>
                  <li>Consider broad categories like "Health & Wellness", "Government & Policy", "Environmental Issues"</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">Best Practices</h3>
                <ul className="list-disc list-inside text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>Start with main category groups rather than specific subcategories</li>
                  <li>Use emojis as icons for better visual appeal and mobile friendliness</li>
                  <li>Choose colors that provide good contrast and accessibility</li>
                  <li>Categories cannot be deleted if they have existing discussions</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Current Category Structure</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  The platform supports main discussion categories that encourage broad community participation
                  in health, wellness, daily life issues, government topics, and local community matters.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}