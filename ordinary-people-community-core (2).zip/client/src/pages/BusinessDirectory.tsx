import React from "react";
import { BusinessDirectorySearch } from "@/components/BusinessDirectorySearch";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { PageNavigationGuide } from "@/components/PageNavigationGuide";

export default function BusinessDirectory() {
  const [, setLocation] = useLocation();
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Instructions Button */}
      <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50">
        <button 
          onClick={() => {
            const message = [
              "Business Directory Instructions:",
              "",
              "1. Select a country from the dropdown menu",
              "2. Choose a specific city or leave as 'All Countries' for broader search",
              "3. Click 'Search Businesses' to find local services",
              "4. Browse business cards showing company details and services",
              "5. Click any business card to view full profile with contact information",
              "6. Use 'Call', 'Email', 'Website', or 'Get Directions' buttons for direct contact",
              "7. Perfect for travelers seeking local services or residents finding nearby businesses",
              "",
              "Tips:",
              "• Business directory covers restaurants, shops, services, and professional businesses",
              "• Each business shows location, contact details, and website links",
              "• Tap anywhere on business cards to access full company profiles",
              "• Great for finding quality services when traveling or in new areas"
            ].join('\n');
            alert(message);
          }}
          className="bg-white border border-gray-300 hover:bg-gray-50 px-3 py-1 text-xs font-bold rounded shadow-sm"
        >
          Instructions
        </button>
      </div>

      <PageHeader title="Business Directory" showBackButton={true} showDashboardButton={true} />
      
      <div className="container mx-auto px-4 pb-8">
        <BusinessDirectorySearch />
      </div>
    </div>
  );
}