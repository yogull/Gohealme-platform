import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { AskAIButton } from "@/components/AskAIButton";
import { UniversalInstructionsButton } from "@/components/UniversalInstructionsButton";
import { useTranslation } from "@/hooks/useTranslation";
import { MessageCircle, Send, Users, Plus, Bot } from "lucide-react";
import { FloatingProfileButton } from "@/components/FloatingProfileButton";
import { BackButton } from "@/components/BackButton";
import { PageNavigationGuide } from "@/components/PageNavigationGuide";

import type { ChatRoom, ChatMessage, User } from "@shared/schema";

export default function Chat() {
  const { appUser: user } = useAuth();
  const queryClient = useQueryClient();
  const { t } = useTranslation();
  const [selectedRoom, setSelectedRoom] = useState<number | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [showUserList, setShowUserList] = useState(false);
  const [userSearchQuery, setUserSearchQuery] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Check if AI mode is enabled via URL parameter
  const urlParams = new URLSearchParams(window.location.search);
  const isAIMode = urlParams.get('ai') === 'true';

  const createAIRoom = async () => {
    try {
      // Create AI room using the same direct message approach
      const roomResponse = await apiRequest("POST", `/api/chat/direct/${user?.id}/999`, {});
      
      if (roomResponse.ok) {
        const roomData = await roomResponse.json();
        setSelectedRoom(roomData.id);
        
        queryClient.invalidateQueries({ queryKey: ['/api/chat/rooms', user?.id] });
        queryClient.invalidateQueries({ queryKey: ['/api/chat/rooms', roomData.id, 'messages'] });
      }
    } catch (error) {
      console.error("Failed to create AI chat room:", error);
    }
  };

  // Fetch user's chat rooms
  const { data: rooms = [], isLoading: roomsLoading } = useQuery({
    queryKey: ['/api/chat/rooms', user?.id],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/chat/rooms/${user?.id}`);
      return Array.isArray(response) ? response : [];
    },
    enabled: !!user?.id
  });

  // Auto-select or create AI chat room when in AI mode
  useEffect(() => {
    if (isAIMode && user?.id && !selectedRoom) {
      // Find existing AI direct message room (with user ID 999)
      const aiRoom = rooms.find(room => room.isDirectMessage);
      if (aiRoom) {
        setSelectedRoom(aiRoom.id);
      } else {
        // Create a new AI room for this user
        createAIRoom();
      }
    } else if (!isAIMode && !selectedRoom && !roomsLoading && rooms.length > 0) {
      // For regular chat, select the first available room
      setSelectedRoom(rooms[0].id);
    }
  }, [isAIMode, rooms, selectedRoom, user?.id, roomsLoading]);

  // Fetch messages for selected room
  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/chat/rooms', selectedRoom, 'messages'],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/chat/rooms/${selectedRoom}/messages`);
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
    enabled: !!selectedRoom,
    refetchInterval: 3000 // Poll for new messages every 3 seconds
  });

  // Fetch users for starting new conversations
  const { data: users = [] } = useQuery({
    queryKey: ['/api/users/search', userSearchQuery],
    queryFn: async () => {
      if (!userSearchQuery || userSearchQuery.length < 1) {
        return [];
      }
      const response = await apiRequest("GET", `/api/users/search?q=${encodeURIComponent(userSearchQuery)}`);
      const result = await response.json();
      console.log('User search results:', result);
      console.log('Current user ID:', user?.id);
      return Array.isArray(result) ? result : [];
    },
    enabled: showUserList && userSearchQuery.length >= 1
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: { content: string; senderId: number }) => {
      return apiRequest("POST", `/api/chat/rooms/${selectedRoom}/messages`, messageData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/rooms', selectedRoom, 'messages'] });
      setNewMessage("");
    }
  });

  // Start direct message mutation
  const startDirectMessageMutation = useMutation({
    mutationFn: async (otherUserId: number) => {
      const response = await apiRequest("POST", `/api/chat/direct/${user?.id}/${otherUserId}`, {});
      return response.json();
    },
    onSuccess: (room: any) => {
      console.log('Room created/retrieved:', room);
      queryClient.invalidateQueries({ queryKey: ['/api/chat/rooms', user?.id] });
      if (room && room.id) {
        setSelectedRoom(room.id);
        console.log('Selected room set to:', room.id);
      }
      setShowUserList(false);
      setUserSearchQuery("");
    },
    onError: (error) => {
      console.error('Failed to start direct message:', error);
    }
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Play notification sound for new messages
  const playNotificationSound = () => {
    try {
      // Create a simple notification beep
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.3);
    } catch (error) {
      console.log('Audio notification not supported');
    }
  };

  // Track previous message count to detect new messages
  const [prevMessageCount, setPrevMessageCount] = useState(0);
  const [showNewMessageIndicator, setShowNewMessageIndicator] = useState(false);
  
  useEffect(() => {
    if (messages.length > prevMessageCount && prevMessageCount > 0) {
      // Only play sound if the new message is not from the current user
      const latestMessage = messages[messages.length - 1];
      if (latestMessage?.senderId !== user?.id) {
        playNotificationSound();
        setShowNewMessageIndicator(true);
        
        // Hide indicator after 3 seconds
        setTimeout(() => {
          setShowNewMessageIndicator(false);
        }, 3000);
      }
    }
    setPrevMessageCount(messages.length);
  }, [messages, prevMessageCount, user?.id]);

  const handleSendMessage = () => {
    console.log('handleSendMessage called:', { newMessage, userId: user?.id, isAIMode, selectedRoom });
    
    if (!newMessage.trim() || !user?.id) return;
    
    // If in AI mode, use AI message handler
    if (isAIMode) {
      console.log('Routing to AI handler');
      handleSendDirectAIMessage();
      return;
    }
    
    // Regular chat mode
    if (!selectedRoom) return;
    
    console.log('Sending regular message');
    sendMessageMutation.mutate({
      content: newMessage.trim(),
      senderId: user.id
    });
  };

  const handleSendDirectAIMessage = async () => {
    if (!newMessage.trim() || !user?.id) return;
    
    try {
      // Use the same direct message approach that works for user-to-user chat
      const roomResponse = await apiRequest("POST", `/api/chat/direct/${user.id}/999`, {});
      
      if (roomResponse.ok) {
        const roomData = await roomResponse.json();
        setSelectedRoom(roomData.id);
        
        // Send user message
        await apiRequest("POST", `/api/chat/rooms/${roomData.id}/messages`, {
          content: newMessage.trim(),
          senderId: user.id,
          messageType: "text"
        });
        
        setNewMessage("");
        queryClient.invalidateQueries({ queryKey: ['/api/chat/rooms', user.id] });
        queryClient.invalidateQueries({ queryKey: ['/api/chat/rooms', roomData.id, 'messages'] });
      }
    } catch (error) {
      console.error("Failed to send AI message:", error);
    }
  };

  const formatTime = (date: string | Date) => {
    return new Date(date).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit' 
    });
  };

  const getOtherUserInitial = (room: ChatRoom) => {
    if (room.name) return room.name.charAt(0).toUpperCase();
    return "U"; // Default for unknown users
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center">
        <Card className="p-8">
          <CardContent>
            <p>Please log in to access chat.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      {/* Page Help System */}
      <UniversalInstructionsButton currentPage="chat" />
      
      <div className="mobile-safe w-full max-w-[65vw] mx-auto p-2 sm:p-4 overflow-x-hidden">
        {/* Ask AI Button - Top of Page */}
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-6">
          <div className="flex justify-center">
            <AskAIButton 
              variant="default" 
              size="lg" 
              className="bg-orange-500 hover:bg-orange-600 text-white border-none shadow-lg"
            />
          </div>
        </div>

        <div className="mb-6">
          <div className="flex items-center space-x-3 mb-4">
            {isAIMode ? (
              <>
                <div className="w-12 h-12 bg-blue-900 rounded-full flex items-center justify-center">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-blue-900">AI Support Chat</h1>
                  <p className="text-gray-600">Get intelligent assistance and health guidance</p>
                </div>
              </>
            ) : (
              <>
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-primary">Community Chat</h1>
                  <p className="text-gray-600">Connect with other GoHealMe community members</p>
                </div>
              </>
            )}
          </div>
          
          <div className="flex space-x-2">
            <a
              href="/"
              className="inline-flex items-center px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
            >
              ← Back to Dashboard
            </a>
            <a
              href="/"
              className="px-4 py-2 rounded-lg bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors flex items-center space-x-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              <span>Back to Dashboard</span>
            </a>
            <a
              href="/chat"
              className={`px-4 py-2 rounded-lg transition-colors flex items-center space-x-2 ${
                !isAIMode ? 'bg-primary text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>User Chat</span>
            </a>
            <a
              href="/chat?ai=true"
              className={`px-4 py-2 rounded-lg transition-colors flex items-center space-x-2 ${
                isAIMode ? 'bg-blue-900 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span>AI Chat</span>
            </a>
          </div>
        </div>

        {/* Help Banner for New Users */}
        {!isAIMode && rooms.length === 0 && (
          <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Users className="w-5 h-5 text-green-600" />
              <h3 className="font-medium text-green-800">Start Your First Conversation</h3>
            </div>
            <p className="text-sm text-green-700 mb-3">
              Connect with other community members by searching for users to chat with.
            </p>
            <Button
              onClick={() => setShowUserList(true)}
              className="bg-green-600 hover:bg-green-700 text-white"
              size="sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              Find Users to Chat With
            </Button>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[600px]">
          {/* Chat Rooms Sidebar */}
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Conversations</CardTitle>
                  {!isAIMode && (
                    <Button
                      size="sm"
                      onClick={() => setShowUserList(!showUserList)}
                      className="bg-green-600 hover:bg-green-700 text-white shadow-md border-2 border-green-500"
                      title="Find users to chat with"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      <span className="text-xs font-medium">Find Users</span>
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-0 flex-1 overflow-y-auto">
                {roomsLoading ? (
                  <div className="p-4">
                    <div className="animate-pulse space-y-3">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="h-12 bg-gray-200 rounded"></div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1">
                    {rooms.length === 0 ? (
                      <div className="p-4 text-center text-gray-500">
                        <MessageCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No conversations yet</p>
                        <p className="text-xs mb-3">Click "Find Users" above to start chatting!</p>
                        {!isAIMode && (
                          <Button
                            size="sm"
                            onClick={() => setShowUserList(true)}
                            className="bg-green-600 hover:bg-green-700 text-white text-xs"
                          >
                            <Plus className="w-3 h-3 mr-1" />
                            Find Users to Chat
                          </Button>
                        )}
                      </div>
                    ) : (
                      rooms.map((room: ChatRoom) => (
                        <button
                          key={room.id}
                          onClick={() => setSelectedRoom(room.id)}
                          className={`w-full p-3 text-left hover:bg-gray-50 border-b transition-colors ${
                            selectedRoom === room.id ? 'bg-primary/10 border-primary' : ''
                          }`}
                        >
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className="bg-primary/20 text-primary text-sm">
                                {getOtherUserInitial(room)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-sm truncate">
                                {room.name || "Direct Message"}
                              </p>
                              <p className="text-xs text-gray-500">
                                {formatTime(room.updatedAt)}
                              </p>
                            </div>
                          </div>
                        </button>
                      ))
                    )}
                  </div>
                )}

                {/* User List for Starting New Chats */}
                {showUserList && (
                  <div className="border-t bg-gray-50 p-4">
                    <h4 className="font-medium mb-3">Start New Chat</h4>
                    
                    {/* User Search Box */}
                    <div className="mb-4">
                      <Input
                        type="text"
                        placeholder="Search users by name..."
                        value={userSearchQuery}
                        onChange={(e) => setUserSearchQuery(e.target.value)}
                        className="w-full"
                      />
                    </div>
                    
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {userSearchQuery.length === 0 ? (
                        <p className="text-sm text-gray-500 text-center py-4">
                          Type a name to search for users
                        </p>
                      ) : users.length === 0 ? (
                        <p className="text-sm text-gray-500 text-center py-4">
                          No users found matching "{userSearchQuery}"
                        </p>
                      ) : (
                        users
                          .filter((u: User) => u.id !== user?.id && u.id !== 999)
                          .map((u: User) => (
                            <button
                              key={u.id}
                              onClick={() => {
                                startDirectMessageMutation.mutate(u.id);
                                setShowUserList(false);
                                setUserSearchQuery("");
                              }}
                              className="w-full p-2 text-left hover:bg-white rounded border transition-colors"
                              disabled={startDirectMessageMutation.isPending}
                            >
                              <div className="flex items-center space-x-2">
                                <Avatar className="w-6 h-6">
                                  <AvatarFallback className="bg-primary/20 text-primary text-xs">
                                    {u.name.charAt(0)}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-sm">{u.name}</span>
                                {u.id === 5 && (
                                  <Badge variant="secondary" className="text-xs">
                                    <Bot className="w-3 h-3 mr-1" />
                                    AI
                                  </Badge>
                                )}
                              </div>
                            </button>
                          ))
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Chat Messages Area */}
          <div className="lg:col-span-3">
            <Card className="h-full flex flex-col">
              {selectedRoom ? (
                <>
                  <CardHeader className="pb-3 border-b">
                    <div className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarFallback className="bg-primary/20 text-primary">
                          {getOtherUserInitial(rooms.find((r: ChatRoom) => r.id === selectedRoom) || {} as ChatRoom)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">
                          {rooms.find((r: ChatRoom) => r.id === selectedRoom)?.name || "Direct Message"}
                        </CardTitle>
                        <p className="text-sm text-gray-500">Active now</p>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messagesLoading ? (
                      <div className="space-y-3">
                        {[...Array(5)].map((_, i) => (
                          <div key={i} className="animate-pulse">
                            <div className={`flex ${i % 2 === 0 ? 'justify-end' : 'justify-start'}`}>
                              <div className="bg-gray-200 rounded-lg p-3 max-w-xs h-16"></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : messages.length === 0 ? (
                      <div className="text-center text-gray-500 py-8">
                        <div className="w-16 h-16 mx-auto mb-4 bg-purple-100 rounded-full flex items-center justify-center">
                          <Bot className="w-8 h-8 text-purple-600" />
                        </div>
                        <p>No messages yet</p>
                        <p className="text-sm">Debug: Room {selectedRoom}, Messages: {JSON.stringify(messages)}</p>
                      </div>
                    ) : (
                      messages.slice().reverse().map((message: ChatMessage) => (
                        <div
                          key={message.id}
                          className={`flex ${message.senderId === user.id ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                              message.senderId === user.id
                                ? 'bg-primary text-white'
                                : (message.isAiResponse || message.senderId === 999)
                                ? 'bg-gradient-to-r from-purple-100 to-pink-100 border border-purple-200'
                                : 'bg-gray-100'
                            }`}
                          >
                            <div className="flex items-start space-x-2">
                              {(message.isAiResponse || message.senderId === 999) && (
                                <Bot className="w-4 h-4 text-purple-600 mt-1 flex-shrink-0" />
                              )}
                              <div className="flex-1">
                                {(message.isAiResponse || message.senderId === 999) && (
                                  <p className="text-xs font-medium text-purple-600 mb-1">AI Health Assistant</p>
                                )}
                                <p className="text-sm break-words">{message.content}</p>
                                <p className={`text-xs mt-1 ${
                                  message.senderId === user.id 
                                    ? 'text-white/70' 
                                    : 'text-gray-500'
                                }`}>
                                  {formatTime(message.createdAt)}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                    <div ref={messagesEndRef} />
                  </CardContent>

                  <div className="border-t p-4">
                    <div className="flex space-x-2">
                      <Input
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type your message..."
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        disabled={sendMessageMutation.isPending}
                      />
                      <Button
                        onClick={handleSendMessage}
                        disabled={!newMessage.trim() || sendMessageMutation.isPending}
                        className="bg-primary text-white"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <CardContent className="flex-1 flex items-center justify-center">
                    <div className="text-center text-gray-500">
                      {isAIMode ? (
                        <>
                          <Bot className="w-16 h-16 mx-auto mb-4 text-blue-900 opacity-50" />
                          <h3 className="text-lg font-medium mb-2 text-blue-900">AI Health Assistant</h3>
                          <p>Ask me anything about health, supplements, or wellness</p>
                          <p className="text-sm mt-2">I'm here to provide intelligent guidance and support</p>
                        </>
                      ) : (
                        <>
                          <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
                          <h3 className="text-lg font-medium mb-2">Welcome to GoHealMe Chat</h3>
                          <p>Select a conversation from the left sidebar or start a new one</p>
                          <p className="text-sm mt-2">Click the + button to find community members to chat with</p>
                        </>
                      )}
                    </div>
                  </CardContent>
                  
                  {isAIMode && (
                    <div className="border-t p-4">
                      <div className="flex space-x-2">
                        <Input
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          placeholder="Ask the AI anything about health and wellness..."
                          onKeyPress={(e) => e.key === 'Enter' && handleSendDirectAIMessage()}
                          disabled={sendMessageMutation.isPending}
                          className="flex-1"
                        />
                        <Button
                          onClick={handleSendDirectAIMessage}
                          disabled={!newMessage.trim() || sendMessageMutation.isPending}
                          className="bg-blue-900 hover:bg-blue-800 text-white"
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </Card>
          </div>
        </div>


      </div>
      
      {/* Floating Profile Wall Button */}
      <FloatingProfileButton />
    </div>
  );
}