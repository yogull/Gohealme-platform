import { useState, useRef } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Heart, MessageCircle, Share2, Camera, Plus, Edit, Store, ShoppingBag } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useFileUpload, useUserFiles } from "@/hooks/useFileUpload";
import ImageCropper from "@/components/ImageCropper";
import EnhancedGallery from "@/components/EnhancedGallery";
import SocialMediaLinks from "@/components/SocialMediaLinks";
import SEO from "@/components/SEO";
import PageHelpSystem from "@/components/PageHelpSystem";

interface User {
  id: number;
  firebaseUid: string;
  email: string;
  name: string;
  bio?: string;
  location?: string;
  profileImageUrl?: string;
  isAdmin: boolean;
  isBlocked: boolean;
  blockedReason?: string;
  blockedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
  credits: number;
  subscription: string;
  balance: number;
  facebookUsername?: string;
  twitterUsername?: string;
  instagramUsername?: string;
  linkedinUsername?: string;
  youtubeUsername?: string;
  whatsappNumber?: string;
  telegramUsername?: string;
  personalWebsite?: string;
}

interface ProfilePost {
  id: number;
  userId: number;
  content: string;
  mediaUrl?: string;
  mediaType?: string;
  likes: number;
  comments: number;
  shares: number;
  createdAt: Date;
  user: {
    id: number;
    name: string;
    profileImageUrl?: string;
  };
}

export default function ProfileWall() {
  const { userId } = useParams();
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [newPost, setNewPost] = useState("");
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [profileEditData, setProfileEditData] = useState({
    name: "",
    bio: "",
    location: ""
  });
  const [showImageCropper, setShowImageCropper] = useState(false);
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [cropperAction, setCropperAction] = useState<'profile' | 'cover' | 'gallery'>('profile');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverFileInputRef = useRef<HTMLInputElement>(null);
  const galleryFileInputRef = useRef<HTMLInputElement>(null);

  // Fetch profile user data
  const { data: profileUser, isLoading } = useQuery({
    queryKey: ["/api/users", userId],
    enabled: !!userId,
  });

  // Fetch profile posts
  const { data: posts = [] } = useQuery({
    queryKey: ["/api/profile-wall", userId],
    enabled: !!userId,
  });

  // Fetch user files for galleries
  const { data: files = [], refetch: refetchFiles } = useUserFiles();

  // Calculate if this is own profile before any conditional logic
  const isOwnProfile = appUser?.id === profileUser?.id;

  // Check if current user owns a company for shop button (only for own profile)
  const { data: userCompanies = [] } = useQuery({
    queryKey: ["/api/companies/user", appUser?.id],
    enabled: !!appUser?.id && isOwnProfile,
  });

  // Check if user has personal shop (optimized query)
  const { data: personalShop } = useQuery({
    queryKey: [`/api/personal-shops/user/${profileUser?.id}`],
    enabled: !!profileUser?.id,
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });

  // File upload mutation
  const { uploadFile } = useFileUpload();

  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (data: { content: string; mediaUrl?: string; mediaType?: string }) => {
      return apiRequest("POST", "/api/profile-wall", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall", userId] });
      setNewPost("");
      toast({
        title: "Success",
        description: "Post created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create post.",
        variant: "destructive",
      });
    },
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: { name: string; bio: string; location: string }) => {
      return apiRequest("PATCH", `/api/users/${profileUser?.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId] });
      setShowEditProfile(false);
      toast({
        title: "Success",
        description: "Profile updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile.",
        variant: "destructive",
      });
    },
  });

  const handleCreatePost = () => {
    if (!newPost.trim()) return;
    createPostMutation.mutate({ content: newPost });
  };

  const handleEditProfile = () => {
    if (profileUser) {
      setProfileEditData({
        name: profileUser.name || "",
        bio: profileUser.bio || "",
        location: profileUser.location || ""
      });
      setShowEditProfile(true);
    }
  };

  const handleSaveProfile = () => {
    updateProfileMutation.mutate(profileEditData);
  };

  const handleImageUpload = (type: 'profile' | 'cover' | 'gallery') => {
    setCropperAction(type);
    const input = type === 'cover' ? coverFileInputRef.current : 
                  type === 'gallery' ? galleryFileInputRef.current : 
                  fileInputRef.current;
    input?.click();
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImageFile(file);
      setShowImageCropper(true);
    }
  };

  const handleCropComplete = async (croppedBlob: Blob, cropData: any) => {
    try {
      const file = new File([croppedBlob], `${cropperAction}-image.jpg`, { type: 'image/jpeg' });
      
      if (uploadFile.mutate) {
        uploadFile.mutate({
          file,
          type: cropperAction === 'gallery' ? 'gallery' : 'profile',
          galleryName: cropperAction === 'gallery' ? 'main' : undefined,
          caption: cropperAction === 'gallery' ? 'Profile image' : undefined,
        });
      }

      setShowImageCropper(false);
      setSelectedImageFile(null);
      
      if (cropperAction !== 'gallery') {
        queryClient.invalidateQueries({ queryKey: ["/api/users", userId] });
      } else {
        refetchFiles();
      }

      toast({
        title: "Success",
        description: `${cropperAction === 'profile' ? 'Profile' : cropperAction === 'cover' ? 'Cover' : 'Gallery'} image updated successfully!`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload image.",
        variant: "destructive",
      });
    }
  };

  const handleLike = async (postId: number) => {
    try {
      await apiRequest("POST", `/api/profile-wall/${postId}/like`);
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall", userId] });
      toast({
        title: "Liked",
        description: "Post liked successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to like post.",
        variant: "destructive",
      });
    }
  };

  const handleShare = async (postId: number) => {
    try {
      await apiRequest("POST", `/api/profile-wall/${postId}/share`);
      toast({
        title: "Shared",
        description: "Post shared successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to share post.",
        variant: "destructive",
      });
    }
  };

  if (isLoading || !profileUser) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const hasCompany = Array.isArray(userCompanies) && userCompanies.length > 0;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <SEO
        title={`${profileUser.name} - Profile Wall`}
        description={`View ${profileUser.name}'s profile and posts on Ordinary People Community`}
        keywords={`${profileUser.name}, profile, community, posts, social`}
      />

      <PageHelpSystem 
        currentPage="profileWall"
      />

      <div className="max-w-[95vw] mx-auto p-2 space-y-4">
        {/* Profile Header */}
        <Card className="max-w-[72vw] mx-auto">
          <CardContent className="p-4">
            <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                <img
                  src={profileUser.profileImageUrl || '/default-avatar.png'}
                  alt={profileUser.name}
                  className="w-20 h-20 rounded-full object-cover"
                />
                {isOwnProfile && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full p-0"
                    onClick={() => handleImageUpload('profile')}
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                )}
              </div>

              <div className="text-center">
                <h1 className="text-xl font-bold">{profileUser.name}</h1>
                {profileUser.bio && (
                  <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                    {profileUser.bio}
                  </p>
                )}
                {profileUser.location && (
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    📍 {profileUser.location}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2 justify-center">
                {isOwnProfile && (
                  <>
                    <Button size="sm" onClick={handleEditProfile}>
                      <Edit className="h-4 w-4 mr-1" />
                      Edit Profile
                    </Button>
                    {hasCompany && (
                      <Button size="sm" variant="outline" className="bg-green-600 text-white">
                        <Store className="h-4 w-4 mr-1" />
                        Visit Shop
                      </Button>
                    )}
                    {personalShop ? (
                      <div className="flex gap-1">
                        <Button size="sm" className="bg-purple-600 text-white">
                          <ShoppingBag className="h-4 w-4 mr-1" />
                          My Personal Shop
                        </Button>
                        <Button size="sm" variant="outline">
                          View Shop
                        </Button>
                      </div>
                    ) : (
                      <Button size="sm" className="bg-blue-600 text-white">
                        <Plus className="h-4 w-4 mr-1" />
                        Create Personal Shop
                      </Button>
                    )}
                  </>
                )}
              </div>

              {/* Social Media Links */}
              <SocialMediaLinks userId={profileUser.id} isOwnProfile={isOwnProfile} />
            </div>
          </CardContent>
        </Card>

        {/* Create Post (Own Profile Only) */}
        {isOwnProfile && (
          <Card className="max-w-[72vw] mx-auto">
            <CardContent className="p-4">
              <div className="space-y-3">
                <Textarea
                  placeholder="Share something with your community..."
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="min-h-[80px]"
                />
                <div className="flex justify-between items-center">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleImageUpload('gallery')}
                  >
                    <Camera className="h-4 w-4 mr-1" />
                    Add Media
                  </Button>
                  <Button 
                    onClick={handleCreatePost}
                    disabled={!newPost.trim() || createPostMutation.isPending}
                    className="bg-pink-600 text-white"
                  >
                    Post
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Posts */}
        <div className="space-y-4">
          {Array.isArray(posts) && posts.map((post: any) => (
            <Card key={post.id} className="max-w-[72vw] mx-auto">
              <CardContent className="p-4">
                <div className="space-y-3">
                  <p className="text-sm">{post.content}</p>
                  {post.mediaUrl && (
                    <div className="rounded-lg overflow-hidden">
                      {post.mediaType === 'video' ? (
                        <video controls className="w-full max-h-64 object-cover">
                          <source src={post.mediaUrl} type="video/mp4" />
                        </video>
                      ) : (
                        <img src={post.mediaUrl} alt="Post media" className="w-full max-h-64 object-cover" />
                      )}
                    </div>
                  )}
                  <div className="flex gap-4 pt-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleLike(post.id)}
                      className="flex-1"
                    >
                      <Heart className="h-4 w-4 mr-1" />
                      {post.likes || 0}
                    </Button>
                    <Button size="sm" variant="ghost" className="flex-1">
                      <MessageCircle className="h-4 w-4 mr-1" />
                      {post.comments || 0}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleShare(post.id)}
                      className="flex-1"
                    >
                      <Share2 className="h-4 w-4 mr-1" />
                      {post.shares || 0}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Gallery Section */}
        <Card className="max-w-[72vw] mx-auto">
          <CardContent className="p-4">
            <h2 className="text-lg font-bold mb-4 text-black">My Photos & Videos</h2>
            <EnhancedGallery userId={profileUser.id} />
          </CardContent>
        </Card>
      </div>

      {/* Edit Profile Dialog */}
      <Dialog open={showEditProfile} onOpenChange={setShowEditProfile}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={profileEditData.name}
                onChange={(e) => setProfileEditData(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={profileEditData.bio}
                onChange={(e) => setProfileEditData(prev => ({ ...prev, bio: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={profileEditData.location}
                onChange={(e) => setProfileEditData(prev => ({ ...prev, location: e.target.value }))}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSaveProfile} disabled={updateProfileMutation.isPending}>
                Save Changes
              </Button>
              <Button variant="outline" onClick={() => setShowEditProfile(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Image Cropper Dialog */}
      <Dialog open={showImageCropper} onOpenChange={setShowImageCropper}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Crop Image</DialogTitle>
          </DialogHeader>
          {selectedImageFile && (
            <ImageCropper
              imageFile={selectedImageFile}
              onCropComplete={handleCropComplete}
              onCancel={() => setShowImageCropper(false)}
              aspectRatio={cropperAction === 'cover' ? 16/9 : 1}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileSelect}
      />
      <input
        ref={coverFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileSelect}
      />
      <input
        ref={galleryFileInputRef}
        type="file"
        accept="image/*,video/*"
        className="hidden"
        onChange={handleFileSelect}
      />
    </div>
  );
}