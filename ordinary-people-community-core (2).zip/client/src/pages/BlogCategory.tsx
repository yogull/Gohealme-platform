import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation, Link, useRoute } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Heart, MessageCircle, Share2, Plus, ArrowLeft, Calendar, UserIcon, Trash2 } from "lucide-react";
import { Sidebar } from "@/components/Sidebar";
import { MobileNav } from "@/components/MobileNav";
import { Footer } from "@/components/Footer";
import SocialActions from "@/components/SocialActions";
import type { User as UserType, BlogPost } from "@shared/schema";

interface BlogCategoryProps {
  params?: { category: string };
}

interface BlogComment {
  id: number;
  userId: number;
  postId: number;
  content: string;
  createdAt: string;
  userName: string;
}

interface BlogPostWithUser extends BlogPost {
  userName: string;
}

const BLOG_CATEGORIES = [
  "Health/Wellness Tips",
  "Supplement Reviews", 
  "Mental Health/Wellness",
  "Nutrition & Diet",
  "Exercise & Fitness",
  "Personal Stories",
  "Medical News",
  "Alternative Medicine",
  "Sleep & Recovery",
  "Chronic Illness Support"
];

export default function BlogCategory() {
  const { appUser: user } = useAuth();
  const [, params] = useRoute("/blog/category/:category");
  const category = params?.category || "";
  const decodedCategory = decodeURIComponent(category);
  const [selectedPost, setSelectedPost] = useState<number | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newComment, setNewComment] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch posts in this category
  const { data: posts = [], isLoading } = useQuery<BlogPostWithUser[]>({
    queryKey: [`/api/blog/category/${category}`],
    enabled: !!category,
  });

  // Fetch comments for selected post
  const { data: comments = [] } = useQuery<BlogComment[]>({
    queryKey: [`/api/blog/comments/${selectedPost}`],
    enabled: !!selectedPost,
  });

  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (data: { title: string; content: string; category: string; tags: string[] }) => {
      const response = await apiRequest("POST", "/api/blog/posts", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/blog/category/${category}`] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Post Created",
        description: "Your blog post has been created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Add comment mutation
  const addCommentMutation = useMutation({
    mutationFn: async (data: { postId: number; content: string }) => {
      const response = await apiRequest("POST", "/api/blog/comments", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/blog/comments/${selectedPost}`] });
      setNewComment("");
      toast({
        title: "Comment Added",
        description: "Your comment has been posted!",
      });
    },
  });

  // Delete comment mutation (admin only)
  const deleteCommentMutation = useMutation({
    mutationFn: async (commentId: number) => {
      const response = await apiRequest("DELETE", `/api/comments/${commentId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/blog/comments/${selectedPost}`] });
      toast({
        title: "Comment Deleted",
        description: "Comment has been removed successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete comment. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Delete post mutation (admin or post owner)
  const deletePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      const response = await apiRequest("DELETE", `/api/blog/posts/${postId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/blog/category/${category}`] });
      setSelectedPost(null);
      toast({
        title: "Post Deleted",
        description: "Blog post has been removed successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete post. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Like post mutation
  const likePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      const response = await apiRequest("POST", `/api/blog/posts/${postId}/like`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/blog/category/${category}`] });
    },
  });

  const handleCreatePost = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const title = formData.get("title") as string;
    const content = formData.get("content") as string;
    const tagsString = formData.get("tags") as string || "";
    
    const tags = tagsString
      .split(",")
      .map(tag => tag.trim())
      .filter(tag => tag.length > 0);

    createPostMutation.mutate({
      title,
      content,
      category: decodedCategory,
      tags,
    });
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPost || !newComment.trim()) return;
    
    addCommentMutation.mutate({
      postId: selectedPost,
      content: newComment.trim(),
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const selectedPostData = posts.find(post => post.id === selectedPost);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block lg:w-64 bg-white shadow-sm">
        {user && <Sidebar user={user} />}
      </div>

      {/* Mobile Navigation */}
      <div className="lg:hidden">
        {user && <MobileNav user={user} />}
      </div>

      {/* Main Content */}
      <main className="flex-1 lg:ml-0 p-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center gap-4 mb-4">
              <Link href="/blog">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back to Blog
                </Button>
              </Link>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{decodedCategory}</h1>
            <p className="text-gray-600">
              Explore posts, share your thoughts, and connect with the community around {decodedCategory.toLowerCase()}.
            </p>
          </div>

          {/* Create Post Button */}
          <div className="mb-6">
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Create Post in {decodedCategory}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create New Post in {decodedCategory}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreatePost} className="space-y-4">
                  <div>
                    <Label htmlFor="title">Post Title</Label>
                    <Input
                      id="title"
                      name="title"
                      placeholder="Enter your post title..."
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="content">Content</Label>
                    <Textarea
                      id="content"
                      name="content"
                      placeholder="Share your thoughts, experiences, or insights..."
                      rows={8}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="tags">Tags (comma-separated)</Label>
                    <Input
                      id="tags"
                      name="tags"
                      placeholder="wellness, tips, health..."
                    />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createPostMutation.isPending}>
                      {createPostMutation.isPending ? "Creating..." : "Create Post"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Posts Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="h-3 bg-gray-200 rounded"></div>
                      <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : posts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {posts.map((post) => (
                <Card key={post.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-xl line-clamp-2">{post.title}</CardTitle>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <UserIcon className="w-4 h-4" />
                      <span>{post.userName}</span>
                      <Calendar className="w-4 h-4 ml-2" />
                      <span>{formatDate(post.createdAt.toString())}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 line-clamp-3 mb-4">
                      {post.content.length > 150 
                        ? `${post.content.substring(0, 150)}...` 
                        : post.content
                      }
                    </p>
                    
                    {post.tags && post.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-4">
                        {post.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <button
                          onClick={() => likePostMutation.mutate(post.id)}
                          className="flex items-center gap-1 text-gray-500 hover:text-red-500 transition-colors"
                        >
                          <Heart className="w-4 h-4" />
                          <span>{post.likes}</span>
                        </button>
                        <button
                          onClick={() => setSelectedPost(post.id)}
                          className="flex items-center gap-1 text-gray-500 hover:text-blue-500 transition-colors"
                        >
                          <MessageCircle className="w-4 h-4" />
                          <span>Comment</span>
                        </button>
                        <SocialActions
                          postId={post.id}
                          title={post.title}
                          content={post.content}
                          url={`${window.location.origin}/blog/category/${category}`}
                        />
                        {(user?.isAdmin || user?.id === post.userId) && (
                          <button
                            onClick={() => deletePostMutation.mutate(post.id)}
                            className="flex items-center gap-1 text-red-600 hover:text-red-800 transition-colors"
                            disabled={deletePostMutation.isPending}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedPost(post.id)}
                      >
                        Read More
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="text-center py-12">
              <CardContent>
                <MessageCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">No posts yet in {decodedCategory}</h3>
                <p className="text-gray-600 mb-4">
                  Be the first to share something in this category!
                </p>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  Create First Post
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Post Detail Dialog */}
          {selectedPost && selectedPostData && (
            <Dialog open={!!selectedPost} onOpenChange={() => setSelectedPost(null)}>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-2xl">{selectedPostData.title}</DialogTitle>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <UserIcon className="w-4 h-4" />
                    <span>{selectedPostData.userName}</span>
                    <Calendar className="w-4 h-4 ml-2" />
                    <span>{formatDate(selectedPostData.createdAt.toString())}</span>
                  </div>
                </DialogHeader>
                
                <div className="space-y-6">
                  {/* Post Content */}
                  <div className="prose max-w-none">
                    <p className="whitespace-pre-wrap">{selectedPostData.content}</p>
                  </div>

                  {/* Tags */}
                  {selectedPostData.tags && selectedPostData.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {selectedPostData.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Post Actions */}
                  <div className="flex items-center space-x-4 py-4 border-y">
                    <button
                      onClick={() => likePostMutation.mutate(selectedPost)}
                      className="flex items-center gap-2 text-gray-600 hover:text-red-500 transition-colors"
                    >
                      <Heart className="w-5 h-5" />
                      <span>{selectedPostData.likes} Likes</span>
                    </button>
                    <SocialActions
                      postId={selectedPost}
                      title={selectedPostData.title}
                      content={selectedPostData.content}
                      url={`${window.location.origin}/blog/category/${category}`}
                    />
                  </div>

                  {/* Comments Section */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Comments</h3>
                    
                    {/* Add Comment Form */}
                    <form onSubmit={handleAddComment} className="space-y-3">
                      <Textarea
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Share your thoughts..."
                        rows={3}
                      />
                      <Button 
                        type="submit" 
                        disabled={!newComment.trim() || addCommentMutation.isPending}
                        size="sm"
                      >
                        {addCommentMutation.isPending ? "Adding..." : "Add Comment"}
                      </Button>
                    </form>

                    {/* Comments List */}
                    <div className="space-y-4">
                      {comments.map((comment) => (
                        <div key={comment.id} className="bg-gray-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Avatar className="w-6 h-6">
                                <AvatarFallback className="text-xs">
                                  {comment.userName.charAt(0).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium text-sm">{comment.userName}</span>
                              <span className="text-xs text-gray-500">
                                {formatDate(comment.createdAt)}
                              </span>
                            </div>
                            {(user?.isAdmin || user?.id === comment.userId) && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteCommentMutation.mutate(comment.id)}
                                className="text-red-600 hover:text-red-800 hover:bg-red-50"
                                disabled={deleteCommentMutation.isPending}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                          <p className="text-gray-700">{comment.content}</p>
                        </div>
                      ))}
                      
                      {comments.length === 0 && (
                        <p className="text-gray-500 text-center py-4">
                          No comments yet. Be the first to comment!
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        <Footer />
      </main>
    </div>
  );
}