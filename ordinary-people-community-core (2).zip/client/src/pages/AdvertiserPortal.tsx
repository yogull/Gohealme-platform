import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { 
  Building2, 
  Plus, 
  CreditCard, 
  BarChart3, 
  Package, 
  Eye, 
  MousePointer,
  Calendar,
  MapPin,
  Globe,
  Upload
} from "lucide-react";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

function PaymentForm({ companyData, onSuccess }: { companyData: any; onSuccess: () => void }) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/advertiser-portal?success=true`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Your advertiser subscription is now active!",
      });
      onSuccess();
    }

    setIsProcessing(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PaymentElement />
      <Button type="submit" disabled={!stripe || isProcessing} className="w-full bg-pink-600 hover:bg-pink-700">
        {isProcessing ? "Processing Donation..." : "Donate £24/year"}
      </Button>
    </form>
  );
}

export default function AdvertiserPortal() {
  const { appUser: user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showAdDialog, setShowAdDialog] = useState(false);
  const [showProductDialog, setShowProductDialog] = useState(false);
  const [clientSecret, setClientSecret] = useState("");

  const { data: company } = useQuery({
    queryKey: ["/api/companies/user", user?.id],
    queryFn: () => apiRequest("GET", `/api/companies/user/${user?.id}`).then(res => res.json()),
    enabled: !!user?.id
  });

  const { data: advertisements = [] } = useQuery({
    queryKey: ["/api/advertisements/company", company?.id],
    queryFn: () => apiRequest("GET", `/api/advertisements/company/${company?.id}`).then(res => res.json()),
    enabled: !!company?.id
  });

  const { data: products = [] } = useQuery({
    queryKey: ["/api/company-products", company?.id],
    queryFn: () => apiRequest("GET", `/api/company-products/${company?.id}`).then(res => res.json()),
    enabled: !!company?.id
  });

  const createCompanyMutation = useMutation({
    mutationFn: async (companyData: any) => {
      // Create payment intent for £24/year subscription
      const paymentResponse = await apiRequest("POST", "/api/create-advertiser-subscription", {
        companyData,
        amount: 2400 // £24 in pence
      });
      const { clientSecret } = await paymentResponse.json();
      setClientSecret(clientSecret);
      setShowPaymentDialog(true);
      return companyData;
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const createAdMutation = useMutation({
    mutationFn: (adData: any) => apiRequest("POST", "/api/advertisements", adData).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/advertisements/company"] });
      setShowAdDialog(false);
      toast({
        title: "Success",
        description: "Advertisement created successfully!",
      });
    }
  });

  const createProductMutation = useMutation({
    mutationFn: (productData: any) => apiRequest("POST", "/api/company-products", productData).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/company-products"] });
      setShowProductDialog(false);
      toast({
        title: "Success",
        description: "Product added successfully!",
      });
    }
  });

  const handleCompanySubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const companyData = {
      ownerId: user?.id,
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      website: formData.get("website") as string,
      email: formData.get("email") as string,
      phone: formData.get("phone") as string,
      address: formData.get("address") as string,
    };
    createCompanyMutation.mutate(companyData);
  };

  const handleAdSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const adData = {
      advertiserId: user?.id,
      title: formData.get("title") as string,
      description: formData.get("description") as string,
      imageUrl: formData.get("imageUrl") as string,
      targetUrl: formData.get("targetUrl") as string,
      targetLocation: formData.get("targetLocation") as string,
      targetScope: formData.get("targetScope") as string,
      budget: parseInt(formData.get("budget") as string) * 100, // Convert to pence
    };
    createAdMutation.mutate(adData);
  };

  const handleProductSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const productData = {
      companyId: company?.id,
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      price: parseInt(formData.get("price") as string) * 100, // Convert to pence
      imageUrl: formData.get("imageUrl") as string,
      category: formData.get("category") as string,
      stock: parseInt(formData.get("stock") as string),
    };
    createProductMutation.mutate(productData);
  };

  const isSubscriptionActive = company?.subscriptionExpiry && new Date(company.subscriptionExpiry) > new Date();

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Sign In Required</h2>
            <p className="text-gray-600">Please sign in to access the advertiser portal.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!company) {
    return (
      <div className="container mx-auto px-4 py-8">
        <PageHeader 
          title="Advertiser Portal" 
          subtitle="Promote your business on GoHealMe"
        />

        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Create Your Company Profile
            </CardTitle>
            <p className="text-gray-600">
              Join our advertising platform for just £24/year and reach health-conscious customers
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCompanySubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Company Name</Label>
                  <Input id="name" name="name" required />
                </div>
                <div>
                  <Label htmlFor="email">Business Email</Label>
                  <Input id="email" name="email" type="email" required />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Company Description</Label>
                <Textarea id="description" name="description" rows={3} required />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="website">Website</Label>
                  <Input id="website" name="website" type="url" />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" name="phone" />
                </div>
              </div>

              <div>
                <Label htmlFor="address">Business Address</Label>
                <Input id="address" name="address" />
              </div>

              <div className="bg-pink-50 border border-pink-200 rounded-lg p-4">
                <h3 className="font-semibold text-pink-900 mb-2">Annual Donation Benefits</h3>
                <ul className="text-sm text-pink-800 space-y-1">
                  <li>• Unlimited advertisements across all pages</li>
                  <li>• Your own company storefront</li>
                  <li>• Direct payment processing for your products</li>
                  <li>• Performance analytics and reporting</li>
                  <li>• No competitor ads on your company pages</li>
                </ul>
                <p className="text-xs text-pink-700 mt-2">
                  Your £24 annual donation supports the GoHealMe community platform
                </p>
              </div>

              <Button type="submit" className="w-full bg-pink-600 hover:bg-pink-700" disabled={createCompanyMutation.isPending}>
                {createCompanyMutation.isPending ? "Creating..." : "Continue to Donate £24/year"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Payment Dialog */}
        <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Complete Your Subscription</DialogTitle>
            </DialogHeader>
            {clientSecret && (
              <Elements stripe={stripePromise} options={{ clientSecret }}>
                <PaymentForm 
                  companyData={createCompanyMutation.data}
                  onSuccess={() => {
                    setShowPaymentDialog(false);
                    queryClient.invalidateQueries({ queryKey: ["/api/companies/user"] });
                  }}
                />
              </Elements>
            )}
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader 
        title={`${company.name} - Advertiser Dashboard`}
        subtitle="Manage your advertisements and products"
      />

      <div className="mb-6">
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="default" className="bg-green-600">
                  Active Subscription
                </Badge>
                <span className="text-sm text-green-700">
                  Expires: {new Date(company.subscriptionExpiry).toLocaleDateString()}
                </span>
              </div>
              <Button variant="outline" size="sm">
                <CreditCard className="h-4 w-4 mr-2" />
                Renew Subscription
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="ads" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="ads">Advertisements</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="company">Company</TabsTrigger>
        </TabsList>

        <TabsContent value="ads" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Your Advertisements</h2>
            <Dialog open={showAdDialog} onOpenChange={setShowAdDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Advertisement
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create New Advertisement</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAdSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="title">Advertisement Title</Label>
                      <Input id="title" name="title" required />
                    </div>
                    <div>
                      <Label htmlFor="budget">Daily Budget (£)</Label>
                      <Input id="budget" name="budget" type="number" min="1" required />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" name="description" rows={3} required />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="imageUrl">Image URL</Label>
                      <Input id="imageUrl" name="imageUrl" type="url" required />
                    </div>
                    <div>
                      <Label htmlFor="targetUrl">Target URL</Label>
                      <Input id="targetUrl" name="targetUrl" type="url" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="targetScope">Targeting Scope</Label>
                      <Select name="targetScope" required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select scope" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="local">Local</SelectItem>
                          <SelectItem value="national">National</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="targetLocation">Target Location (if local)</Label>
                      <Input id="targetLocation" name="targetLocation" placeholder="e.g., Nottingham" />
                    </div>
                  </div>

                  <Button type="submit" disabled={createAdMutation.isPending} className="w-full">
                    {createAdMutation.isPending ? "Creating..." : "Create Advertisement"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4">
            {advertisements.map((ad: any) => (
              <Card key={ad.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    {ad.imageUrl && (
                      <img 
                        src={ad.imageUrl} 
                        alt={ad.title}
                        className="w-20 h-20 object-cover rounded"
                      />
                    )}
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold">{ad.title}</h3>
                          <p className="text-sm text-gray-600 mt-1">{ad.description}</p>
                          <div className="flex items-center gap-4 mt-2">
                            <Badge variant={ad.targetScope === 'local' ? 'default' : 'secondary'}>
                              {ad.targetScope === 'local' ? (
                                <><MapPin className="h-3 w-3 mr-1" />{ad.targetLocation}</>
                              ) : (
                                <><Globe className="h-3 w-3 mr-1" />National</>
                              )}
                            </Badge>
                            <span className="text-sm text-gray-500">
                              Budget: £{(ad.budget / 100).toFixed(2)}/day
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <Eye className="h-4 w-4" />
                              {ad.impressions}
                            </div>
                            <div className="flex items-center gap-1">
                              <MousePointer className="h-4 w-4" />
                              {ad.clicks}
                            </div>
                          </div>
                          <Badge variant={ad.isActive ? 'default' : 'secondary'} className="mt-2">
                            {ad.isActive ? 'Active' : 'Paused'}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Your Products</h2>
            <Dialog open={showProductDialog} onOpenChange={setShowProductDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Product
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add New Product</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleProductSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Product Name</Label>
                      <Input id="name" name="name" required />
                    </div>
                    <div>
                      <Label htmlFor="price">Price (£)</Label>
                      <Input id="price" name="price" type="number" min="0" step="0.01" required />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="description">Product Description</Label>
                    <Textarea id="description" name="description" rows={3} required />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="imageUrl">Product Image URL</Label>
                      <Input id="imageUrl" name="imageUrl" type="url" required />
                    </div>
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Input id="category" name="category" required />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="stock">Stock Quantity</Label>
                    <Input id="stock" name="stock" type="number" min="0" required />
                  </div>

                  <Button type="submit" disabled={createProductMutation.isPending} className="w-full">
                    {createProductMutation.isPending ? "Adding..." : "Add Product"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {products.map((product: any) => (
              <Card key={product.id}>
                <CardContent className="p-4">
                  {product.imageUrl && (
                    <img 
                      src={product.imageUrl} 
                      alt={product.name}
                      className="w-full h-32 object-cover rounded mb-3"
                    />
                  )}
                  <h3 className="font-semibold">{product.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">{product.description}</p>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-lg font-bold">£{(product.price / 100).toFixed(2)}</span>
                    <Badge variant="outline">
                      <Package className="h-3 w-3 mr-1" />
                      {product.stock} in stock
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Performance Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {advertisements.reduce((sum: number, ad: any) => sum + ad.impressions, 0)}
                    </div>
                    <div className="text-sm text-gray-600">Total Impressions</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {advertisements.reduce((sum: number, ad: any) => sum + ad.clicks, 0)}
                    </div>
                    <div className="text-sm text-gray-600">Total Clicks</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {advertisements.length > 0 ? (
                        ((advertisements.reduce((sum: number, ad: any) => sum + ad.clicks, 0) / 
                          advertisements.reduce((sum: number, ad: any) => sum + ad.impressions, 0)) * 100).toFixed(1)
                      ) : 0}%
                    </div>
                    <div className="text-sm text-gray-600">Click-through Rate</div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="company">
          <Card>
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Company Name</Label>
                  <Input value={company.name} readOnly />
                </div>
                <div>
                  <Label>Email</Label>
                  <Input value={company.email} readOnly />
                </div>
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={company.description || ''} readOnly rows={3} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Website</Label>
                  <Input value={company.website || ''} readOnly />
                </div>
                <div>
                  <Label>Phone</Label>
                  <Input value={company.phone || ''} readOnly />
                </div>
              </div>
              <Button variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Edit Company Profile
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}