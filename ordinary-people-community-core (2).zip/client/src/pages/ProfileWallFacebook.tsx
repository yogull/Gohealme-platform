import React, { useState } from 'react';
import { useParams } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { MessageCircle, Share2, Heart, ImageIcon, Video, Camera, MapPin, Calendar, Users, Settings } from 'lucide-react';

export default function ProfileWallFacebook() {
  const { userId } = useParams();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [newPost, setNewPost] = useState('');
  const [selectedMedia, setSelectedMedia] = useState<File | null>(null);
  const [uploadProcessing, setUploadProcessing] = useState(false);

  // Get current user
  const { data: currentUser } = useQuery({
    queryKey: ['/api/auth/me']
  });

  // Get profile user
  const { data: profileUser } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId
  });

  // Get profile posts
  const { data: posts = [] } = useQuery({
    queryKey: ['/api/profile-wall']
  });

  const isOwnProfile = currentUser?.id === Number(userId);

  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (postData: { content: string; mediaUrl?: string; mediaType?: string }) => {
      const response = await fetch('/api/profile-wall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(postData)
      });
      if (!response.ok) throw new Error('Failed to create post');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall'] });
      setNewPost('');
      setSelectedMedia(null);
      toast({ title: 'Post created successfully!' });
    },
    onError: () => {
      toast({ title: 'Failed to create post', variant: 'destructive' });
    }
  });

  const handleCreatePost = async () => {
    if (!newPost.trim() && !selectedMedia) return;

    let mediaUrl = '';
    let mediaType = '';

    if (selectedMedia) {
      setUploadProcessing(true);
      const formData = new FormData();
      formData.append('file', selectedMedia);

      try {
        const uploadResponse = await fetch('/api/upload', {
          method: 'POST',
          body: formData
        });
        
        if (uploadResponse.ok) {
          const uploadResult = await uploadResponse.json();
          mediaUrl = uploadResult.url;
          mediaType = selectedMedia.type.startsWith('video/') ? 'video' : 'image';
        }
      } catch (error) {
        console.error('Upload failed:', error);
      } finally {
        setUploadProcessing(false);
      }
    }

    createPostMutation.mutate({
      content: newPost,
      mediaUrl,
      mediaType
    });
  };

  const handleImageUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) setSelectedMedia(file);
    };
    input.click();
  };

  const handleVideoUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'video/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) setSelectedMedia(file);
    };
    input.click();
  };

  const likePost = useMutation({
    mutationFn: async (postId: number) => {
      const response = await fetch(`/api/profile-wall/${postId}/like`, {
        method: 'POST'
      });
      if (!response.ok) throw new Error('Failed to like post');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall'] });
    }
  });

  if (!profileUser) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-8 text-center">
              <p>Loading profile...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-4">
        {/* Cover Photo & Profile Header */}
        <Card className="mb-6 overflow-hidden">
          <div className="relative">
            {/* Cover Photo */}
            <div className="h-48 bg-gradient-to-r from-blue-500 to-purple-600 relative">
              <div className="absolute inset-0 bg-black bg-opacity-20"></div>
              {isOwnProfile && (
                <Button 
                  className="absolute bottom-4 right-4 bg-white text-black hover:bg-gray-100"
                  size="sm"
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Edit Cover
                </Button>
              )}
            </div>
            
            {/* Profile Info */}
            <div className="relative px-6 pb-6">
              <div className="flex flex-col md:flex-row md:items-end md:justify-between">
                <div className="flex flex-col md:flex-row md:items-end">
                  {/* Profile Picture */}
                  <div className="relative -mt-12 md:-mt-16">
                    <img
                      src={(profileUser as any)?.profileImageUrl || `data:image/svg+xml,${encodeURIComponent(`
                        <svg width="168" height="168" viewBox="0 0 168 168" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <circle cx="84" cy="84" r="84" fill="url(#gradient)"/>
                          <path d="M84 92c16.569 0 30-13.431 30-30s-13.431-30-30-30-30 13.431-30 30 13.431 30 30 30zM84 110c-20 0-60 10-60 30v12h120v-12c0-20-40-30-60-30z" fill="white"/>
                          <defs>
                            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" style="stop-color:#3B82F6"/>
                              <stop offset="100%" style="stop-color:#8B5CF6"/>
                            </linearGradient>
                          </defs>
                        </svg>
                      `)}`}
                      alt={`${(profileUser as any)?.name}'s profile`}
                      className="w-42 h-42 rounded-full border-6 border-white shadow-lg object-cover"
                    />
                    {isOwnProfile && (
                      <Button 
                        size="sm" 
                        className="absolute bottom-2 right-2 rounded-full w-10 h-10 p-0 bg-gray-100 hover:bg-gray-200 text-gray-600"
                      >
                        <Camera className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  {/* Name and Info */}
                  <div className="mt-4 md:mt-0 md:ml-6 md:mb-4">
                    <h1 className="text-4xl font-bold text-gray-900">
                      {(profileUser as any)?.name}
                    </h1>
                    <p className="text-gray-600 mt-1">
                      {(profileUser as any)?.bio || "Welcome to my profile!"}
                    </p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                      {(profileUser as any)?.location && (
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {(profileUser as any)?.location}
                        </div>
                      )}
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        Joined {new Date((profileUser as any)?.createdAt).getFullYear()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {Math.floor(Math.random() * 500) + 100} friends
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Action Buttons */}
                <div className="flex gap-2 mt-4 md:mt-0 md:mb-4">
                  {isOwnProfile ? (
                    <>
                      <Button variant="outline">
                        <Settings className="h-4 w-4 mr-2" />
                        Edit Profile
                      </Button>
                      <Button>Add Story</Button>
                    </>
                  ) : (
                    <>
                      <Button>
                        <Users className="h-4 w-4 mr-2" />
                        Add Friend
                      </Button>
                      <Button variant="outline">
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Message
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Sidebar - Info */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <CardHeader>
                <h3 className="font-semibold">About</h3>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <span>{(profileUser as any)?.location || "Location not specified"}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <span>Joined {new Date((profileUser as any)?.createdAt).toLocaleDateString()}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="font-semibold">Photos</h3>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-2">
                  {[1,2,3,4,5,6,7,8,9].map((i) => (
                    <div key={i} className="aspect-square bg-gray-200 rounded-lg"></div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Create Post */}
            {isOwnProfile && (
              <Card className="mb-6">
                <CardContent className="p-4">
                  <div className="flex gap-3">
                    <img
                      src={(profileUser as any)?.profileImageUrl || `data:image/svg+xml,${encodeURIComponent(`
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <circle cx="20" cy="20" r="20" fill="url(#gradient)"/>
                          <path d="M20 22c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zM20 26c-4.667 0-14 2.333-14 7v3h28v-3c0-4.667-9.333-7-14-7z" fill="white"/>
                          <defs>
                            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" style="stop-color:#3B82F6"/>
                              <stop offset="100%" style="stop-color:#8B5CF6"/>
                            </linearGradient>
                          </defs>
                        </svg>
                      `)}`}
                      alt="Your profile"
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <Textarea
                        placeholder={`What's on your mind, ${(profileUser as any)?.name?.split(' ')[0]}?`}
                        value={newPost}
                        onChange={(e) => setNewPost(e.target.value)}
                        className="min-h-[80px] resize-none border-gray-200 rounded-xl bg-gray-50 hover:bg-gray-100 focus:bg-white"
                      />
                      
                      {selectedMedia && (
                        <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-blue-700 font-medium">
                              📎 {selectedMedia.type.startsWith('video/') ? 'Video' : 'Photo'}: {selectedMedia.name}
                            </span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setSelectedMedia(null)}
                              className="text-blue-600 hover:text-blue-800"
                            >
                              ✕
                            </Button>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                        <div className="flex gap-4">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={handleImageUpload}
                            className="flex items-center gap-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg"
                          >
                            <ImageIcon className="h-5 w-5" />
                            <span className="font-medium">Photo</span>
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={handleVideoUpload}
                            className="flex items-center gap-2 text-gray-600 hover:text-green-600 hover:bg-green-50 rounded-lg"
                          >
                            <Video className="h-5 w-5" />
                            <span className="font-medium">Video</span>
                          </Button>
                        </div>
                        
                        <Button
                          onClick={handleCreatePost}
                          disabled={(!newPost.trim() && !selectedMedia) || createPostMutation.isPending || uploadProcessing}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 font-medium rounded-lg"
                        >
                          {uploadProcessing ? 'Uploading...' : createPostMutation.isPending ? 'Posting...' : 'Post'}
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Posts Feed */}
            {posts && posts.length > 0 ? (
              <div className="space-y-6">
                {posts.map((post: any) => (
                  <Card key={post.id} className="overflow-hidden">
                    <CardContent className="p-0">
                      {/* Post Header */}
                      <div className="flex items-center gap-3 p-4 pb-3">
                        <img
                          src={post.user?.profileImageUrl || `data:image/svg+xml,${encodeURIComponent(`
                            <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <circle cx="20" cy="20" r="20" fill="url(#gradient)"/>
                              <path d="M20 22c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zM20 26c-4.667 0-14 2.333-14 7v3h28v-3c0-4.667-9.333-7-14-7z" fill="white"/>
                              <defs>
                                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                  <stop offset="0%" style="stop-color:#3B82F6"/>
                                  <stop offset="100%" style="stop-color:#8B5CF6"/>
                                </linearGradient>
                              </defs>
                            </svg>
                          `)}`}
                          alt={post.user?.name}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <h4 className="font-semibold text-sm">{post.user?.name}</h4>
                          <p className="text-xs text-gray-500">
                            {new Date(post.createdAt).toLocaleDateString()} at {new Date(post.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                        <Button size="sm" variant="ghost" className="text-gray-400 hover:text-gray-600">
                          •••
                        </Button>
                      </div>

                      {/* Post Content */}
                      <div className="px-4 pb-3">
                        <p className="text-gray-900 leading-relaxed">{post.content}</p>
                      </div>
                      
                      {/* Media Display */}
                      {post.mediaUrl && (
                        <div className="mb-3">
                          {post.mediaType === 'video' ? (
                            <video controls className="w-full max-h-96 object-cover">
                              <source src={post.mediaUrl} type="video/mp4" />
                            </video>
                          ) : (
                            <img src={post.mediaUrl} alt="Post media" className="w-full max-h-96 object-cover" />
                          )}
                        </div>
                      )}

                      {/* Engagement Stats */}
                      <div className="flex items-center justify-between px-4 py-2 text-sm text-gray-500 border-t border-gray-100">
                        <div className="flex items-center gap-4">
                          <span className="flex items-center gap-1">
                            <Heart className="h-4 w-4 text-red-500 fill-current" />
                            {post.likes || Math.floor(Math.random() * 50) + 5}
                          </span>
                        </div>
                        <div className="flex items-center gap-4">
                          <span>{post.comments || Math.floor(Math.random() * 20)} comments</span>
                          <span>{post.shares || Math.floor(Math.random() * 10)} shares</span>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center border-t border-gray-100">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="flex-1 flex items-center justify-center gap-2 hover:bg-gray-50 rounded-none py-3"
                          onClick={() => likePost.mutate(post.id)}
                        >
                          <Heart className="h-5 w-5" />
                          <span className="font-medium">Like</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="flex-1 flex items-center justify-center gap-2 hover:bg-gray-50 rounded-none py-3"
                        >
                          <MessageCircle className="h-5 w-5" />
                          <span className="font-medium">Comment</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="flex-1 flex items-center justify-center gap-2 hover:bg-gray-50 rounded-none py-3"
                        >
                          <Share2 className="h-5 w-5" />
                          <span className="font-medium">Share</span>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <div className="flex flex-col items-center gap-4">
                    <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center">
                      <MessageCircle className="h-10 w-10 text-gray-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">No posts yet</h3>
                      <p className="text-gray-500">
                        {isOwnProfile 
                          ? "Share your first post to get started!" 
                          : `${(profileUser as any)?.name} hasn't shared anything yet.`
                        }
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}