import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { UniversalBackButton } from "@/components/UniversalBackButton";
import { SimpleImageUpload } from "@/components/SimpleImageUpload";
import { ChevronLeft, ChevronRight, Plus, Heart, MessageCircle, Share2, Edit3, Trash2 } from "lucide-react";

interface Album {
  id: string;
  name: string;
  photos: Photo[];
  createdAt: string;
}

interface Photo {
  id: string;
  url: string;
  caption: string;
  likes: number;
  comments: Comment[];
  uploadedAt: string;
}

interface Comment {
  id: string;
  user: string;
  text: string;
  timestamp: string;
  avatar: string;
}

export default function Gallery() {
  const [albums, setAlbums] = useState<Album[]>([]);
  const [selectedAlbum, setSelectedAlbum] = useState<Album | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [newAlbumName, setNewAlbumName] = useState("");
  const [newComment, setNewComment] = useState("");
  const [showCreateAlbum, setShowCreateAlbum] = useState(false);

  // Load albums from localStorage on component mount
  useEffect(() => {
    const savedAlbums = localStorage.getItem('gallery_albums');
    if (savedAlbums) {
      setAlbums(JSON.parse(savedAlbums));
    } else {
      // Initialize with demo albums
      const demoAlbums: Album[] = [
        {
          id: "holiday-2024",
          name: "Holiday Photos",
          createdAt: "2024-06-01",
          photos: [
            {
              id: "holiday-1",
              url: "/api/placeholder/400/300",
              caption: "Beautiful sunset at the beach",
              likes: 15,
              uploadedAt: "2024-06-01",
              comments: [
                {
                  id: "c1",
                  user: "Sarah Johnson",
                  text: "Absolutely stunning! Where was this taken?",
                  timestamp: "2 hours ago",
                  avatar: "/api/placeholder/32/32"
                }
              ]
            }
          ]
        },
        {
          id: "family-2024",
          name: "Family Memories",
          createdAt: "2024-05-15",
          photos: [
            {
              id: "family-1",
              url: "/api/placeholder/400/300",
              caption: "Family gathering at grandma's house",
              likes: 23,
              uploadedAt: "2024-05-15",
              comments: []
            }
          ]
        }
      ];
      setAlbums(demoAlbums);
      localStorage.setItem('gallery_albums', JSON.stringify(demoAlbums));
    }
  }, []);

  // Save albums to localStorage whenever albums change
  useEffect(() => {
    localStorage.setItem('gallery_albums', JSON.stringify(albums));
  }, [albums]);

  const createAlbum = () => {
    if (!newAlbumName.trim()) {
      toast({ title: "Please enter an album name" });
      return;
    }

    const newAlbum: Album = {
      id: Date.now().toString(),
      name: newAlbumName,
      photos: [],
      createdAt: new Date().toISOString()
    };

    setAlbums(prev => [...prev, newAlbum]);
    setNewAlbumName("");
    setShowCreateAlbum(false);
    toast({ title: "Album created successfully!" });
  };

  const addPhotoToAlbum = (albumId: string, photoUrl: string) => {
    const newPhoto: Photo = {
      id: Date.now().toString(),
      url: photoUrl,
      caption: "",
      likes: 0,
      comments: [],
      uploadedAt: new Date().toISOString()
    };

    setAlbums(prev => prev.map(album => 
      album.id === albumId 
        ? { ...album, photos: [...album.photos, newPhoto] }
        : album
    ));
    toast({ title: "Photo added to album!" });
  };

  const openPhotoViewer = (album: Album, photoIndex: number) => {
    setSelectedAlbum(album);
    setSelectedPhoto(album.photos[photoIndex]);
    setCurrentPhotoIndex(photoIndex);
  };

  const navigatePhoto = (direction: 'prev' | 'next') => {
    if (!selectedAlbum) return;
    
    const newIndex = direction === 'prev' 
      ? Math.max(0, currentPhotoIndex - 1)
      : Math.min(selectedAlbum.photos.length - 1, currentPhotoIndex + 1);
    
    setCurrentPhotoIndex(newIndex);
    setSelectedPhoto(selectedAlbum.photos[newIndex]);
  };

  const addComment = () => {
    if (!newComment.trim() || !selectedPhoto) return;

    const comment: Comment = {
      id: Date.now().toString(),
      user: "You",
      text: newComment,
      timestamp: "Just now",
      avatar: "/api/placeholder/32/32"
    };

    // Update the photo in the album
    if (selectedAlbum) {
      setAlbums(prev => prev.map(album => 
        album.id === selectedAlbum.id 
          ? {
              ...album,
              photos: album.photos.map(photo => 
                photo.id === selectedPhoto.id 
                  ? { ...photo, comments: [...photo.comments, comment] }
                  : photo
              )
            }
          : album
      ));
      
      // Update selected photo
      setSelectedPhoto(prev => prev ? { ...prev, comments: [...prev.comments, comment] } : null);
    }

    setNewComment("");
    toast({ title: "Comment added!" });
  };

  const likePhoto = (photoId: string) => {
    if (!selectedAlbum) return;

    setAlbums(prev => prev.map(album => 
      album.id === selectedAlbum.id 
        ? {
            ...album,
            photos: album.photos.map(photo => 
              photo.id === photoId 
                ? { ...photo, likes: photo.likes + 1 }
                : photo
            )
          }
        : album
    ));

    if (selectedPhoto?.id === photoId) {
      setSelectedPhoto(prev => prev ? { ...prev, likes: prev.likes + 1 } : null);
    }
  };

  const sharePhoto = () => {
    if (navigator.share) {
      navigator.share({
        title: selectedPhoto?.caption || "Check out this photo!",
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({ title: "Link copied to clipboard!" });
    }
  };

  const handleOPCShare = (photo: Photo) => {
    const shareText = `Check out this amazing photo: ${photo.caption || 'Beautiful moment'} - shared on Ordinary People Community`;
    if (navigator.share) {
      navigator.share({
        title: photo.caption || 'Photo from Gallery',
        text: shareText,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(`${shareText} ${window.location.href}`);
      toast({ title: "OPC share link copied to clipboard!" });
    }
  };

  const handleMediaShare = (photo: Photo) => {
    const platforms = ['Facebook', 'Twitter', 'Instagram', 'LinkedIn'];
    const shareText = `Amazing photo: ${photo.caption || 'Beautiful moment'}`;
    
    // Simulate sharing to multiple media platforms
    platforms.forEach(platform => {
      console.log(`Sharing to ${platform}:`, shareText);
    });
    
    toast({ title: `Shared to ${platforms.join(', ')}!` });
  };

  const handleMultiShare = (photo: Photo) => {
    const shareText = `Check out this photo: ${photo.caption || 'Beautiful moment'} - shared via Multi-Share`;
    
    // Multi-platform sharing simulation
    const allPlatforms = ['Facebook', 'Twitter', 'Instagram', 'LinkedIn', 'WhatsApp', 'Telegram', 'Discord'];
    
    allPlatforms.forEach(platform => {
      console.log(`Multi-sharing to ${platform}:`, shareText);
    });
    
    toast({ title: `Multi-shared to all ${allPlatforms.length} platforms!` });
  };

  const likeComment = (commentId: string) => {
    toast({ title: "Comment liked!" });
  };

  const deletePhoto = (albumId: string, photoId: string) => {
    if (!confirm('Are you sure you want to delete this photo? This action cannot be undone.')) {
      return;
    }

    setAlbums(albums.map(album => 
      album.id === albumId 
        ? { ...album, photos: album.photos.filter(photo => photo.id !== photoId) }
        : album
    ));

    // Close photo viewer if deleted photo was being viewed
    if (selectedPhoto?.id === photoId) {
      setSelectedPhoto(null);
    }

    toast({ title: "Photo deleted successfully" });
  };

  const deleteAlbum = (albumId: string) => {
    if (!confirm('Are you sure you want to delete this album and all its photos? This action cannot be undone.')) {
      return;
    }

    setAlbums(albums.filter(album => album.id !== albumId));
    
    // Close album view if deleted album was being viewed
    if (selectedAlbum?.id === albumId) {
      setSelectedAlbum(null);
    }

    toast({ title: "Album deleted successfully" });
  };

  const deleteComment = (photoId: string, commentId: string) => {
    if (!confirm('Are you sure you want to delete this comment? This action cannot be undone.')) {
      return;
    }

    setAlbums(albums.map(album => ({
      ...album,
      photos: album.photos.map(photo => 
        photo.id === photoId 
          ? { ...photo, comments: photo.comments.filter(comment => comment.id !== commentId) }
          : photo
      )
    })));

    // Update selected photo if viewing comments
    if (selectedPhoto?.id === photoId) {
      setSelectedPhoto(prev => prev ? {
        ...prev,
        comments: prev.comments.filter(comment => comment.id !== commentId)
      } : null);
    }

    toast({ title: "Comment deleted successfully" });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <UniversalBackButton />
      
      {/* Header */}
      <div className="bg-white shadow-sm px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-gray-900">Photo Gallery</h1>
          <Dialog open={showCreateAlbum} onOpenChange={setShowCreateAlbum}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                New Album
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Album</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  placeholder="Album name"
                  value={newAlbumName}
                  onChange={(e) => setNewAlbumName(e.target.value)}
                />
                <div className="flex gap-2">
                  <Button onClick={createAlbum} className="flex-1">Create Album</Button>
                  <Button variant="outline" onClick={() => setShowCreateAlbum(false)}>Cancel</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Albums Grid */}
      <div className="px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {albums.map((album) => (
            <div key={album.id} className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="aspect-square bg-gray-200 flex items-center justify-center">
                {album.photos.length > 0 ? (
                  <img 
                    src={album.photos[0].url} 
                    alt={album.name}
                    className="w-full h-full object-cover cursor-pointer"
                    onClick={() => openPhotoViewer(album, 0)}
                  />
                ) : (
                  <div className="text-gray-400">
                    <Plus className="w-12 h-12" />
                  </div>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-lg">{album.name}</h3>
                <p className="text-sm text-gray-600">{album.photos.length} photos</p>
                <div className="flex gap-2 mt-3">
                  <Button 
                    size="sm" 
                    onClick={() => setSelectedAlbum(album)}
                    className="flex-1"
                  >
                    Open
                  </Button>
                  <SimpleImageUpload
                    onImageUploaded={(imageUrl) => addPhotoToAlbum(album.id, imageUrl)}
                    buttonText="+"
                    isProfileImage={false}
                    className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-sm"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => deleteAlbum(album.id)}
                    className="px-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                    title="Delete Album"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Album View */}
      {selectedAlbum && !selectedPhoto && (
        <Dialog open={true} onOpenChange={() => setSelectedAlbum(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedAlbum.name}</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {selectedAlbum.photos.map((photo, index) => (
                <div key={photo.id} className="aspect-square bg-gray-200 rounded-lg overflow-hidden">
                  <img 
                    src={photo.url} 
                    alt={photo.caption}
                    className="w-full h-full object-cover cursor-pointer hover:opacity-90 transition-opacity"
                    onClick={() => openPhotoViewer(selectedAlbum, index)}
                  />
                </div>
              ))}
              <div className="aspect-square bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center">
                <SimpleImageUpload
                  onImageUploaded={(imageUrl) => addPhotoToAlbum(selectedAlbum.id, imageUrl)}
                  buttonText="Add Photo"
                  isProfileImage={false}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
                />
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Photo Viewer */}
      {selectedPhoto && selectedAlbum && (
        <Dialog open={true} onOpenChange={() => { setSelectedPhoto(null); setSelectedAlbum(null); }}>
          <DialogContent className="max-w-6xl max-h-[90vh] p-0">
            <div className="flex h-[80vh]">
              {/* Photo Display */}
              <div className="flex-1 bg-black flex items-center justify-center relative">
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white hover:bg-white/20 z-10"
                  onClick={() => navigatePhoto('prev')}
                  disabled={currentPhotoIndex === 0}
                >
                  <ChevronLeft className="w-6 h-6" />
                </Button>
                <img 
                  src={selectedPhoto.url} 
                  alt={selectedPhoto.caption}
                  className="max-w-full max-h-full object-contain"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white hover:bg-white/20 z-10"
                  onClick={() => navigatePhoto('next')}
                  disabled={currentPhotoIndex === selectedAlbum.photos.length - 1}
                >
                  <ChevronRight className="w-6 h-6" />
                </Button>
              </div>

              {/* Social Panel */}
              <div className="w-80 bg-white border-l flex flex-col">
                <div className="p-4 border-b">
                  <div className="flex items-center gap-4 mb-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => likePhoto(selectedPhoto.id)}
                      className="flex items-center gap-2"
                    >
                      <Heart className="w-4 h-4" />
                      {selectedPhoto.likes}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex items-center gap-2"
                    >
                      <MessageCircle className="w-4 h-4" />
                      {selectedPhoto.comments.length}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={sharePhoto}
                      className="flex items-center gap-2"
                    >
                      <Share2 className="w-4 h-4" />
                      Share
                    </Button>
                  </div>
                  
                  {/* OPC, Media, Multi sharing buttons */}
                  <div className="flex gap-2 mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 text-xs"
                      onClick={() => handleOPCShare(selectedPhoto)}
                    >
                      OPC
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 text-xs"
                      onClick={() => handleMediaShare(selectedPhoto)}
                    >
                      Media
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 text-xs"
                      onClick={() => handleMultiShare(selectedPhoto)}
                    >
                      Multi
                    </Button>
                  </div>
                  {selectedPhoto.caption && (
                    <p className="text-sm text-gray-700">{selectedPhoto.caption}</p>
                  )}
                </div>

                {/* Comments */}
                <div className="flex-1 overflow-y-auto p-4">
                  {selectedPhoto.comments.map((comment) => (
                    <div key={comment.id} className="flex gap-3 mb-4">
                      <img 
                        src={comment.avatar} 
                        alt={comment.user}
                        className="w-8 h-8 rounded-full"
                      />
                      <div className="flex-1">
                        <div className="bg-gray-100 rounded-lg px-3 py-2">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <p className="font-medium text-sm">{comment.user}</p>
                              <p className="text-sm">{comment.text}</p>
                            </div>
                            {/* Delete button for user's own comments */}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteComment(selectedPhoto.id, comment.id)}
                              className="p-1 h-auto text-red-600 hover:text-red-700 hover:bg-red-50"
                              title="Delete Comment"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                        
                        {/* Comment Action Buttons */}
                        <div className="flex gap-2 mt-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="px-2 py-1 h-auto text-xs"
                            onClick={() => likeComment(comment.id)}
                          >
                            <Heart className="w-3 h-3 mr-1" />
                            Like
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="px-2 py-1 h-auto text-xs"
                          >
                            Reply
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="px-2 py-1 h-auto text-xs"
                          >
                            Share
                          </Button>
                        </div>
                        
                        <p className="text-xs text-gray-500 mt-1">{comment.timestamp}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Comment Input */}
                <div className="p-4 border-t">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add a comment..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addComment()}
                      className="flex-1"
                    />
                    <Button onClick={addComment} size="sm">Post</Button>
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}