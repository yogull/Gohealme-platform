import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { Store, Plus, Search, Heart, MessageCircle, Share2, Camera, Edit, ArrowLeft, Home } from "lucide-react";
import { BackButton } from "@/components/BackButton";
import type { PersonalShop, PersonalShopAffiliateLink } from "@shared/schema";

const CATEGORIES = [
  "Electronics", "Health & Wellness", "Fashion", "Home & Garden", "Sports & Fitness",
  "Beauty & Personal Care", "Books & Media", "Automotive", "Food & Beverages", "Toys & Games"
];

const BRANDS = [
  "Amazon", "Apple", "Nike", "Adidas", "Samsung", "Sony", "LG", "HP", "Dell",
  "Calvin Klein", "H&M", "Zara", "IKEA", "John Lewis", "Boots", "Superdrug"
];

// Banner gradient helper function
const getBannerGradient = (colorScheme: string) => {
  switch (colorScheme) {
    case "blue-green": return "bg-gradient-to-r from-blue-500 to-green-500";
    case "orange-red": return "bg-gradient-to-r from-orange-500 to-red-500";
    case "green-blue": return "bg-gradient-to-r from-green-500 to-blue-500";
    case "gold-orange": return "bg-gradient-to-r from-yellow-500 to-orange-500";
    case "dark-purple": return "bg-gradient-to-r from-purple-800 to-purple-600";
    default: return "bg-gradient-to-r from-purple-500 to-pink-500";
  }
};

export default function PersonalShop() {
  const { appUser: user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [isCreateShopOpen, setIsCreateShopOpen] = useState(false);
  const [isAddLinkOpen, setIsAddLinkOpen] = useState(false);
  const [isBannerEditOpen, setIsBannerEditOpen] = useState(false);
  const [shopFormData, setShopFormData] = useState({
    shopName: "",
    description: "",
    bannerImage: ""
  });
  const [bannerFormData, setBannerFormData] = useState({
    shopName: "",
    description: "",
    bannerImage: "",
    bannerColor: "purple-pink"
  });
  const [linkFormData, setLinkFormData] = useState({
    title: "",
    description: "",
    affiliateUrl: "",
    productImageUrl: "",
    brand: "",
    category: "",
    price: ""
  });

  // Get user's personal shop - if exists, redirect to view page
  const { data: shop, isLoading: shopLoading } = useQuery({
    queryKey: [`/api/personal-shops/user/${user?.id}`],
    enabled: !!user?.id
  });

  // Redirect to view page if shop already exists
  useEffect(() => {
    if (shop && !shopLoading) {
      // Use proper client-side navigation instead of window.location
      setLocation(`/personal-shop-view/${shop.id}`);
    }
  }, [shop, shopLoading]);

  // Get shop's affiliate links
  const { data: affiliateLinks, isLoading: linksLoading } = useQuery({
    queryKey: [`/api/personal-shops/${shop?.id}/affiliate-links`],
    enabled: !!shop?.id
  });

  // Create shop mutation with redirect logic for existing shops
  const createShopMutation = useMutation({
    mutationFn: async (shopData: any) => {
      try {
        const response = await fetch('/api/personal-shops', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(shopData)
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          if (errorData.error?.includes('already has a personal shop')) {
            // User already has a shop, fetch it and redirect
            const existingShopResponse = await fetch(`/api/personal-shops/user/${user?.id}`);
            if (existingShopResponse.ok) {
              const existingShop = await existingShopResponse.json();
              setLocation(`/personal-shop-view/${existingShop.id}`);
              return existingShop;
            }
          }
          throw new Error(errorData.error || 'Failed to create shop');
        }
        
        return response.json();
      } catch (error: any) {
        console.error("Shop creation error:", error);
        throw error;
      }
    },
    onSuccess: (data) => {
      if (data?.id) {
        toast({ title: "Personal shop created successfully!" });
        setIsCreateShopOpen(false);
        setLocation(`/personal-shop-view/${data.id}`);
      }
    },
    onError: (error: any) => {
      console.error("Shop creation error:", error);
      toast({ 
        title: "Failed to create shop", 
        description: error.message || "Please try again",
        variant: "destructive" 
      });
    }
  });

  // Add affiliate link mutation
  const addLinkMutation = useMutation({
    mutationFn: async (linkData: any) => {
      return await apiRequest("POST", `/api/personal-shops/${shop?.id}/affiliate-links`, linkData);
    },
    onSuccess: () => {
      toast({ 
        title: user?.isAdmin ? "Affiliate link added and shared to all walls!" : "Affiliate link added! Pay £1 to activate.",
        description: user?.isAdmin ? "Your link is live and visible to everyone." : "Complete payment to share with the community."
      });
      setIsAddLinkOpen(false);
      setLinkFormData({
        title: "", description: "", affiliateUrl: "", productImageUrl: "",
        brand: "", category: "", price: ""
      });
      queryClient.invalidateQueries({ queryKey: [`/api/personal-shops/${shop?.id}/affiliate-links`] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to add affiliate link", 
        description: error.message || "Please try again",
        variant: "destructive" 
      });
    }
  });

  const handleCreateShop = () => {
    if (!shopFormData.shopName.trim()) {
      toast({ title: "Shop name is required", variant: "destructive" });
      return;
    }
    
    createShopMutation.mutate({
      shopName: shopFormData.shopName,
      description: shopFormData.description
    });
  };

  const handleAddLink = () => {
    if (!linkFormData.title.trim() || !linkFormData.affiliateUrl.trim()) {
      toast({ title: "Title and affiliate URL are required", variant: "destructive" });
      return;
    }
    
    addLinkMutation.mutate({
      userId: user?.id,
      ...linkFormData
    });
  };

  if (shopLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Checking your shop status...</p>
        </div>
      </div>
    );
  }

  // If shop exists, the useEffect will redirect, but show loading until redirect
  if (shop) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Redirecting to your shop...</p>
        </div>
      </div>
    );
  }

  if (!shop) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center space-y-6">
          <Store className="w-24 h-24 mx-auto text-gray-400" />
          <div>
            <h1 className="text-3xl font-bold mb-2">Create Your Personal Shop</h1>
            <p className="text-gray-600 mb-6">
              Set up your personal affiliate shop and start earning from your recommendations!
            </p>
            <p className="text-sm text-gray-500 mb-6">
              {user?.isAdmin ? "✅ Admin privileges: Unlimited links, no fees" : "💰 £1 per affiliate link • Maximum 20 links • £2 maintenance per 20-link block"}
            </p>
          </div>

          <Dialog open={isCreateShopOpen} onOpenChange={setIsCreateShopOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                <Store className="w-5 h-5 mr-2" />
                Create My Personal Shop
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create Your Personal Shop</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Shop Name *</label>
                  <Input
                    value={shopFormData.shopName}
                    onChange={(e) => setShopFormData(prev => ({ ...prev, shopName: e.target.value }))}
                    placeholder="My Awesome Shop"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <Textarea
                    value={shopFormData.description}
                    onChange={(e) => setShopFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe what your shop offers..."
                    rows={3}
                  />
                </div>
                <Button 
                  onClick={handleCreateShop}
                  disabled={createShopMutation.isPending}
                  className="w-full"
                >
                  {createShopMutation.isPending ? "Creating..." : "Create Shop"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Header with Navigation */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            onClick={() => setLocation('/')}
            className="flex items-center gap-2"
          >
            <Home className="w-4 h-4" />
            Dashboard
          </Button>
          <Button 
            variant="outline" 
            onClick={() => setLocation('/profile-wall')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Profile
          </Button>
        </div>
        <h1 className="text-2xl font-bold">My Personal Shop</h1>
      </div>

      {/* Shop Banner */}
      <div className="relative mb-8">
        <div className="h-48 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg relative overflow-hidden">
          <div className="absolute inset-0 bg-black bg-opacity-30"></div>
          <div className="absolute bottom-4 left-4 text-white z-10">
            <h1 className="text-3xl font-bold">{shop.shopName}</h1>
            <p className="text-lg opacity-90">{shop.description}</p>
            <div className="flex items-center gap-4 mt-2">
              <Badge variant="secondary" className="bg-white text-black">
                {shop.totalAffiliateLinks} {shop.totalAffiliateLinks === 1 ? 'Product' : 'Products'}
              </Badge>
              <Badge variant="outline" className="border-green-500 text-green-700">
                Max: {shop.maxLinks} Links
              </Badge>
            </div>
          </div>
          <div className="absolute top-4 right-4 flex gap-2">
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => setLocation(`/profile-wall/${user?.id}`)}
              className="bg-white/90 text-gray-800 hover:bg-white"
            >
              View My Profile
            </Button>
            <Dialog open={isBannerEditOpen} onOpenChange={setIsBannerEditOpen}>
              <DialogTrigger asChild>
                <Button 
                  size="sm" 
                  variant="secondary"
                  onClick={() => {
                    setBannerFormData({
                      shopName: shop.shopName,
                      description: shop.description,
                      bannerImage: shop.bannerImage || "",
                      bannerColor: shop.bannerColor || "purple-pink"
                    });
                  }}
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Edit Banner
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>🎨 Customize Your Shop Banner</DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  {/* Banner Preview */}
                  <div className="relative">
                    <div className={`h-32 rounded-lg relative overflow-hidden ${getBannerGradient(bannerFormData.bannerColor)}`}>
                      <div className="absolute inset-0 bg-black bg-opacity-30"></div>
                      <div className="absolute bottom-2 left-4 text-white z-10">
                        <h3 className="text-xl font-bold">{bannerFormData.shopName || "Your Shop Name"}</h3>
                        <p className="text-sm opacity-90">{bannerFormData.description || "Your shop description"}</p>
                      </div>
                      {bannerFormData.bannerImage && (
                        <img 
                          src={bannerFormData.bannerImage} 
                          alt="Banner" 
                          className="absolute inset-0 w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mt-2">Live Preview</p>
                  </div>

                  {/* Banner Customization Form */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Shop Name</label>
                      <Input
                        value={bannerFormData.shopName}
                        onChange={(e) => setBannerFormData(prev => ({ ...prev, shopName: e.target.value }))}
                        placeholder="Amazing Shop Name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Shop Description</label>
                      <Input
                        value={bannerFormData.description}
                        onChange={(e) => setBannerFormData(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Quality products at great prices"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Banner Image URL (Optional)</label>
                      <Input
                        value={bannerFormData.bannerImage}
                        onChange={(e) => setBannerFormData(prev => ({ ...prev, bannerImage: e.target.value }))}
                        placeholder="https://example.com/banner.jpg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Color Scheme</label>
                      <Select value={bannerFormData.bannerColor} onValueChange={(value) => setBannerFormData(prev => ({ ...prev, bannerColor: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="purple-pink">Purple to Pink</SelectItem>
                          <SelectItem value="blue-green">Blue to Green</SelectItem>
                          <SelectItem value="orange-red">Orange to Red</SelectItem>
                          <SelectItem value="green-blue">Green to Blue</SelectItem>
                          <SelectItem value="gold-orange">Gold to Orange</SelectItem>
                          <SelectItem value="dark-purple">Dark Purple</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3">
                    <Button variant="outline" onClick={() => setIsBannerEditOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleUpdateBanner} className="bg-green-600 hover:bg-green-700">
                      Update Banner
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-4 mb-8">
        <Dialog open={isAddLinkOpen} onOpenChange={setIsAddLinkOpen}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="w-5 h-5 mr-2" />
              Add Affiliate Link (£1)
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Affiliate Link</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Product Title *</label>
                <Input
                  value={linkFormData.title}
                  onChange={(e) => setLinkFormData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Amazing Product Name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Price</label>
                <Input
                  value={linkFormData.price}
                  onChange={(e) => setLinkFormData(prev => ({ ...prev, price: e.target.value }))}
                  placeholder="£29.99"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Brand</label>
                <Select onValueChange={(value) => setLinkFormData(prev => ({ ...prev, brand: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select brand" />
                  </SelectTrigger>
                  <SelectContent>
                    {BRANDS.map(brand => (
                      <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Category</label>
                <Select onValueChange={(value) => setLinkFormData(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-2">Affiliate URL *</label>
                <Input
                  value={linkFormData.affiliateUrl}
                  onChange={(e) => setLinkFormData(prev => ({ ...prev, affiliateUrl: e.target.value }))}
                  placeholder="https://partner.site.com/product/12345?ref=yourcode"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-2">Product Image URL</label>
                <Input
                  value={linkFormData.productImageUrl}
                  onChange={(e) => setLinkFormData(prev => ({ ...prev, productImageUrl: e.target.value }))}
                  placeholder="https://example.com/product-image.jpg"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-2">Description</label>
                <Textarea
                  value={linkFormData.description}
                  onChange={(e) => setLinkFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Why you recommend this product..."
                  rows={3}
                />
              </div>
              <div className="md:col-span-2">
                <Button 
                  onClick={handleAddLink}
                  disabled={addLinkMutation.isPending}
                  className="w-full"
                >
                  {addLinkMutation.isPending ? "Adding..." : `Add Link ${!user?.isAdmin ? '(£1 Payment Required)' : ''}`}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Button variant="outline" onClick={() => window.location.href = '/personal-shop-search'}>
          <Search className="w-5 h-5 mr-2" />
          Search All Shops
        </Button>
      </div>

      {/* Affiliate Links Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {affiliateLinks?.map((link: PersonalShopAffiliateLink) => (
          <Card key={link.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative">
              {link.productImageUrl ? (
                <img 
                  src={link.productImageUrl} 
                  alt={link.title}
                  className="w-full h-48 object-cover"
                />
              ) : (
                <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
                  <span className="text-gray-500">No Image</span>
                </div>
              )}
              {!link.isPaid && !user?.isAdmin && (
                <Badge className="absolute top-2 right-2 bg-red-500">
                  Payment Required
                </Badge>
              )}
              {link.isSharedToWalls && (
                <Badge className="absolute top-2 left-2 bg-green-500">
                  Shared
                </Badge>
              )}
            </div>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-lg">{link.title}</h3>
                {link.price && (
                  <span className="text-lg font-bold text-green-600">{link.price}</span>
                )}
              </div>
              <div className="flex gap-2 mb-3">
                <Badge variant="outline">{link.brand}</Badge>
                <Badge variant="outline">{link.category}</Badge>
              </div>
              {link.description && (
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">{link.description}</p>
              )}
              
              {/* Social Actions */}
              <div className="flex justify-between items-center pt-3 border-t">
                <div className="flex gap-4">
                  <Button variant="ghost" size="sm">
                    <Heart className="w-4 h-4 mr-1" />
                    {link.likes}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MessageCircle className="w-4 h-4 mr-1" />
                    {link.comments}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Share2 className="w-4 h-4 mr-1" />
                    {link.shares}
                  </Button>
                </div>
                
                {/* Only show affiliate URL to shop owner */}
                {user?.id === link.userId && (
                  <Button 
                    size="sm" 
                    onClick={() => window.open(link.affiliateUrl, '_blank')}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Visit Link
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {!affiliateLinks?.length && (
        <div className="text-center py-12">
          <Plus className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-xl font-semibold mb-2">No affiliate links yet</h3>
          <p className="text-gray-600">Add your first affiliate link to start earning!</p>
        </div>
      )}
    </div>
  );
}