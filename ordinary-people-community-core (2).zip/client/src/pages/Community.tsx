import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTutorial } from "@/hooks/useTutorial";
import { PageHeader } from "@/components/PageHeader";
import { TutorialPopup } from "@/components/TutorialPopup";
import { AskAIButton } from "@/components/AskAIButton";
import { AdCarousel } from "@/components/AdCarousel";
import { AdvertisingButton } from "@/components/AdvertisingButton";
import { UniversalInstructionsButton } from "@/components/UniversalInstructionsButton";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MapPin, Users, MessageCircle, Plus, Search, Filter, Share2 } from "lucide-react";
import type { User, CommunityDiscussion, DiscussionCategory, DiscussionMessage } from "@shared/schema";
import SocialActions from "@/components/SocialActions";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";
import { FloatingProfileButton } from "@/components/FloatingProfileButton";
import { BackButton } from "@/components/BackButton";
import { PageNavigationGuide } from "@/components/PageNavigationGuide";

const LOCATION_DATA = {
  "United Kingdom": [
    "London", "Birmingham", "Manchester", "Liverpool", "Leeds", "Sheffield", "Bristol", 
    "Glasgow", "Edinburgh", "Newcastle", "Cardiff", "Belfast", "Leicester", "Coventry",
    "Bradford", "Nottingham", "Kingston upon Hull", "Plymouth", "Stoke-on-Trent", "Wolverhampton"
  ],
  "United States": [
    "New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", 
    "San Antonio", "San Diego", "Dallas", "San Jose", "Austin", "Jacksonville", 
    "Fort Worth", "Columbus", "Charlotte", "San Francisco", "Indianapolis", "Seattle", "Denver", "Washington DC"
  ],
  "Canada": [
    "Toronto", "Montreal", "Vancouver", "Calgary", "Edmonton", "Ottawa", "Winnipeg", 
    "Quebec City", "Hamilton", "Kitchener", "London", "Victoria", "Halifax", "Oshawa",
    "Windsor", "Saskatoon", "Regina", "Sherbrooke", "Barrie", "Kelowna"
  ],
  "Australia": [
    "Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide", "Gold Coast", "Newcastle", 
    "Canberra", "Sunshine Coast", "Wollongong", "Geelong", "Hobart", "Townsville", 
    "Cairns", "Darwin", "Toowoomba", "Ballarat", "Bendigo", "Albury", "Launceston"
  ],
  "Germany": [
    "Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt", "Stuttgart", "Düsseldorf", 
    "Dortmund", "Essen", "Leipzig", "Bremen", "Dresden", "Hanover", "Nuremberg", 
    "Duisburg", "Bochum", "Wuppertal", "Bielefeld", "Bonn", "Münster"
  ],
  "France": [
    "Paris", "Marseille", "Lyon", "Toulouse", "Nice", "Nantes", "Strasbourg", 
    "Montpellier", "Bordeaux", "Lille", "Rennes", "Reims", "Le Havre", "Saint-Étienne",
    "Toulon", "Grenoble", "Dijon", "Angers", "Nîmes", "Villeurbanne"
  ],
  "Ireland": [
    "Dublin", "Cork", "Limerick", "Galway", "Waterford", "Drogheda", "Dundalk", 
    "Bray", "Navan", "Ennis", "Tralee", "Carlow", "Newbridge", "Naas", "Athlone",
    "Portlaoise", "Mullingar", "Wexford", "Letterkenny", "Kilkenny"
  ],
  "Netherlands": [
    "Amsterdam", "Rotterdam", "The Hague", "Utrecht", "Eindhoven", "Tilburg", 
    "Groningen", "Almere", "Breda", "Nijmegen", "Enschede", "Haarlem", "Arnhem", 
    "Zaanstad", "Amersfoort", "Apeldoorn", "'s-Hertogenbosch", "Hoofddorp", "Maastricht", "Leiden"
  ]
};

const SOCIAL_PLATFORMS = [
  { name: "Facebook", icon: "fab fa-facebook", color: "#1877f2" },
  { name: "Twitter", icon: "fab fa-twitter", color: "#1da1f2" },
  { name: "Instagram", icon: "fab fa-instagram", color: "#e4405f" },
  { name: "LinkedIn", icon: "fab fa-linkedin", color: "#0077b5" },
  { name: "YouTube", icon: "fab fa-youtube", color: "#ff0000" },
  { name: "TikTok", icon: "fab fa-tiktok", color: "#000000" }
];

export default function Community() {
  const { appUser: user } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedCountry, setSelectedCountry] = useState<string>("all");
  const [selectedArea, setSelectedArea] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false);
  const [selectedDiscussion, setSelectedDiscussion] = useState<number | null>(null);
  const [formCategoryId, setFormCategoryId] = useState<string>("");
  const [formCountry, setFormCountry] = useState<string>("");
  const [formArea, setFormArea] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [location] = useLocation();
  const { shouldShowTutorial, getTutorialSteps, markTutorialComplete } = useTutorial();

  // Fetch discussion categories
  const { data: categories = [], refetch: refetchCategories } = useQuery<DiscussionCategory[]>({
    queryKey: ["/api/discussion-categories"],
    staleTime: 0, // Always fetch fresh data
  });

  // Fetch community discussions
  const combinedLocation = selectedCountry !== "all" && selectedArea !== "all" 
    ? `${selectedArea}, ${selectedCountry}` 
    : selectedCountry !== "all" ? selectedCountry : "all";
  
  const { data: discussions = [] } = useQuery<CommunityDiscussion[]>({
    queryKey: ["/api/community-discussions", selectedCategory, combinedLocation, searchQuery],
  });

  // Fetch messages for selected discussion
  const { data: messages = [] } = useQuery<DiscussionMessage[]>({
    queryKey: ["/api/discussion-messages", selectedDiscussion],
    enabled: !!selectedDiscussion,
  });

  // Create discussion mutation
  const createDiscussionMutation = useMutation({
    mutationFn: async (data: {
      title: string;
      description: string;
      categoryId: number;
      location?: string;
      tags: string[];
    }) => {
      const response = await apiRequest("POST", "/api/community-discussions", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community-discussions"] });
      setIsCreateDialogOpen(false);
      // Reset form values
      setFormCategoryId("");
      setFormCountry("");
      setFormArea("");
      toast({
        title: "Discussion Created",
        description: "Your community discussion has been started successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create discussion. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create category mutation (admin only)
  const createCategoryMutation = useMutation({
    mutationFn: async (data: {
      name: string;
      description: string;
      icon: string;
      color: string;
    }) => {
      const response = await apiRequest("POST", "/api/discussion-categories", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/discussion-categories"] });
      refetchCategories(); // Force immediate refetch
      setIsCategoryDialogOpen(false);
      toast({
        title: "Category Created",
        description: "New discussion category has been created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create category. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Add message mutation
  const addMessageMutation = useMutation({
    mutationFn: async (data: { discussionId: number; content: string }) => {
      const response = await apiRequest("POST", "/api/discussion-messages", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/discussion-messages"] });
    },
  });

  const filteredDiscussions = discussions.filter(discussion => {
    const matchesCategory = selectedCategory === "all" || discussion.categoryId === parseInt(selectedCategory);
    const matchesLocation = combinedLocation === "all" || discussion.location === combinedLocation ||
      (selectedCountry !== "all" && discussion.location?.includes(selectedCountry));
    const matchesSearch = !searchQuery || 
      discussion.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      discussion.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesLocation && matchesSearch;
  });

  const handleCreateDiscussion = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!formCategoryId) {
      toast({
        title: "Error",
        description: "Please select a category for your discussion.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData(e.currentTarget);
    const title = formData.get("title") as string;
    const description = formData.get("description") as string;
    const tagsString = formData.get("tags") as string || "";
    
    const tags = tagsString
      .split(",")
      .map(tag => tag.trim())
      .filter(tag => tag.length > 0);

    let location: string | undefined;
    if (formCountry && formArea) {
      location = `${formArea}, ${formCountry}`;
    } else if (formCountry) {
      location = formCountry;
    }

    createDiscussionMutation.mutate({
      title,
      description,
      categoryId: parseInt(formCategoryId),
      location,
      tags,
    });
  };

  const handleAddMessage = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedDiscussion) return;
    
    const formData = new FormData(e.currentTarget);
    const content = formData.get("content") as string;
    
    if (content.trim()) {
      addMessageMutation.mutate({
        discussionId: selectedDiscussion,
        content: content.trim(),
      });
      e.currentTarget.reset();
    }
  };

  const shareToSocialMedia = (discussion: CommunityDiscussion, platform: string) => {
    const url = window.location.href;
    const text = `Check out this discussion: ${discussion.title}`;
    
    let shareUrl = "";
    switch (platform.toLowerCase()) {
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
        break;
      case "linkedin":
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
        break;
      default:
        return;
    }
    
    window.open(shareUrl, "_blank", "width=600,height=400");
  };

  return (
    <div className="relative w-full overflow-x-hidden">
      {/* Advertisement Carousels - Hide on mobile */}
      {user && (
        <div className="hidden sm:block">
          <AdCarousel 
            location="Nottingham"
            scope="local"
            userId={user.id}
            position="left"
          />
          <AdCarousel 
            scope="national"
            userId={user.id}
            position="right"
          />
        </div>
      )}

      {/* Page Help System */}
      <UniversalInstructionsButton currentPage="community" />
      
      {/* Advertising Button - Top of Page */}
      <AdvertisingButton />

      <div className="mobile-safe w-full max-w-[90vw] sm:max-w-2xl mx-auto px-2 sm:px-4 py-2 overflow-x-hidden">
        {/* Ask AI Button */}
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-6">
          <div className="flex justify-center">
            <AskAIButton 
              variant="default" 
              size="lg" 
              className="bg-orange-500 hover:bg-orange-600 text-white border-none shadow-lg"
            />
          </div>
        </div>

      <PageHeader 
        title="Community Discussions" 
        subtitle="Join location-based and topic-based health discussions. Connect with people in your area or with shared health interests."
      />

      {/* Health & Wellness Categories Spotlight */}
      <Card className="mb-4 bg-gradient-to-r from-green-50 to-blue-50 border-green-200 w-full max-w-[95vw] sm:max-w-2xl mx-auto">
        <CardHeader className="px-2 py-2">
          <CardTitle className="flex items-center gap-1 text-green-700 text-xs">
            <i className="fas fa-heart text-red-500 text-xs" />
            Health Categories
          </CardTitle>
          <p className="text-xs text-green-600">Quick health topics</p>
        </CardHeader>
        <CardContent className="px-2 py-2">
          <div className="grid grid-cols-2 gap-2">
            {categories
              .filter(cat => 
                cat.name.toLowerCase().includes('health') || 
                cat.name.toLowerCase().includes('wellness') ||
                cat.name.toLowerCase().includes('nutrition') ||
                cat.name.toLowerCase().includes('mental') ||
                cat.name.toLowerCase().includes('fitness') ||
                cat.name.toLowerCase().includes('exercise') ||
                cat.name.toLowerCase().includes('sleep') ||
                cat.name.toLowerCase().includes('stress') ||
                cat.name.toLowerCase().includes('supplement') ||
                cat.name.toLowerCase().includes('chronic') ||
                cat.name.toLowerCase().includes('alternative') ||
                cat.name.toLowerCase().includes('women') ||
                cat.name.toLowerCase().includes('men') ||
                cat.name.toLowerCase().includes('senior') ||
                cat.name.toLowerCase().includes('teen') ||
                cat.name.toLowerCase().includes('youth')
              )
              .slice(0, 10)
              .map((category) => (
                <Link key={category.id} href={`/community/category/${category.id}`}>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-auto py-2 px-2 text-xs hover:bg-green-100 border-green-200 w-full min-h-[60px]"
                    style={{ borderColor: category.color }}
                  >
                    <div className="text-center w-full">
                      <i className={`${category.icon} text-sm mb-1 block`} style={{ color: category.color }} />
                      <div className="font-medium text-xs leading-tight break-words">{category.name}</div>
                    </div>
                  </Button>
                </Link>
              ))}
          </div>
        </CardContent>
      </Card>

      {/* Filters and Search */}
      <div className="mb-4 w-full max-w-[95vw] mx-auto">
        <div className="w-full">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search discussions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-full"
            />
          </div>
        </div>
        
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-[180px]">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Filter by Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Show All Categories</SelectItem>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id.toString()}>
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center">
                    <i className={`${category.icon} mr-2`} style={{ color: category.color }} />
                    {category.name}
                  </div>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Quick Navigate to Category */}
        <Select onValueChange={(value) => {
          if (value && value !== "placeholder") {
            setLocation(`/community/category/${value}`);
          }
        }}>
          <SelectTrigger className="w-[220px] bg-blue-50 border-blue-200 hover:bg-blue-100">
            <MessageCircle className="h-4 w-4 mr-2 text-blue-600" />
            <SelectValue placeholder="📋 Choose Category to Visit" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="placeholder" disabled className="text-gray-400 font-medium">
              👇 Click any category to visit:
            </SelectItem>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id.toString()} className="hover:bg-blue-50">
                <div className="flex items-center">
                  <i className={`${category.icon} mr-2`} style={{ color: category.color }} />
                  {category.name}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Category Quick Access Links */}
        <div className="flex flex-wrap gap-2">
          {categories.slice(0, 6).map((category) => (
            <Link key={category.id} href={`/community/category/${category.id}`}>
              <Button variant="outline" size="sm" className="text-xs">
                <i className={`${category.icon} mr-1`} style={{ color: category.color }} />
                {category.name}
              </Button>
            </Link>
          ))}
        </div>

        <Select value={selectedCountry} onValueChange={(value) => {
          setSelectedCountry(value);
          setSelectedArea("all"); // Reset area when country changes
        }}>
          <SelectTrigger className="w-[140px]">
            <MapPin className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Country" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Countries</SelectItem>
            {Object.keys(LOCATION_DATA).map((country) => (
              <SelectItem key={country} value={country}>
                {country}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {selectedCountry !== "all" && (
          <Select value={selectedArea} onValueChange={setSelectedArea}>
            <SelectTrigger className="w-[140px]">
              <MapPin className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Area/County" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Areas</SelectItem>
              {LOCATION_DATA[selectedCountry as keyof typeof LOCATION_DATA]?.map((area) => (
                <SelectItem key={area} value={area}>
                  {area}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {user && user.isAdmin && (
          <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="mr-2">
                <Plus className="h-4 w-4 mr-2" />
                Add Category
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Discussion Category</DialogTitle>
              </DialogHeader>
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                createCategoryMutation.mutate({
                  name: formData.get("name") as string,
                  description: formData.get("description") as string,
                  icon: formData.get("icon") as string,
                  color: formData.get("color") as string,
                });
                e.currentTarget.reset(); // Reset form after submission
              }} className="space-y-4">
                <div>
                  <Label htmlFor="name">Category Name</Label>
                  <Input id="name" name="name" placeholder="e.g., Brain Injury, Vitamins" required />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" name="description" placeholder="Brief description of this category" required />
                </div>
                <div>
                  <Label htmlFor="icon">Font Awesome Icon Class</Label>
                  <Input id="icon" name="icon" placeholder="e.g., fas fa-brain, fas fa-pills" required />
                </div>
                <div>
                  <Label htmlFor="color">Color (hex)</Label>
                  <Input id="color" name="color" placeholder="#ff6b6b" required />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="submit" disabled={createCategoryMutation.isPending}>
                    {createCategoryMutation.isPending ? "Creating..." : "Create Category"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Start Discussion
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Start a New Discussion</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateDiscussion} className="space-y-4">
              <div>
                <Label htmlFor="title">Discussion Title</Label>
                <Input
                  id="title"
                  name="title"
                  placeholder="What would you like to discuss?"
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="Provide more details about your discussion topic..."
                  rows={4}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="categoryId">Category</Label>
                  <Select value={formCategoryId} onValueChange={setFormCategoryId} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id.toString()}>
                          <div className="flex items-center">
                            <i className={`${category.icon} mr-2`} style={{ color: category.color }} />
                            {category.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="discussionCountry">Country (Optional)</Label>
                    <Select value={formCountry} onValueChange={(value) => {
                      setFormCountry(value);
                      setFormArea(""); // Reset area when country changes
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No specific country</SelectItem>
                        {Object.keys(LOCATION_DATA).map((country) => (
                          <SelectItem key={country} value={country}>
                            {country}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {formCountry && (
                    <div>
                      <Label htmlFor="discussionArea">Area/City (Optional)</Label>
                      <Select value={formArea} onValueChange={setFormArea}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select area" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No specific area</SelectItem>
                          {LOCATION_DATA[formCountry as keyof typeof LOCATION_DATA]?.map((area) => (
                            <SelectItem key={area} value={area}>
                              {area}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="tags">Tags (comma-separated)</Label>
                <Input
                  id="tags"
                  name="tags"
                  placeholder="health tips, nutrition, mental health..."
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createDiscussionMutation.isPending}>
                  {createDiscussionMutation.isPending ? "Creating..." : "Start Discussion"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Discussion List */}
      <div className="grid gap-2 w-full max-w-[95vw] sm:max-w-2xl mx-auto">
        {filteredDiscussions.map((discussion) => {
          const category = categories.find(c => c.id === discussion.categoryId);
          
          return (
            <Card key={discussion.id} className="hover:shadow-md transition-shadow w-full max-w-[95vw] sm:max-w-2xl mx-auto">
              <CardHeader className="px-2 py-2">
                <div className="flex flex-col gap-2">
                  <div className="w-full">
                    <div className="flex flex-wrap gap-1 mb-2">
                      {category && (
                        <Badge variant="secondary" className="text-xs">
                          <i className={`${category.icon} mr-1`} style={{ color: category.color }} />
                          {category.name}
                        </Badge>
                      )}
                      {discussion.location && (
                        <Badge variant="outline" className="text-xs">
                          <MapPin className="w-3 h-3 mr-1" />
                          {discussion.location}
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-sm font-semibold mb-1 break-words">{discussion.title}</CardTitle>
                    <p className="text-gray-600 text-xs mb-2 break-words">{discussion.description}</p>
                    
                    {discussion.tags && discussion.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {discussion.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {SOCIAL_PLATFORMS.slice(0, 3).map((platform) => (
                      <Button
                        key={platform.name}
                        variant="ghost"
                        size="sm"
                        onClick={() => shareToSocialMedia(discussion, platform.name)}
                        className="p-2"
                      >
                        <i className={platform.icon} style={{ color: platform.color }} />
                      </Button>
                    ))}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      {discussion.participantCount} participants
                    </div>
                    <div className="flex items-center">
                      <MessageCircle className="h-4 w-4 mr-1" />
                      {discussion.messageCount} messages
                    </div>
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedDiscussion(discussion.id)}
                  >
                    Join Discussion
                  </Button>
                </div>

                <SocialActions
                  itemId={discussion.id}
                  itemType="discussion"
                  initialLikes={0}
                  initialComments={discussion.messageCount}
                  isLiked={false}
                  showComments={true}
                  compact={true}
                />
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredDiscussions.length === 0 && (
        <div className="text-center py-8">
          <MessageCircle className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No discussions found</h3>
          <p className="text-gray-500 mb-4">
            {searchQuery || selectedCategory !== "all" || selectedCountry !== "all"
              ? "Try adjusting your filters or search terms."
              : "Be the first to start a community discussion!"}
          </p>
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Start Discussion
          </Button>
        </div>
      )}

      {/* Discussion Detail Modal */}
      {selectedDiscussion && (
        <Dialog open={!!selectedDiscussion} onOpenChange={() => setSelectedDiscussion(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Discussion Messages</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className="flex items-start space-x-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>U</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="text-sm">{message.content}</p>
                    </div>
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <span>{new Date(message.createdAt).toLocaleString()}</span>
                      {message.likes > 0 && (
                        <span className="ml-2">{message.likes} likes</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <Separator />

            <form onSubmit={handleAddMessage} className="flex space-x-2">
              <Input
                name="content"
                placeholder="Add your message..."
                className="flex-1"
                required
              />
              <Button type="submit" disabled={addMessageMutation.isPending}>
                {addMessageMutation.isPending ? "Sending..." : "Send"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      )}

        {/* Tutorial popup for first-time visitors */}
        {shouldShowTutorial(location) && (
          <TutorialPopup
            page={location}
            steps={getTutorialSteps(location)}
            onComplete={() => markTutorialComplete(location)}
            onSkip={() => markTutorialComplete(location)}
          />
        )}
      </div>
      
      {/* Floating Profile Wall Button */}
      <FloatingProfileButton />
    </div>
  );
}