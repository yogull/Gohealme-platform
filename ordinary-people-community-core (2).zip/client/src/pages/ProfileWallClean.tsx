import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Camera, Upload, Users, MessageCircle, Share2, Video, Image as ImageIcon } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import UniversalFeed from "@/components/UniversalFeed";
import { SimpleInstructionsButton } from "@/components/SimpleInstructionsButton";

export default function ProfileWall() {
  const { userId } = useParams<{ userId: string }>();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [newPost, setNewPost] = useState('');
  const [selectedMedia, setSelectedMedia] = useState<File | null>(null);
  const [uploadProcessing, setUploadProcessing] = useState(false);

  // Get current user
  const { data: currentUser } = useQuery({
    queryKey: ['/api/auth/me'],
    staleTime: 5 * 60 * 1000
  });

  // Get profile user data
  const { data: profileUser, isLoading: userLoading, error: userError } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId
  });

  // Get profile wall posts
  const { data: posts = [], isLoading: postsLoading } = useQuery({
    queryKey: [`/api/profile-wall?userId=${userId}`],
    enabled: !!userId
  });

  // Get user companies for shop button
  const { data: userCompanies = [] } = useQuery({
    queryKey: ['/api/companies/user', userId],
    enabled: !!userId
  });

  const isOwnProfile = currentUser?.id === (profileUser as any)?.id;

  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (postData: { content: string; mediaUrl?: string; mediaType?: string }) => {
      const response = await fetch('/api/profile-wall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(postData),
      });
      if (!response.ok) throw new Error('Failed to create post');
      return response.json();
    },
    onSuccess: () => {
      setNewPost("");
      setSelectedMedia(null);
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall"] });
      toast({
        title: "Success",
        description: "Your post has been shared!"
      });
    },
    onError: (error) => {
      console.error('Create post error:', error);
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleImageUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setSelectedMedia(file);
        toast({
          title: "Image Selected",
          description: "Image ready to post"
        });
      }
    };
    input.click();
  };

  const handleVideoUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'video/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setSelectedMedia(file);
        toast({
          title: "Video Selected",
          description: "Video ready to post"
        });
      }
    };
    input.click();
  };

  const handleCreatePost = async () => {
    if (!newPost.trim() && !selectedMedia) return;

    let mediaUrl = '';
    let mediaType = '';

    if (selectedMedia) {
      setUploadProcessing(true);
      
      try {
        const reader = new FileReader();
        reader.onload = async () => {
          const base64Data = reader.result as string;
          
          const fileData = {
            fileName: selectedMedia.name,
            fileType: selectedMedia.type,
            base64Data: base64Data,
            fileSize: selectedMedia.size
          };

          const uploadResponse = await fetch('/api/files/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(fileData)
          });

          if (uploadResponse.ok) {
            const uploadData = await uploadResponse.json();
            mediaUrl = uploadData.fileUrl;
            mediaType = selectedMedia.type.startsWith('video/') ? 'video' : 'image';
            
            await createPostMutation.mutateAsync({
              content: newPost.trim(),
              mediaUrl,
              mediaType
            });
          }
          
          setUploadProcessing(false);
        };
        reader.readAsDataURL(selectedMedia);
      } catch (error) {
        console.error('Upload error:', error);
        setUploadProcessing(false);
        toast({
          title: "Upload Error",
          description: "Failed to upload media. Please try again.",
          variant: "destructive"
        });
      }
    } else {
      await createPostMutation.mutateAsync({
        content: newPost.trim()
      });
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (userError || !profileUser) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold">Profile Not Found</h1>
          <p className="text-gray-600">This profile may not exist or there was an error loading it.</p>
          <Button onClick={() => setLocation('/dashboard')} className="bg-blue-600 text-white">
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const hasCompany = Array.isArray(userCompanies) && userCompanies.length > 0;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <SimpleInstructionsButton currentPage="community" />
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {/* Profile Header */}
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                <img
                  src={(profileUser as any)?.profileImageUrl || `data:image/svg+xml,${encodeURIComponent(`
                    <svg width="96" height="96" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="48" cy="48" r="48" fill="url(#gradient)"/>
                      <path d="M48 52c8.837 0 16-7.163 16-16s-7.163-16-16-16-16 7.163-16 16 7.163 16 16 16zM48 60c-10.667 0-32 5.333-32 16v8h64v-8c0-10.667-21.333-16-32-16z" fill="white"/>
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" style="stop-color:#3B82F6"/>
                          <stop offset="100%" style="stop-color:#8B5CF6"/>
                        </linearGradient>
                      </defs>
                    </svg>
                  `)}`}
                  alt={`${(profileUser as any)?.name}'s profile`}
                  className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                />
              </div>
              
              <div className="text-center space-y-2">
                <h1 className="text-2xl font-bold">{(profileUser as any)?.name}</h1>
                {(profileUser as any)?.bio && (
                  <p className="text-gray-600 text-sm">{(profileUser as any)?.bio}</p>
                )}
                {(profileUser as any)?.location && (
                  <p className="text-gray-500 text-xs">{(profileUser as any)?.location}</p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2 justify-center">
                {hasCompany && (
                  <Button
                    onClick={() => setLocation(`/business/${(userCompanies as any)[0].id}`)}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    Visit Shop
                  </Button>
                )}
                
                <Button
                  onClick={() => setLocation(`/chat?user=${(profileUser as any)?.id}`)}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <MessageCircle className="h-4 w-4" />
                  Message
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Create Post Section - Facebook Style */}
        {isOwnProfile && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <img
                  src={(profileUser as any)?.profileImageUrl || `data:image/svg+xml,${encodeURIComponent(`
                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="20" cy="20" r="20" fill="url(#gradient)"/>
                      <path d="M20 22c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zM20 26c-4.667 0-14 2.333-14 7v3h28v-3c0-4.667-9.333-7-14-7z" fill="white"/>
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" style="stop-color:#3B82F6"/>
                          <stop offset="100%" style="stop-color:#8B5CF6"/>
                        </linearGradient>
                      </defs>
                    </svg>
                  `)}`}
                  alt="Your profile"
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div className="flex-1">
                  <Textarea
                    placeholder="What's on your mind?"
                    value={newPost}
                    onChange={(e) => setNewPost(e.target.value)}
                    className="min-h-[60px] resize-none border-gray-200 rounded-full px-4 py-3 bg-gray-50 hover:bg-gray-100 focus:bg-white"
                  />
                  
                  {selectedMedia && (
                    <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-blue-700 font-medium">
                          📎 {selectedMedia.type.startsWith('video/') ? 'Video' : 'Photo'}: {selectedMedia.name}
                        </span>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setSelectedMedia(null)}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          ✕
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                    <div className="flex gap-4">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={handleImageUpload}
                        className="flex items-center gap-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50"
                      >
                        <ImageIcon className="h-5 w-5" />
                        <span className="font-medium">Photo</span>
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={handleVideoUpload}
                        className="flex items-center gap-2 text-gray-600 hover:text-green-600 hover:bg-green-50"
                      >
                        <Video className="h-5 w-5" />
                        <span className="font-medium">Video</span>
                      </Button>
                    </div>
                    
                    <Button
                      onClick={handleCreatePost}
                      disabled={(!newPost.trim() && !selectedMedia) || createPostMutation.isPending || uploadProcessing}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 font-medium rounded-lg"
                    >
                      {uploadProcessing ? 'Uploading...' : createPostMutation.isPending ? 'Posting...' : 'Post'}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Posts Feed - Facebook Style */}
        {posts && posts.length > 0 ? (
          <div className="space-y-4">
            {posts.map((post: any) => (
              <Card key={post.id} className="w-full">
                <CardContent className="p-4">
                  {/* Post Header */}
                  <div className="flex items-center gap-3 mb-3">
                    <img
                      src={post.user?.profileImageUrl || `data:image/svg+xml,${encodeURIComponent(`
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <circle cx="20" cy="20" r="20" fill="url(#gradient)"/>
                          <path d="M20 22c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zM20 26c-4.667 0-14 2.333-14 7v3h28v-3c0-4.667-9.333-7-14-7z" fill="white"/>
                          <defs>
                            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" style="stop-color:#3B82F6"/>
                              <stop offset="100%" style="stop-color:#8B5CF6"/>
                            </linearGradient>
                          </defs>
                        </svg>
                      `)}`}
                      alt={post.user?.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm">{post.user?.name}</h4>
                      <p className="text-xs text-gray-500">
                        {new Date(post.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {/* Post Content */}
                  <p className="text-gray-800 mb-3">{post.content}</p>
                  
                  {/* Media Display */}
                  {post.mediaUrl && (
                    <div className="mb-3">
                      {post.mediaType === 'video' ? (
                        <video controls className="w-full rounded-lg max-h-96">
                          <source src={post.mediaUrl} type="video/mp4" />
                        </video>
                      ) : (
                        <img src={post.mediaUrl} alt="Post media" className="w-full rounded-lg max-h-96 object-cover" />
                      )}
                    </div>
                  )}

                  {/* Engagement Stats */}
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-3 pt-2 border-t">
                    <span>{post.likes || 0} likes</span>
                    <span>{post.comments || 0} comments • {post.shares || 0} shares</span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-between pt-2 border-t">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex-1 flex items-center justify-center gap-2 hover:bg-gray-100"
                    >
                      <span className="text-lg">👍</span>
                      Like
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex-1 flex items-center justify-center gap-2 hover:bg-gray-100"
                    >
                      <MessageCircle className="h-4 w-4" />
                      Comment
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex-1 flex items-center justify-center gap-2 hover:bg-gray-100"
                    >
                      <Share2 className="h-4 w-4" />
                      Share
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="flex flex-col items-center gap-3">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                  <MessageCircle className="h-8 w-8 text-gray-400" />
                </div>
                <p className="text-gray-500">No posts to display yet</p>
                {isOwnProfile && (
                  <p className="text-sm text-gray-400">Share your first post above!</p>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}