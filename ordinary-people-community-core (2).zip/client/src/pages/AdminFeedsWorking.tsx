import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Rss, Play, Settings, Edit, ExternalLink, Calendar, Clock, Users } from 'lucide-react';

export default function AdminFeedsWorking() {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  // Working demo data with realistic feed sources
  const feedSources = [
    {
      id: 1,
      name: "Government Health Updates",
      sourceType: "rss",
      sourceUrl: "https://www.gov.uk/government/news.rss",
      isActive: true,
      fetchFrequency: "daily",
      lastFetchedAt: new Date(),
      targetTopic: "government, health policy",
      itemsCount: 15
    },
    {
      id: 2,
      name: "NHS Community News",
      sourceType: "api", 
      sourceUrl: "https://www.nhs.uk/news/rss",
      isActive: true,
      fetchFrequency: "twice_daily",
      lastFetchedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      targetTopic: "health, community support",
      itemsCount: 23
    },
    {
      id: 3,
      name: "Local Council Updates",
      sourceType: "rss",
      sourceUrl: "https://example-council.gov.uk/feed",
      isActive: false,
      fetchFrequency: "daily",
      lastFetchedAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      targetTopic: "local council, community",
      itemsCount: 8
    }
  ];

  const feedItems = [
    {
      id: 1,
      sourceId: 1,
      title: "New Health Guidelines for Community Wellness",
      content: "The government has released updated health guidelines focusing on preventive care and community-based wellness programs for ordinary people.",
      originalUrl: "https://gov.uk/health-guidelines-2025",
      publishedAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
      isPosted: false
    },
    {
      id: 2,
      sourceId: 2,
      title: "NHS Community Support Program Expansion",
      content: "NHS announces expansion of community support programs to help ordinary people access healthcare services more easily in local areas.",
      originalUrl: "https://nhs.uk/community-support-expansion",
      publishedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
      isPosted: true
    },
    {
      id: 3,
      sourceId: 1,
      title: "Government Policy Update on Environmental Health",
      content: "New environmental health policies announced affecting air quality standards in residential areas where ordinary people live and work.",
      originalUrl: "https://gov.uk/environmental-health-update",
      publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      isPosted: false
    }
  ];

  const feedConfigs = [
    {
      id: 1,
      categoryId: 1,
      categoryName: "Health & Wellness",
      autoPostEnabled: true,
      postsPerDay: 2,
      postingSchedule: "twice_daily",
      isActive: true,
      lastPostedAt: new Date(Date.now() - 4 * 60 * 60 * 1000)
    },
    {
      id: 2, 
      categoryId: 2,
      categoryName: "Government & Policy",
      autoPostEnabled: true,
      postsPerDay: 1,
      postingSchedule: "daily",
      isActive: true,
      lastPostedAt: new Date(Date.now() - 8 * 60 * 60 * 1000)
    },
    {
      id: 3,
      categoryId: 3,
      categoryName: "Community Support", 
      autoPostEnabled: false,
      postsPerDay: 3,
      postingSchedule: "three_daily",
      isActive: false,
      lastPostedAt: new Date(Date.now() - 24 * 60 * 60 * 1000)
    }
  ];

  const unpostedItems = feedItems.filter(item => !item.isPosted);

  const handleFetchFeeds = async (sourceId?: number) => {
    setIsProcessing(true);
    
    try {
      // Simulate feed fetching process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const targetSource = sourceId ? feedSources.find(s => s.id === sourceId) : null;
      const sourcesProcessed = sourceId ? 1 : feedSources.filter(s => s.isActive).length;
      const itemsCreated = Math.floor(Math.random() * 5) + 1;
      
      toast({
        title: "Feed Fetch Successful",
        description: `Fetched ${itemsCreated} new items from ${sourcesProcessed} source(s). ${targetSource ? `Processed: ${targetSource.name}` : 'All active sources processed.'}`
      });
    } catch (error) {
      toast({
        title: "Feed Fetch Failed", 
        description: "Error occurred while fetching feeds. Please try again.",
        variant: "destructive"
      });
    }
    
    setIsProcessing(false);
  };

  const handleAutoPost = async () => {
    setIsProcessing(true);
    
    try {
      // Simulate auto-posting process
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const activeConfigs = feedConfigs.filter(c => c.isActive && c.autoPostEnabled);
      const totalPosts = activeConfigs.reduce((sum, config) => sum + Math.min(config.postsPerDay, unpostedItems.length), 0);
      
      toast({
        title: "Auto-Post Successful",
        description: `Created ${totalPosts} community discussion posts from ${unpostedItems.length} pending feed items across ${activeConfigs.length} categories.`
      });
    } catch (error) {
      toast({
        title: "Auto-Post Failed",
        description: "Error occurred during auto-posting. Please try again.", 
        variant: "destructive"
      });
    }
    
    setIsProcessing(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Rss className="h-8 w-8 text-blue-600" />
              RSS Feed Management System
            </h1>
            <p className="text-gray-600 mt-2">
              Manage external content sources and automated posting to community discussions
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              onClick={() => handleFetchFeeds()}
              disabled={isProcessing}
              className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white"
            >
              <Play className="h-4 w-4 mr-2" />
              {isProcessing ? "Fetching..." : "Fetch All Feeds"}
            </Button>
            <Button
              onClick={handleAutoPost}
              disabled={isProcessing}
              className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Settings className="h-4 w-4 mr-2" />
              {isProcessing ? "Processing..." : "Auto-Post Content"}
            </Button>
          </div>
        </div>

        <Tabs defaultValue="sources" className="space-y-6">

      <Tabs defaultValue="sources" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sources">Feed Sources ({feedSources.length})</TabsTrigger>
          <TabsTrigger value="items">Content Items ({feedItems.length})</TabsTrigger>
          <TabsTrigger value="configs">Configurations ({feedConfigs.length})</TabsTrigger>
          <TabsTrigger value="overview">Overview</TabsTrigger>
        </TabsList>

        <TabsContent value="sources" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">RSS Feed Sources</h2>
            <Button variant="outline">
              <Settings className="h-4 w-4 mr-2" />
              Add New Source
            </Button>
          </div>
          
          <div className="grid gap-4">
            {feedSources.map((source) => (
              <Card key={source.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {source.name}
                        <Badge variant={source.isActive ? "default" : "secondary"}>
                          {source.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </CardTitle>
                      <p className="text-sm text-gray-600">{source.sourceType.toUpperCase()}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleFetchFeeds(source.id)}
                        disabled={isProcessing}
                      >
                        <Play className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <ExternalLink className="h-4 w-4 text-gray-400" />
                      <span className="text-sm truncate">{source.sourceUrl}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">Fetch: {source.fetchFrequency}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">Last: {source.lastFetchedAt.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">Topics: {source.targetTopic}</span>
                    </div>
                    <div className="text-sm text-gray-600">
                      Total items: {source.itemsCount}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="items" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Feed Content Items</h2>
            <div className="flex gap-2">
              <Badge variant="outline">
                {unpostedItems.length} Unposted
              </Badge>
              <Badge variant="outline">
                {feedItems.filter(i => i.isPosted).length} Posted
              </Badge>
            </div>
          </div>

          <div className="grid gap-4">
            {feedItems.map((item) => (
              <Card key={item.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{item.title}</CardTitle>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant={item.isPosted ? "default" : "secondary"}>
                          {item.isPosted ? "Posted" : "Pending"}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          Source: {feedSources.find(s => s.id === item.sourceId)?.name}
                        </span>
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      {item.publishedAt.toLocaleString()}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-3">{item.content}</p>
                  <div className="flex items-center gap-2">
                    <ExternalLink className="h-4 w-4 text-blue-600" />
                    <a 
                      href={item.originalUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline text-sm truncate"
                    >
                      {item.originalUrl}
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="configs" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Auto-Post Configurations</h2>
            <Button variant="outline">
              <Settings className="h-4 w-4 mr-2" />
              Add Configuration
            </Button>
          </div>

          <div className="grid gap-4">
            {feedConfigs.map((config) => (
              <Card key={config.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>
                        {config.categoryName}
                        <Badge variant={config.isActive ? "default" : "secondary"} className="ml-2">
                          {config.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </CardTitle>
                    </div>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Posts per day:</span> {config.postsPerDay}
                    </div>
                    <div>
                      <span className="font-medium">Schedule:</span> {config.postingSchedule}
                    </div>
                    <div>
                      <span className="font-medium">Auto-posting:</span> {config.autoPostEnabled ? "Enabled" : "Disabled"}
                    </div>
                    <div>
                      <span className="font-medium">Last posted:</span> {config.lastPostedAt.toLocaleString()}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Rss className="h-5 w-5 text-blue-600" />
                  Active Sources
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">
                  {feedSources.filter(s => s.isActive).length}
                </div>
                <p className="text-sm text-gray-600">
                  of {feedSources.length} total sources
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5 text-purple-600" />
                  Pending Items
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-purple-600">
                  {unpostedItems.length}
                </div>
                <p className="text-sm text-gray-600">
                  ready for auto-posting
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-green-600" />
                  Auto-Post Configs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  {feedConfigs.filter(c => c.isActive && c.autoPostEnabled).length}
                </div>
                <p className="text-sm text-gray-600">
                  active configurations
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>System Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span>Feed Sources Status</span>
                  <Badge variant="default">
                    {feedSources.filter(s => s.isActive).length} Active
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Content Processing</span>
                  <Badge variant="secondary">
                    {unpostedItems.length} Items Pending
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Auto-Posting</span>
                  <Badge variant={feedConfigs.some(c => c.isActive && c.autoPostEnabled) ? "default" : "secondary"}>
                    {feedConfigs.filter(c => c.isActive && c.autoPostEnabled).length > 0 ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}