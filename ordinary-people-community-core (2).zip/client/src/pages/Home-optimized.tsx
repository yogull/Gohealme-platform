import { useState, useEffect } from "react";
import { User as FirebaseUser } from "firebase/auth";
import { User } from "@shared/schema";
import { onAuthStateChange, getCurrentAppUser } from "@/lib/auth";
import { LoginForm } from "@/components/LoginForm";
import { useLocation } from "wouter";
import { Leaf, Loader2 } from "lucide-react";

export default function Home() {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [appUser, setAppUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [location] = useLocation();

  useEffect(() => {
    // Clear any demo data from localStorage
    localStorage.removeItem('demoUser');
    
    // Initialize Firebase authentication
    const unsubscribe = onAuthStateChange(async (user) => {
      setFirebaseUser(user);
      
      if (user) {
        try {
          const userData = await getCurrentAppUser(user.uid);
          setAppUser(userData);
        } catch (error) {
          console.error('Failed to get app user:', error);
          setAppUser(null);
        }
      } else {
        setAppUser(null);
      }
      
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading GoHealMe...</p>
        </div>
      </div>
    );
  }

  if (!firebaseUser || !appUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <Leaf className="w-8 h-8 text-green-600 mr-2" />
              <h1 className="text-3xl font-bold text-gray-900">GoHealMe</h1>
            </div>
            <p className="text-gray-600">Your comprehensive health tracking platform</p>
          </div>
          <LoginForm onSuccess={() => window.location.reload()} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Welcome to GoHealMe</h1>
          <p className="text-gray-600 mb-6">Hello, {appUser.name}!</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Supplement Tracking</h3>
              <p className="text-gray-600 text-sm mb-4">Track your daily supplements and vitamins</p>
              <button className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
                View Supplements
              </button>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Health Metrics</h3>
              <p className="text-gray-600 text-sm mb-4">Log your biometric data and health stats</p>
              <button className="w-full bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700">
                View Biometrics
              </button>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Community</h3>
              <p className="text-gray-600 text-sm mb-4">Connect with others on their health journey</p>
              <button className="w-full bg-purple-600 text-white py-2 px-4 rounded hover:bg-purple-700">
                Join Community
              </button>
            </div>
          </div>
          
          <div className="mt-8">
            <button 
              onClick={() => {
                localStorage.removeItem('auth_user');
                window.location.reload();
              }}
              className="text-gray-600 hover:text-gray-700 underline"
            >
              Sign Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}