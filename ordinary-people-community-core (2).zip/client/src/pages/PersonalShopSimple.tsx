import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { BackButton } from "@/components/BackButton";
import { ArrowLeft, Home, Store, Plus, ExternalLink, DollarSign, Loader2 } from "lucide-react";

export default function PersonalShopSimple() {
  const { appUser: user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isCreatingShop, setIsCreatingShop] = useState(false);
  const [shopName, setShopName] = useState("");
  const [shopDescription, setShopDescription] = useState("");

  // Check if user already has a personal shop
  const { data: existingShop, isLoading: checkingExistingShop, error } = useQuery({
    queryKey: [`/api/personal-shops/user/${user?.id}`],
    enabled: !!user?.id,
    retry: false
  });

  // Debug logging
  useEffect(() => {
    console.log('PersonalShop Debug:', {
      userId: user?.id,
      existingShop,
      checkingExistingShop,
      error
    });
  }, [user?.id, existingShop, checkingExistingShop, error]);

  // Redirect to existing shop if found
  useEffect(() => {
    if (existingShop && typeof existingShop === 'object' && 'id' in existingShop && !checkingExistingShop) {
      const shop = existingShop as { id: string };
      console.log('Redirecting to existing shop:', shop.id);
      setLocation(`/personal-shop-view/${shop.id}`);
    }
  }, [existingShop, checkingExistingShop, setLocation]);

  // Show loading while checking for existing shop
  if (checkingExistingShop) {
    return (
      <div className="w-full max-w-sm mx-auto px-2 py-4">
        <div className="flex items-center gap-2 mb-4">
          <BackButton />
        </div>
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span className="ml-2 text-sm">Checking...</span>
        </div>
      </div>
    );
  }

  const handleCreateShop = async () => {
    if (!user?.id) {
      toast({
        title: "Authentication Required",
        description: "Please log in to create your shop",
        variant: "destructive"
      });
      return;
    }

    if (!shopName.trim()) {
      toast({
        title: "Shop Name Required",
        description: "Please enter a name for your shop",
        variant: "destructive"
      });
      return;
    }

    setIsCreatingShop(true);
    
    try {
      const response = await fetch('/api/personal-shops', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          shopName: shopName.trim(),
          description: shopDescription.trim() || "My personal affiliate shop"
        })
      });

      if (response.ok) {
        const newShop = await response.json();
        toast({
          title: "Shop Created Successfully!",
          description: `${shopName} is now ready for affiliate links`,
        });
        setLocation(`/personal-shop-view/${newShop.id}`);
      } else {
        const errorData = await response.json();
        toast({
          title: "Shop Creation Failed",
          description: errorData.error || "Please try again",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Network Error",
        description: "Please check your connection and try again",
        variant: "destructive"
      });
    } finally {
      setIsCreatingShop(false);
    }
  };

  return (
    <div className="w-full max-w-sm mx-auto px-2 py-4">
      {/* Header with Navigation */}
      <div className="flex items-center gap-2 mb-4">
        <BackButton />
        <Button 
          variant="outline" 
          onClick={() => setLocation(`/profile-wall/${user?.id}`)}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Profile
        </Button>
        <Button 
          variant="outline" 
          onClick={() => setLocation('/dashboard')}
          className="flex items-center gap-2"
        >
          <Home className="w-4 h-4" />
          Dashboard
        </Button>
      </div>

      {/* Shop Creation Header */}
      <div className="text-center mb-4">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Store className="w-6 h-6 text-purple-600" />
          <h1 className="text-xl font-bold text-gray-900">Personal Affiliate Shop</h1>
        </div>
        <p className="text-sm text-gray-600">
          Create your own affiliate marketing shop and start earning money from product recommendations
        </p>
      </div>

      {/* Pricing Information */}
      <Card className="mb-4 border-green-200 bg-green-50">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-green-800 text-base">
            <DollarSign className="w-4 h-4" />
            Affiliate Shop Pricing
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <div className="space-y-3">
            <div className="text-center p-3 bg-white rounded-lg border">
              <h3 className="font-semibold text-sm mb-1">First 20 Links</h3>
              <div className="text-xl font-bold text-green-600 mb-1">£1 per link</div>
              <p className="text-xs text-gray-600">One-time payment for each affiliate link</p>
            </div>
            <div className="text-center p-3 bg-white rounded-lg border">
              <h3 className="font-semibold text-sm mb-1">Next 20 Links</h3>
              <div className="text-xl font-bold text-green-600 mb-1">£2/month</div>
              <p className="text-xs text-gray-600">Monthly maintenance for additional links</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Shop Creation Form */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Plus className="w-4 h-4" />
            Create Your Shop
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-2">
          <div>
            <label className="block text-xs font-medium mb-1">Shop Name *</label>
            <Input
              value={shopName}
              onChange={(e) => setShopName(e.target.value)}
              placeholder="e.g., John's Tech Recommendations"
              className="w-full text-sm"
            />
          </div>
          
          <div>
            <label className="block text-xs font-medium mb-1">Shop Description</label>
            <Textarea
              value={shopDescription}
              onChange={(e) => setShopDescription(e.target.value)}
              placeholder="Describe what kinds of products you'll recommend..."
              className="w-full text-sm"
              rows={2}
            />
          </div>

          <Button 
            onClick={handleCreateShop}
            disabled={isCreatingShop || !shopName.trim()}
            className="w-full bg-purple-600 hover:bg-purple-700 text-sm py-2"
          >
            {isCreatingShop ? "Creating..." : "Create My Shop"}
          </Button>
        </CardContent>
      </Card>

      {/* Getting Started Guide */}
      <Card className="mt-4">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Getting Started with Affiliate Marketing</CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <div className="space-y-3">
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="text-xs">1</Badge>
              <div>
                <h3 className="font-semibold text-sm">Create Your Shop</h3>
                <p className="text-xs text-gray-600">Set up your personal affiliate shop with a name and description</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="text-xs">2</Badge>
              <div>
                <h3 className="font-semibold text-sm">Get Affiliate Links</h3>
                <p className="text-xs text-gray-600">Sign up for Amazon Associates, eBay Partner Network, or other affiliate programs</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="text-xs">3</Badge>
              <div>
                <h3 className="font-semibold text-sm">Add Products</h3>
                <p className="text-xs text-gray-600">Add affiliate links to products you recommend (£1 per link for first 20)</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Badge variant="outline" className="text-xs">4</Badge>
              <div>
                <h3 className="font-semibold text-sm">Share & Earn</h3>
                <p className="text-xs text-gray-600">Share your shop link and earn commissions from purchases</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}