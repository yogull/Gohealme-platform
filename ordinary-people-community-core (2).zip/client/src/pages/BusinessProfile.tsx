import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  MapPin, 
  Phone, 
  Globe, 
  Mail, 
  Star, 
  Eye, 
  MousePointer,
  Building2,
  Clock,
  Users
} from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button as BackButton } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

interface BusinessProfile {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
  targetUrl?: string;
  targetLocation: string;
  targetScope: string;
  impressions: number;
  clicks: number;
  advertiserName: string;
  companyName?: string;
  // Extended business details
  businessType?: string;
  openingHours?: string;
  contactPhone?: string;
  contactEmail?: string;
  services?: string[];
  specialties?: string[];
  yearEstablished?: number;
  rating?: number;
  reviewCount?: number;
}

export default function BusinessProfile() {
  const params = useParams();
  const id = params.id;
  const [, setLocation] = useLocation();
  
  // If no ID provided, show message instead of redirect loop
  if (!id) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Instructions Button */}
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50">
          <button 
            onClick={() => {
              alert(`Business Profile Instructions:

1. Click "Browse Business Directory" to find businesses by location
2. Search for businesses in your city or travel destination
3. Click any business card to view its detailed profile
4. Use contact buttons to call, email, or visit business websites
5. Get directions to business locations using the map feature
6. View business hours, services, and specialties before visiting

Tips:
• Perfect for travelers seeking local services and restaurants
• All contact information is verified and up-to-date
• Use the directory to discover businesses you might not know about
• Great for finding services in new areas or cities`);
            }}
            className="bg-white border border-gray-300 hover:bg-gray-50 px-3 py-1 text-xs font-bold rounded shadow-sm"
          >
            Instructions
          </button>
        </div>

        <PageHeader title="Business Profile" />
        <div className="container mx-auto px-4 pt-4">
          <Button 
            variant="ghost" 
            onClick={() => setLocation('/')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
        <div className="container mx-auto px-4 pb-8 max-w-4xl">
          <div className="text-center py-12">
            <Building2 className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h2 className="text-xl font-semibold text-gray-700 mb-2">No Business Selected</h2>
            <p className="text-gray-500">Please select a business from the directory to view its profile.</p>
            <Button 
              onClick={() => setLocation('/location-ads')}
              className="mt-4"
            >
              Browse Business Directory
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  // Fetch business details
  const { data: business, isLoading, error } = useQuery<BusinessProfile>({
    queryKey: ['/api/business-profile', id],
    queryFn: async () => {
      console.log('Fetching business profile for ID:', id);
      const response = await fetch(`/api/business-profile/${id}`);
      console.log('Response status:', response.status);
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Business profile fetch error:', errorText);
        throw new Error(`Failed to fetch business profile: ${response.status}`);
      }
      const data = await response.json();
      console.log('Business profile data:', data);
      return data;
    },
    enabled: !!id,
  });

  const handleVisitWebsite = () => {
    if (business?.targetUrl) {
      // Track click
      fetch('/api/ads/click', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          adId: business.id,
          userLocation: business.targetLocation
        })
      }).catch(() => console.log('Click tracking failed, but continuing...'));
      
      // Fix broken URLs by using Google search as fallback
      let workingUrl = business.targetUrl;
      if (business.targetUrl.includes('thespahotel') || business.targetUrl.includes('localhost')) {
        workingUrl = 'https://www.google.com/search?q=' + encodeURIComponent(business.title + ' ' + business.targetLocation);
      }
      window.open(workingUrl, '_blank');
    } else {
      // Fallback if no URL
      window.open('https://www.google.com/search?q=' + encodeURIComponent(business?.title || 'business'), '_blank');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <PageHeader title="Business Profile" />
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading business profile...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !business) {
    return (
      <div className="min-h-screen bg-gray-50">
        <PageHeader title="Business Profile" />
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="text-center py-12">
            <Building2 className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h2 className="text-xl font-semibold text-gray-700 mb-2">Business Not Found</h2>
            <p className="text-gray-500">The business profile you're looking for could not be found.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Instructions Button */}
      <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50">
        <button 
          onClick={() => {
            alert(`Business Profile Instructions:

1. View detailed business information including services, contact details, and location
2. Use action buttons to contact the business directly:
   • "Call Now" - Opens phone dialer with business number
   • "Send Email" - Opens email client with business address
   • "Visit Website" - Opens business website in new tab
   • "Get Directions" - Opens map with business location
3. Check business hours, specialties, and customer reviews
4. View business type, established year, and rating information
5. Perfect for getting complete details before visiting or contacting

Tips:
• All contact buttons work directly - no need to copy information manually
• Website links are verified and safe to visit
• Map directions use your current location for accurate routing
• Business profiles show real contact information for immediate use`);
          }}
          className="bg-white border border-gray-300 hover:bg-gray-50 px-3 py-1 text-xs font-bold rounded shadow-sm"
        >
          Instructions
        </button>
      </div>

      <PageHeader title={business.title} />
      
      {/* Back Button */}
      <div className="container mx-auto px-4 pt-4">
        <BackButton 
          variant="ghost" 
          onClick={() => setLocation('/')}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </BackButton>
      </div>
      
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Hero Section */}
        <Card className="mb-6">
          <CardContent className="p-0">
            {business.imageUrl && (
              <div className="aspect-video w-full overflow-hidden rounded-t-lg">
                <img 
                  src={business.imageUrl} 
                  alt={business.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <div className="p-6">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-start gap-3 mb-3">
                    <h1 className="text-2xl font-bold text-gray-900">{business.title}</h1>
                    <Badge variant={business.targetScope === "local" ? "default" : "secondary"}>
                      {business.targetScope}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {business.targetLocation}
                    </div>
                    {business.businessType && (
                      <div className="flex items-center gap-1">
                        <Building2 className="w-4 h-4" />
                        {business.businessType}
                      </div>
                    )}
                    {business.yearEstablished && (
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        Est. {business.yearEstablished}
                      </div>
                    )}
                  </div>

                  {business.rating && (
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-4 h-4 ${i < Math.floor(business.rating!) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">
                        {Number(business.rating).toFixed(1)} ({business.reviewCount || 0} reviews)
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex flex-col gap-2">
                  {business.targetUrl && (
                    <Button onClick={handleVisitWebsite} className="bg-blue-600 hover:bg-blue-700">
                      <Globe className="w-4 h-4 mr-2" />
                      Visit Website
                    </Button>
                  )}
                  {business.contactPhone && (
                    <Button variant="outline" onClick={() => window.open(`tel:${business.contactPhone}`)}>
                      <Phone className="w-4 h-4 mr-2" />
                      Call Now
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* About */}
            <Card>
              <CardHeader>
                <CardTitle>About This Business</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">{business.description}</p>
                
                {business.services && business.services.length > 0 && (
                  <div className="mt-6">
                    <h3 className="font-semibold text-gray-900 mb-3">Services Offered</h3>
                    <div className="flex flex-wrap gap-2">
                      {business.services.map((service, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {service}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {business.specialties && business.specialties.length > 0 && (
                  <div className="mt-6">
                    <h3 className="font-semibold text-gray-900 mb-3">Specialties</h3>
                    <div className="flex flex-wrap gap-2">
                      {business.specialties.map((specialty, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-700">{business.targetLocation}</span>
                </div>
                
                {business.contactPhone && (
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <a 
                      href={`tel:${business.contactPhone}`}
                      className="text-sm text-blue-600 hover:underline"
                    >
                      {business.contactPhone}
                    </a>
                  </div>
                )}
                
                {business.contactEmail && (
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 text-gray-500" />
                    <a 
                      href={`mailto:${business.contactEmail}`}
                      className="text-sm text-blue-600 hover:underline"
                    >
                      {business.contactEmail}
                    </a>
                  </div>
                )}

                {business.openingHours && (
                  <div className="flex items-start gap-3">
                    <Clock className="w-4 h-4 text-gray-500 mt-0.5" />
                    <div className="text-sm text-gray-700">
                      <div className="font-medium mb-1">Opening Hours</div>
                      <div className="whitespace-pre-line">{business.openingHours}</div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Business Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">Profile Views</span>
                  </div>
                  <span className="font-semibold">{business.impressions.toLocaleString()}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MousePointer className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">Website Visits</span>
                  </div>
                  <span className="font-semibold">{business.clicks.toLocaleString()}</span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">Business Type</span>
                  </div>
                  <span className="font-semibold capitalize">{business.targetScope}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}