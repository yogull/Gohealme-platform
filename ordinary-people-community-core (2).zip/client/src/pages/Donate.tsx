import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Heart, ArrowLeft, Mail, User } from "lucide-react";
import { useLocation } from "wouter";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePublicKey = import.meta.env.VITE_STRIPE_PUBLIC_KEY;
const stripePromise = stripePublicKey ? loadStripe(stripePublicKey) : null;

const DonateForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/donate-success`,
        },
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Thank You!",
          description: "Your donation helps keep GoHealMe running for everyone!",
        });
        // Redirect will happen automatically via confirmParams
      }
    } catch (error) {
      toast({
        title: "Payment Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <div className="flex gap-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={() => setLocation("/")}
          className="flex-1"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>
        <Button 
          type="submit" 
          disabled={!stripe || isProcessing}
          className="flex-1 bg-gradient-to-r from-pink-500 to-purple-500 hover:opacity-90"
        >
          {isProcessing ? "Processing..." : "Donate £1"}
        </Button>
      </div>
    </form>
  );
};

export default function Donate() {
  const [clientSecret, setClientSecret] = useState("");
  const [showPayment, setShowPayment] = useState(false);
  const [donorInfo, setDonorInfo] = useState({
    email: "",
    name: ""
  });
  const [, setLocation] = useLocation();

  const handleInfoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!donorInfo.email.trim()) {
      return;
    }

    try {
      const response = await apiRequest("POST", "/api/create-payment-intent", { 
        amount: 1,
        donorEmail: donorInfo.email,
        donorName: donorInfo.name || undefined
      });
      const data = await response.json();
      
      if (data.clientSecret) {
        setClientSecret(data.clientSecret);
        setShowPayment(true);
      } else {
        throw new Error("No client secret received");
      }
    } catch (error) {
      console.error("Payment setup error:", error);
      setLocation("/");
    }
  };

  if (!showPayment) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-gray-800">
              Support GoHealMe
            </CardTitle>
            <CardDescription className="text-gray-600">
              Your donation helps us build a better health community for everyone
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleInfoSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email Address *
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={donorInfo.email}
                  onChange={(e) => setDonorInfo(prev => ({ ...prev, email: e.target.value }))}
                  required
                  className="w-full"
                />
                <p className="text-sm text-gray-500">We'll send you a thank you email</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="name" className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Name (Optional)
                </Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Your name"
                  value={donorInfo.name}
                  onChange={(e) => setDonorInfo(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full"
                />
              </div>

              <div className="bg-gradient-to-r from-pink-100 to-purple-100 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-lg font-semibold text-gray-800">Donation Amount:</span>
                  <span className="text-2xl font-bold text-purple-600">£1.00</span>
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  Your support makes a real difference
                </p>
              </div>

              <div className="flex gap-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setLocation("/")}
                  className="flex-1"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button 
                  type="submit" 
                  disabled={!donorInfo.email.trim()}
                  className="flex-1 bg-gradient-to-r from-pink-500 to-purple-500 hover:opacity-90"
                >
                  Continue to Payment
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center py-8">
            <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center mb-4">
              <Heart className="w-8 h-8 text-white animate-pulse" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Setting up donation...</h2>
            <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full"></div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 p-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Support GoHealMe</h1>
          <p className="text-lg text-gray-700">Help keep our health/wellness community platform running for everyone</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">Donate £1</CardTitle>
            <CardDescription className="text-center">
              Your contribution helps maintain GoHealMe as a free platform for our health community.
              Donations are completely optional but greatly appreciated.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <DonateForm />
            </Elements>
          </CardContent>
        </Card>

        <div className="text-center mt-6 text-sm text-gray-600">
          <p>🔒 Secure payment processing by Stripe</p>
          <p className="mt-2">GoHealMe - The People's Health/Wellness Community</p>
        </div>
      </div>
    </div>
  );
}