import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useTutorial } from "@/hooks/useTutorial";
import { PageHeader } from "@/components/PageHeader";
import { TutorialPopup } from "@/components/TutorialPopup";
import { SocialMediaLinks } from "@/components/SocialMediaLinks";
import { useLocation } from "wouter";
import { Search, UserPlus, Users, MessageCircle, Check, X, Share2, Globe, Camera, Video } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { User, UserConnection } from "@shared/schema";
import { UniversalInstructionsButton } from "@/components/UniversalInstructionsButton";

export default function Social() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { appUser, loading } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [location] = useLocation();
  const { shouldShowTutorial, getTutorialSteps, markTutorialComplete } = useTutorial();

  const { data: connections = [] } = useQuery<UserConnection[]>({
    queryKey: ["/api/users/connections"],
    enabled: !!appUser,
  });

  const { data: pendingConnections = [] } = useQuery<UserConnection[]>({
    queryKey: ["/api/users/connections/pending"],
    enabled: !!appUser,
  });

  const searchMutation = useMutation({
    mutationFn: async (query: string) => {
      if (!query.trim()) {
        setSearchResults([]);
        return [];
      }
      try {
        const response = await apiRequest("GET", `/api/users/search?q=${encodeURIComponent(query)}`);
        if (!response.ok) {
          throw new Error('Search failed');
        }
        const users = await response.json();
        const filteredUsers = users.filter((user: User) => user.id !== appUser?.id);
        setSearchResults(filteredUsers);
        return filteredUsers;
      } catch (error) {
        console.error('Search error:', error);
        setSearchResults([]);
        toast({
          title: "Search Error",
          description: "Failed to search for users. Please try again.",
          variant: "destructive",
        });
        return [];
      }
    },
  });

  const connectMutation = useMutation({
    mutationFn: async (userId: number) => {
      try {
        const response = await apiRequest("POST", "/api/users/connect", { userId });
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Connection failed');
        }
        return response.json();
      } catch (error: any) {
        console.error('Connection error:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users/connections/pending"] });
      toast({
        title: "Connection request sent",
        description: "Your connection request has been sent successfully.",
      });
      // Keep search results visible so user can connect with multiple people
      // setSearchResults([]);
      // setSearchQuery("");
    },
    onError: (error: any) => {
      console.error('Connect mutation error:', error);
      toast({
        title: "Connection failed",
        description: error.message || "Failed to send connection request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleConnectionMutation = useMutation({
    mutationFn: async ({ connectionId, action }: { connectionId: number; action: "accept" | "reject" }) => {
      return apiRequest("POST", `/api/users/connections/${connectionId}/${action}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users/connections/pending"] });
      toast({
        title: "Connection updated",
        description: "Connection request has been updated.",
      });
    },
  });

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      toast({
        title: "Search Required",
        description: "Please enter a name or email to search for users.",
        variant: "destructive",
      });
      return;
    }
    searchMutation.mutate(searchQuery);
  };

  const handleConnect = (userId: number) => {
    connectMutation.mutate(userId);
  };

  const handleAcceptConnection = (connectionId: number) => {
    handleConnectionMutation.mutate({ connectionId, action: "accept" });
  };

  const handleRejectConnection = (connectionId: number) => {
    handleConnectionMutation.mutate({ connectionId, action: "reject" });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-muted-foreground">Loading your social network...</p>
        </div>
      </div>
    );
  }

  if (!appUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-bold text-muted-foreground">Authentication Required</h2>
          <p className="text-muted-foreground">Please log in to access your social network.</p>
          <a href="/login" className="text-primary hover:text-primary/80">
            Go to login page
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Instructions Button */}
      <UniversalInstructionsButton currentPage="social" position="top" />
      
      <PageHeader 
        title="Social Hub" 
        subtitle="Your complete social networking center - connect, share, and engage with the Ordinary People Community"
      />

      <Tabs defaultValue="connections" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="connections" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Connections
          </TabsTrigger>
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <Camera className="w-4 h-4" />
            My Profile
          </TabsTrigger>
          <TabsTrigger value="social-media" className="flex items-center gap-2">
            <Share2 className="w-4 h-4" />
            Social Media
          </TabsTrigger>
          <TabsTrigger value="discover" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            Discover
          </TabsTrigger>
        </TabsList>

        {/* Connections Tab */}
        <TabsContent value="connections" className="space-y-6">
          {/* Search Users */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                Find New Connections
              </CardTitle>
              <CardDescription>
                Search for other users by name or email to connect with them
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSearch} className="flex gap-2">
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by name or email..."
                  className="flex-1"
                />
                <Button type="submit" disabled={searchMutation.isPending}>
                  {searchMutation.isPending ? "Searching..." : "Search"}
                </Button>
              </form>

              {/* Show loading state */}
              {searchMutation.isPending && (
                <div className="mt-4 p-4 text-center">
                  <div className="animate-spin w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full mx-auto mb-2"></div>
                  <p className="text-sm text-gray-600">Searching for users...</p>
                </div>
              )}

              {/* Show search results */}
              {searchResults.length > 0 && !searchMutation.isPending && (
                <div className="mt-4 space-y-3">
                  <h4 className="font-medium">Search Results ({searchResults.length} found)</h4>
                  {searchResults.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg bg-white hover:bg-gray-50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-medium">
                          {user.name?.charAt(0).toUpperCase() || 'U'}
                        </div>
                        <div>
                          <h5 className="font-medium text-gray-900">{user.name}</h5>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          {user.bio && (
                            <p className="text-xs text-gray-500 mt-1">{user.bio}</p>
                          )}
                        </div>
                      </div>
                      <Button
                        onClick={() => handleConnect(user.id)}
                        disabled={connectMutation.isPending}
                        size="sm"
                        className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
                      >
                        <UserPlus className="w-4 h-4" />
                        {connectMutation.isPending ? "Connecting..." : "Connect"}
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              {/* Show no results message */}
              {searchQuery && searchResults.length === 0 && !searchMutation.isPending && (
                <div className="mt-4 p-4 text-center text-gray-500">
                  <p>No users found for "{searchQuery}"</p>
                  <p className="text-sm mt-1">Try searching by name or email address</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Pending Connection Requests */}
          {pendingConnections.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Pending Requests
                  <Badge variant="secondary">{pendingConnections.length}</Badge>
                </CardTitle>
                <CardDescription>
                  People who want to connect with you
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {pendingConnections.map((connection) => (
                    <div key={connection.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <h5 className="font-medium">Connection Request</h5>
                        <p className="text-sm text-muted-foreground">
                          Received {new Date(connection.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleAcceptConnection(connection.id)}
                          disabled={handleConnectionMutation.isPending}
                          size="sm"
                          className="flex items-center gap-2"
                        >
                          <Check className="w-4 h-4" />
                          Accept
                        </Button>
                        <Button
                          onClick={() => handleRejectConnection(connection.id)}
                          disabled={handleConnectionMutation.isPending}
                          variant="outline"
                          size="sm"
                          className="flex items-center gap-2"
                        >
                          <X className="w-4 h-4" />
                          Decline
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Your Connections */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Your Connections
                <Badge variant="secondary">{connections.length}</Badge>
              </CardTitle>
              <CardDescription>
                People you're connected with in the community
              </CardDescription>
            </CardHeader>
            <CardContent>
              {connections.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No connections yet</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Use the search above to find and connect with other users
                  </p>
                </div>
              ) : (
                <div className="grid gap-3">
                  {connections.map((connection) => (
                    <div key={connection.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <h5 className="font-medium">Connected User</h5>
                        <p className="text-sm text-muted-foreground">
                          Connected since {new Date(connection.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Connected
                        </Badge>
                        <Button variant="outline" size="sm">
                          Message
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* My Profile Tab */}
        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="w-5 h-5" />
                Profile Wall Access
              </CardTitle>
              <CardDescription>
                Access your complete profile and social features
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button 
                  onClick={() => window.location.href = `/profile-wall/${appUser?.id}`}
                  className="w-full"
                  size="lg"
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Go to My Profile Wall
                </Button>
                <p className="text-sm text-muted-foreground text-center">
                  Visit your profile wall to post updates, share photos/videos, and manage your social presence
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Video className="w-5 h-5" />
                Quick Actions
              </CardTitle>
              <CardDescription>
                Direct access to key social features
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button variant="outline" className="flex items-center gap-2">
                  <Camera className="w-4 h-4" />
                  Upload Photo
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <Video className="w-4 h-4" />
                  Upload Video
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <Share2 className="w-4 h-4" />
                  Share All
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4" />
                  Start Chat
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Social Media Tab */}
        <TabsContent value="social-media" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Share2 className="w-5 h-5" />
                Social Media Integration
              </CardTitle>
              <CardDescription>
                Connect your external social media accounts and use "Share All" functionality
              </CardDescription>
            </CardHeader>
            <CardContent>
              <SocialMediaLinks 
                userId={appUser?.id || 0}
                isOwnProfile={true}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Discover Tab */}
        <TabsContent value="discover" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Community Impact
              </CardTitle>
              <CardDescription>
                Your contribution to the Ordinary People Community
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{connections.length}</div>
                  <div className="text-sm text-muted-foreground">Connections</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">0</div>
                  <div className="text-sm text-muted-foreground">Posts Shared</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">0</div>
                  <div className="text-sm text-muted-foreground">Likes Received</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">0</div>
                  <div className="text-sm text-muted-foreground">Comments Made</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Community Features</CardTitle>
              <CardDescription>
                Explore more social features across the platform
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button 
                  variant="outline" 
                  className="h-auto p-4 flex flex-col items-start space-y-2"
                  onClick={() => window.location.href = "/community"}
                >
                  <div className="flex items-center gap-2">
                    <MessageCircle className="w-4 h-4" />
                    <span className="font-medium">Community Discussions</span>
                  </div>
                  <span className="text-sm text-muted-foreground text-left">
                    Join open discussions on government, health, and personal views across 20+ categories
                  </span>
                </Button>
                
                <Button 
                  variant="outline" 
                  className="h-auto p-4 flex flex-col items-start space-y-2"
                  onClick={() => window.location.href = "/blog"}
                >
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <span className="font-medium">Blog Platform</span>
                  </div>
                  <span className="text-sm text-muted-foreground text-left">
                    Share your views and experiences with the community
                  </span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Tutorial popup for first-time visitors */}
      {shouldShowTutorial(location) && (
        <TutorialPopup
          page={location}
          steps={getTutorialSteps(location)}
          onComplete={() => markTutorialComplete(location)}
          onSkip={() => markTutorialComplete(location)}
        />
      )}
    </div>
  );
}