import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Link href="/dashboard">
            <Button variant="outline" className="mb-4">← Back to Dashboard</Button>
          </Link>
          <h1 className="text-3xl font-bold text-center mb-2">Terms and Conditions</h1>
          <p className="text-center text-gray-600">Ordinary People Community Platform</p>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-red-600">Community Standards</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <h3 className="font-semibold text-lg">Prohibited Content</h3>
              <p>The following types of content are strictly prohibited on our platform:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Hate Speech:</strong> Content that attacks or demeans individuals or groups based on race, religion, gender, sexual orientation, nationality, disability, or other protected characteristics</li>
                <li><strong>Harassment and Bullying:</strong> Targeted harassment, threats, or intimidation of other users</li>
                <li><strong>Violent Content:</strong> Content that promotes, glorifies, or incites violence against individuals or groups</li>
                <li><strong>Discriminatory Language:</strong> Slurs, derogatory terms, or language intended to marginalize or dehumanize others</li>
                <li><strong>Extremist Content:</strong> Content promoting terrorist organizations, white supremacy, or other extremist ideologies</li>
                <li><strong>Personal Attacks:</strong> Direct attacks on other community members' character, appearance, or personal circumstances</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-blue-600">Acceptable Language Policy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <h3 className="font-semibold text-lg">Language Guidelines</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-green-600 mb-2">Acceptable:</h4>
                  <ul className="list-disc pl-6 space-y-1 text-sm">
                    <li>General mild profanity (damn, hell, crap, etc.)</li>
                    <li>Passionate expression about issues</li>
                    <li>Strong opinions when respectfully stated</li>
                    <li>Cultural or regional expressions</li>
                    <li>Academic or medical terminology</li>
                    <li>Quoted material with context</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-red-600 mb-2">Not Acceptable:</h4>
                  <ul className="list-disc pl-6 space-y-1 text-sm">
                    <li>Racial, ethnic, or religious slurs</li>
                    <li>Homophobic or transphobic language</li>
                    <li>Sexist or misogynistic terms</li>
                    <li>Ableist language targeting disabilities</li>
                    <li>Threats or violent language</li>
                    <li>Sexual harassment or explicit content</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-purple-600">Automatic Content Filtering</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <h3 className="font-semibold text-lg">How Our System Works</h3>
              <p>Our platform uses advanced content filtering to maintain community standards:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Real-time Scanning:</strong> All posts are automatically scanned before publication</li>
                <li><strong>Intelligent Detection:</strong> Context-aware filtering that understands intent and usage</li>
                <li><strong>Graduated Response:</strong> Warning messages for borderline content, blocking for severe violations</li>
                <li><strong>Human Review:</strong> Complex cases are reviewed by community moderators</li>
                <li><strong>Appeals Process:</strong> Users can appeal automated decisions through our support system</li>
              </ul>
              
              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200 mt-4">
                <h4 className="font-semibold text-yellow-800 mb-2">What Happens When Content is Filtered?</h4>
                <ul className="list-disc pl-6 space-y-1 text-sm text-yellow-700">
                  <li>Mild violations: Warning message with option to edit</li>
                  <li>Moderate violations: Post blocked with explanation</li>
                  <li>Severe violations: Account review and potential suspension</li>
                  <li>Repeat violations: Progressive penalties up to permanent ban</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-gray-600">User Responsibilities</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <h3 className="font-semibold text-lg">Community Member Obligations</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>Treat all community members with respect and dignity</li>
                <li>Engage in constructive dialogue, even when disagreeing</li>
                <li>Report content that violates community standards</li>
                <li>Respect the privacy and personal information of others</li>
                <li>Use the platform for its intended purpose of community discussion</li>
                <li>Accept responsibility for all content posted under your account</li>
              </ul>

              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mt-4">
                <h4 className="font-semibold text-blue-800 mb-2">Reporting Violations</h4>
                <p className="text-sm text-blue-700">
                  If you encounter content that violates our community standards, please use the report button 
                  or contact our moderation team. All reports are reviewed promptly and confidentially.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-gray-600">Enforcement and Appeals</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <h3 className="font-semibold text-lg">Progressive Enforcement</h3>
              <div className="space-y-3">
                <div className="border-l-4 border-yellow-400 pl-4">
                  <h4 className="font-semibold">First Violation: Warning</h4>
                  <p className="text-sm text-gray-600">Educational message about community standards</p>
                </div>
                <div className="border-l-4 border-orange-400 pl-4">
                  <h4 className="font-semibold">Second Violation: Temporary Restriction</h4>
                  <p className="text-sm text-gray-600">24-48 hour posting restriction with required acknowledgment</p>
                </div>
                <div className="border-l-4 border-red-400 pl-4">
                  <h4 className="font-semibold">Repeated Violations: Account Suspension</h4>
                  <p className="text-sm text-gray-600">7-30 day suspension with mandatory community standards review</p>
                </div>
                <div className="border-l-4 border-red-600 pl-4">
                  <h4 className="font-semibold">Severe/Persistent Violations: Permanent Ban</h4>
                  <p className="text-sm text-gray-600">Permanent removal from platform with appeal rights</p>
                </div>
              </div>

              <h3 className="font-semibold text-lg mt-6">Appeals Process</h3>
              <p>Users may appeal moderation decisions within 30 days. Appeals should include:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Explanation of why the content should be allowed</li>
                <li>Context that may have been missed by automated systems</li>
                <li>Commitment to follow community standards</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-gray-600">Contact Information</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">For questions about our community standards or to report violations:</p>
              <div className="space-y-2">
                <p><strong>Email:</strong> moderation@ordinarypeoplecommunity.com</p>
                <p><strong>Appeals:</strong> appeals@ordinarypeoplecommunity.com</p>
                <p><strong>General Support:</strong> support@ordinarypeoplecommunity.com</p>
              </div>
              
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">
                  By using the Ordinary People Community platform, you agree to abide by these terms and conditions. 
                  These terms may be updated periodically, and continued use of the platform constitutes acceptance 
                  of any changes.
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  Last updated: {new Date().toLocaleDateString()}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}