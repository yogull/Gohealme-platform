import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Footer } from "@/components/Footer";
import { BackButton } from "@/components/BackButton";
import { useAuth } from "@/hooks/useAuth";
import { 
  ArrowLeft, 
  ExternalLink, 
  Star, 
  Heart, 
  MessageCircle, 
  Share2,
  Store,
  User,
  Calendar,
  Tag,
  Package,
  Plus,
  Home
} from "lucide-react";

export default function PersonalShopView() {
  const { shopId } = useParams();
  const { appUser } = useAuth();

  // Fetch personal shop details
  const { data: shop, isLoading } = useQuery({
    queryKey: [`/api/personal-shops/${shopId}`],
    enabled: !!shopId,
  });

  // Fetch affiliate links for this shop
  const { data: affiliateLinks } = useQuery({
    queryKey: [`/api/personal-shops/${shopId}/affiliate-links`],
    enabled: !!shopId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!shop) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="text-center p-6">
            <Store className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-semibold mb-2">Shop Not Found</h2>
            <p className="text-gray-600 mb-4">The personal shop you're looking for doesn't exist or has been removed.</p>
            <Link href="/personal-shop-search">
              <Button>Browse All Shops</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header with Navigation */}
        <div className="flex items-center gap-4 mb-6">
          <BackButton />
          <Link href="/">
            <Button variant="outline" className="flex items-center gap-2">
              <Home className="w-4 h-4" />
              Dashboard
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-gray-800">Personal Shop</h1>
        </div>

        {/* Shop Header */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex flex-col sm:flex-row items-start gap-4">
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={shop.user?.profilePicture} />
                  <AvatarFallback>
                    <User className="w-8 h-8" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-2xl text-purple-800">{shop.shopName}</CardTitle>
                  <p className="text-gray-600 flex items-center gap-2 mt-1">
                    <User className="w-4 h-4" />
                    {shop.user?.name || shop.user?.email}
                  </p>
                  <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      Created {new Date(shop.createdAt).toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Package className="w-4 h-4" />
                      {shop.totalAffiliateLinks} Products
                    </span>
                  </div>
                </div>
              </div>
              <div className="ml-auto">
                <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                  <Store className="w-3 h-3 mr-1" />
                  Personal Shop
                </Badge>
              </div>
            </div>
            {shop.description && (
              <p className="text-gray-700 mt-4">{shop.description}</p>
            )}
          </CardHeader>
        </Card>

        {/* Affiliate Products */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {affiliateLinks?.map((link: any) => (
            <Card key={link.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="outline" className="text-xs">
                    <Tag className="w-3 h-3 mr-1" />
                    {link.category}
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {link.brand}
                  </Badge>
                </div>
                {link.productImageUrl && (
                  <div className="w-full h-48 bg-gray-100 rounded-lg overflow-hidden mb-3">
                    <img 
                      src={link.productImageUrl} 
                      alt={link.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <CardTitle className="text-lg line-clamp-2">{link.title}</CardTitle>
                {link.description && (
                  <p className="text-gray-600 text-sm line-clamp-3">{link.description}</p>
                )}
                {link.price && (
                  <p className="text-lg font-bold text-green-600 mt-2">{link.price}</p>
                )}
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      {link.likes}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4" />
                      {link.comments}
                    </span>
                    <span className="flex items-center gap-1">
                      <Share2 className="w-4 h-4" />
                      {link.shares}
                    </span>
                  </div>
                </div>
                <Button 
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  onClick={() => window.open(link.affiliateUrl, '_blank')}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  View Product
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State with Add Product Button */}
        {affiliateLinks?.length === 0 && (
          <Card className="text-center p-8">
            <Package className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Products Yet</h3>
            <p className="text-gray-600 mb-6">Ready to start making money? Add your first affiliate product!</p>
            <div className="space-y-4">
              <Button 
                className="bg-green-600 hover:bg-green-700 text-white font-bold px-8 py-3"
                onClick={() => window.location.href = `/personal-shop-manage/${shop?.id}`}
              >
                <Plus className="w-5 h-5 mr-2" />
                Add Your First Product
              </Button>
              <div className="text-sm text-gray-500">
                <p>💡 <strong>How it works:</strong></p>
                <p>1. Get affiliate links from Amazon, eBay, or any store</p>
                <p>2. Add products here with your affiliate links</p>
                <p>3. Share to your Profile Wall and earn commissions!</p>
              </div>
            </div>
          </Card>
        )}
        
        {/* Add Product Button for shops with existing products */}
        {affiliateLinks && affiliateLinks.length > 0 && (
          <Card className="text-center p-6 border-dashed border-2 border-purple-300">
            <Button 
              className="bg-purple-600 hover:bg-purple-700 text-white font-bold px-6 py-2"
              onClick={() => window.location.href = `/personal-shop-manage/${shop?.id}`}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add More Products
            </Button>
          </Card>
        )}
      </div>
      <Footer />
    </div>
  );
}