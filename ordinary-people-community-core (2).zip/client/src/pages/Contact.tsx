import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SEO } from "@/components/SEO";
import { Mail, Phone, MapPin, Send, Loader2, MessageCircle, MessageSquare, HelpCircle, Users, Clock, Shield, Heart, ArrowLeft } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { AdCarousel } from "@/components/AdCarousel";
import { PageHelpSystem } from "@/components/PageHelpSystem";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import stressImage from "@assets/brain pic_1750108425244.jfif";
import { UniversalInstructionsButton } from "@/components/UniversalInstructionsButton";

const contactSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  subject: z.string().min(5, "Subject must be at least 5 characters"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type ContactFormData = z.infer<typeof contactSchema>;

export default function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  const handleSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    try {
      const response = await apiRequest("POST", "/api/contact", data);
      
      if (response.ok) {
        toast({
          title: "Message sent successfully!",
          description: "We'll get back to you as soon as possible.",
        });
        form.reset();
      } else {
        throw new Error("Failed to send message");
      }
    } catch (error) {
      toast({
        title: "Failed to send message",
        description: "Please try again or contact us directly at ordinarypeoplecommunity.com@gmail.com",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 mobile-safe w-full max-w-[65vw] mx-auto overflow-x-hidden">
      {/* Page Help System */}
      <PageHelpSystem currentPage="contact" />
      
      <SEO 
        title="Contact GoHealMe - Get Support & Help"
        description="Contact GoHealMe for support with your health tracking journey. Get help with supplements, biometrics, AI health guidance, or community features. We're here to support your wellness goals."
        keywords={[
          'contact gohealme', 'gohealme support', 'health platform help',
          'supplement tracking support', 'wellness community contact',
          'health tracking help', 'ai health assistant support',
          'gohealme customer service', 'health platform assistance'
        ]}
        type="website"
        url="https://gohealme.org/contact"
      />
      
      {/* Hero Section with Stress Image */}
      <div className="relative bg-gradient-to-br from-primary/20 to-primary/5 py-16">
        <div className="max-w-4xl mx-auto px-6">
          {/* Return Button */}
          <div className="mb-6">
            <Link href="/" className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              <ArrowLeft className="w-4 h-4" />
              Back to Dashboard
            </Link>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                We're Here to Help
              </h1>
              <p className="text-lg text-gray-700 mb-6">
                Need help or have questions? The best place to get answers is in our community discussions. 
                Join conversations about daily life, government issues, and connect with ordinary people sharing their experiences.
              </p>
              <p className="text-primary font-medium">
                Visit our discussions - every voice matters, every opinion is welcome.
              </p>
            </div>
            <div className="flex justify-center">
              <img 
                src={stressImage} 
                alt="Person experiencing stress - you're not alone" 
                className="rounded-lg shadow-lg max-w-sm w-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Quick Help Options */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <h2 className="text-2xl font-bold text-center mb-8">Find Your Community</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center p-6 hover:shadow-lg transition-shadow border-l-4 border-blue-500">
            <MessageCircle className="w-12 h-12 mx-auto mb-4 text-blue-600" />
            <h3 className="font-semibold mb-2 text-lg">Community Discussions</h3>
            <p className="text-gray-600 mb-4">Join conversations about daily life, government issues, and share your experiences</p>
            <Link href="/community">
              <Button variant="outline" size="sm">Join Discussions</Button>
            </Link>
          </Card>
          <Card className="text-center p-6 hover:shadow-lg transition-shadow border-l-4 border-green-500">
            <HelpCircle className="w-12 h-12 mx-auto mb-4 text-green-600" />
            <h3 className="font-semibold mb-2 text-lg">AI Assistant</h3>
            <p className="text-gray-600 mb-4">Get instant answers to any questions about life, science, or current events</p>
            <Button variant="outline" size="sm">Ask AI</Button>
          </Card>
          <Card className="text-center p-6 hover:shadow-lg transition-shadow border-l-4 border-purple-500">
            <Users className="w-12 h-12 mx-auto mb-4 text-purple-600" />
            <h3 className="font-semibold mb-2 text-lg">Multi-Platform Communication</h3>
            <p className="text-gray-600 mb-4">Use WhatsApp Call/Video, Messenger Call/Video, or chat to connect with ordinary people</p>
            <Link href="/chat">
              <Button variant="outline" size="sm">Start Communication</Button>
            </Link>
          </Card>
        </div>

        {/* FAQ Section */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <HelpCircle className="w-6 h-6 text-blue-600" />
              Frequently Asked Questions
            </CardTitle>
            <CardDescription>Quick answers to common questions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="border-l-4 border-blue-500 pl-4 py-2">
              <h4 className="font-semibold text-lg mb-2">How do I join community discussions?</h4>
              <p className="text-gray-600">Navigate to the Community page and select a discussion category that interests you. You can join existing conversations about government issues, daily life topics, or start new discussions to share your experiences with ordinary people.</p>
            </div>
            <div className="border-l-4 border-green-500 pl-4 py-2">
              <h4 className="font-semibold text-lg mb-2">What topics can I discuss here?</h4>
              <p className="text-gray-600">Discuss anything that matters to ordinary people - government policies, council issues, daily life challenges, personal experiences, and connect with others who share your concerns and interests.</p>
            </div>
            <div className="border-l-4 border-purple-500 pl-4 py-2">
              <h4 className="font-semibold text-lg mb-2">Is my information private and secure?</h4>
              <p className="text-gray-600">Yes, all your personal information is stored securely with permanent database protection. Only you control what you choose to share with the community in discussions and your profile.</p>
            </div>
            <div className="border-l-4 border-orange-500 pl-4 py-2">
              <h4 className="font-semibold text-lg mb-2">How do I connect with other community members?</h4>
              <p className="text-gray-600">Use the Chat feature to find and message other users, participate in discussions, or visit Profile Walls to connect with people who share similar interests and viewpoints on important topics.</p>
            </div>
            <div className="border-l-4 border-red-500 pl-4 py-2">
              <h4 className="font-semibold text-lg mb-2">Can I share my opinions freely?</h4>
              <p className="text-gray-600">This is a platform for ordinary people to share their views and experiences. We encourage open discussion while maintaining respectful communication. Share your thoughts on topics that matter to you.</p>
            </div>
          </CardContent>
        </Card>

        {/* Contact Methods */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center p-6">
            <Clock className="w-10 h-10 mx-auto mb-3 text-blue-600" />
            <h3 className="font-semibold mb-2">Response Time</h3>
            <p className="text-gray-600">We typically respond within 24-48 hours</p>
          </Card>
          <Card className="text-center p-6">
            <Shield className="w-10 h-10 mx-auto mb-3 text-green-600" />
            <h3 className="font-semibold mb-2">Privacy Protected</h3>
            <p className="text-gray-600">Your messages are handled confidentially</p>
          </Card>
          <Card className="text-center p-6">
            <Heart className="w-10 h-10 mx-auto mb-3 text-red-600" />
            <h3 className="font-semibold mb-2">Community Focused</h3>
            <p className="text-gray-600">We understand ordinary people's concerns matter</p>
          </Card>
        </div>
      </div>

      {/* Advertisement Carousels */}
      <div className="relative">
        {/* Left carousel - Local ads */}
        <div className="fixed left-0 top-1/2 transform -translate-y-1/2 z-20 hidden lg:block">
          <AdCarousel 
            location="Nottingham" 
            scope="local" 
            position="left"
          />
        </div>

        {/* Right carousel - National ads */}
        <div className="fixed right-0 top-1/2 transform -translate-y-1/2 z-20 hidden lg:block">
          <AdCarousel 
            scope="national" 
            position="right"
          />
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6 space-y-8 -mt-8">
        {/* Contact Information */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6 text-center">
              <Mail className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Email Us</h3>
              <p className="text-gray-600 text-sm">patientbrain.com@gmail.com</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Phone className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Call Us</h3>
              <a 
                href="tel:+447711776304" 
                className="text-primary hover:text-primary-dark text-sm font-medium"
              >
                +44 7711 776 304
              </a>
              <p className="text-gray-500 text-xs mt-1">Mon-Fri 9AM-5PM GMT</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <MapPin className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Location</h3>
              <p className="text-gray-600 text-sm">Online Health Community</p>
            </CardContent>
          </Card>
        </div>

        {/* Instant Messaging Contact Options */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-6 text-center">
              <MessageCircle className="w-8 h-8 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">WhatsApp</h3>
              <p className="text-gray-600 text-sm mb-4">Quick support via WhatsApp</p>
              <a 
                href="https://wa.me/447711776304?text=Hello%20Ordinary%20People%20Community%2C%20I%20need%20help%20with..."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Message on WhatsApp
              </a>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-6 text-center">
              <MessageSquare className="w-8 h-8 text-blue-600 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Facebook Messenger</h3>
              <p className="text-gray-600 text-sm mb-4">Chat with us on Messenger</p>
              <a 
                href="https://m.me/ordinarypeoplecommunity"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Chat on Messenger
              </a>
            </CardContent>
          </Card>
        </div>

        {/* Contact Form */}
        <Card>
          <CardHeader>
            <CardTitle>Send us a message</CardTitle>
            <CardDescription>
              We'd love to hear from you. Send us a message and we'll respond as soon as possible.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    placeholder="Your name"
                    {...form.register("name")}
                  />
                  {form.formState.errors.name && (
                    <p className="text-sm text-red-600">{form.formState.errors.name.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    {...form.register("email")}
                  />
                  {form.formState.errors.email && (
                    <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  placeholder="What is this regarding?"
                  {...form.register("subject")}
                />
                {form.formState.errors.subject && (
                  <p className="text-sm text-red-600">{form.formState.errors.subject.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Tell us more about your question or feedback..."
                  className="min-h-32"
                  {...form.register("message")}
                />
                {form.formState.errors.message && (
                  <p className="text-sm text-red-600">{form.formState.errors.message.message}</p>
                )}
              </div>

              <Button type="submit" disabled={isSubmitting} className="w-full md:w-auto">
                {isSubmitting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Send className="w-4 h-4 mr-2" />
                )}
                {isSubmitting ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Legal Notice */}
        <Card className="bg-red-50 border-red-200">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <Shield className="w-6 h-6 text-red-600 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-red-800 mb-3">Important Legal Information</h3>
                <p className="text-red-700 text-sm mb-4">
                  Before using this platform or engaging in any business activities, please review our comprehensive 
                  legal disclosures regarding platform liability, user content, and business transactions.
                </p>
                <Link href="/disclosures">
                  <Button variant="destructive" size="sm" className="bg-red-600 hover:bg-red-700">
                    <Shield className="w-4 h-4 mr-2" />
                    View Platform Disclosures
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Additional Information */}
        <Card className="bg-primary-light border-primary-light">
          <CardContent className="p-6">
            <h3 className="font-semibold text-primary-dark mb-3">Get Support</h3>
            <p className="text-primary-dark/80 text-sm mb-4">
              For urgent health-related questions, please consult with your healthcare provider. 
              For platform support, account issues, or general inquiries, we're here to help!
            </p>
            <div className="space-y-2 text-sm text-primary-dark/70">
              <p>• Account and login issues</p>
              <p>• Technical support</p>
              <p>• Feature requests</p>
              <p>• General feedback</p>
              <p>• Partnership inquiries</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}