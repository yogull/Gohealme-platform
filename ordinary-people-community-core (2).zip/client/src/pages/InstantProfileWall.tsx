import React from 'react';
import { Button } from '@/components/ui/button';
import { Camera, ArrowLeft, Home, Users, Share2 } from 'lucide-react';
import { Link } from 'wouter';

export default function InstantProfileWall() {
  const uploadImage = (type: 'profile' | 'cover') => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = e.target?.result as string;
        
        try {
          const response = await fetch('/api/files/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileName: `${type}_${Date.now()}.jpg`,
              fileData: base64,
              userId: 4
            })
          });
          
          if (response.ok) {
            alert(`${type} image uploaded! Refreshing page...`);
            window.location.reload();
          } else {
            alert('Upload failed');
          }
        } catch (error) {
          alert('Upload failed');
        }
      };
      
      reader.readAsDataURL(file);
    };
    
    input.click();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex gap-3">
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <Link href="/social">
              <Button className="bg-green-600 hover:bg-green-700" size="sm">
                <Users className="h-4 w-4 mr-2" />
                Social Hub
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        {/* Cover Photo Section */}
        <div className="relative mb-20">
          <div 
            className="h-64 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 cursor-pointer flex items-center justify-center"
            onClick={() => uploadImage('cover')}
          >
            <div className="text-white text-center">
              <Camera className="h-16 w-16 mx-auto mb-4 opacity-80" />
              <h2 className="text-2xl font-bold mb-2">Add Cover Photo</h2>
              <p className="text-lg opacity-90">Click anywhere to upload</p>
            </div>
          </div>
          
          <Button
            onClick={() => uploadImage('cover')}
            className="absolute top-4 right-4 bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm"
            size="sm"
          >
            <Camera className="h-4 w-4 mr-2" />
            Edit Cover
          </Button>
        </div>

        {/* Profile Section */}
        <div className="px-6 -mt-16 relative z-10">
          <div className="flex items-end mb-6">
            <div className="relative">
              <div 
                className="w-40 h-40 rounded-full bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 border-6 border-white cursor-pointer flex items-center justify-center shadow-xl"
                onClick={() => uploadImage('profile')}
              >
                <span className="text-white text-6xl font-bold">J</span>
              </div>
              
              <Button
                onClick={() => uploadImage('profile')}
                className="absolute bottom-3 right-3 w-12 h-12 rounded-full p-0 bg-blue-600 hover:bg-blue-700 shadow-lg"
              >
                <Camera className="h-5 w-5" />
              </Button>
            </div>
            
            <div className="ml-6 pb-4">
              <h1 className="text-4xl font-bold text-gray-900 mb-2">John Proctor</h1>
              <p className="text-xl text-gray-600 mb-4">Community Leader & Health Advocate</p>
              <p className="text-gray-500">Ordinary People Community - Away from Elite Control</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex gap-4 mb-8">
            <Button
              onClick={() => uploadImage('profile')}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Camera className="h-4 w-4 mr-2" />
              Add Photos
            </Button>
            
            <Button
              onClick={() => {
                const url = window.location.href;
                const text = "Check out my profile on Ordinary People Community!";
                if (navigator.share) {
                  navigator.share({ title: 'My Profile', text, url });
                } else {
                  navigator.clipboard.writeText(`${text} ${url}`);
                  alert('Link copied to clipboard!');
                }
              }}
              variant="outline"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share Profile
            </Button>
          </div>

          {/* Revenue Opportunity Card */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-8">
            <div className="flex items-center mb-3">
              <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
              <h3 className="text-lg font-semibold text-green-800">Start Making Money Today!</h3>
            </div>
            <p className="text-green-700 mb-4">
              Personal Affiliate Shop System: Add your Amazon/eBay affiliate links and earn commissions on every sale.
            </p>
            <div className="flex gap-3">
              <Link href="/shop">
                <Button className="bg-green-600 hover:bg-green-700">
                  Set Up My Shop (£1 per link)
                </Button>
              </Link>
              <Link href="/location-ads">
                <Button variant="outline" className="border-green-300 text-green-700">
                  Browse Local Businesses
                </Button>
              </Link>
            </div>
          </div>

          {/* Three Sharing Options */}
          <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
            <h2 className="text-2xl font-semibold mb-4">Share Content</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button className="bg-blue-600 hover:bg-blue-700 h-16">
                <div className="text-center">
                  <Share2 className="h-6 w-6 mx-auto mb-1" />
                  <div className="text-sm font-medium">OPC Wall</div>
                </div>
              </Button>
              
              <Button className="bg-green-600 hover:bg-green-700 h-16">
                <div className="text-center">
                  <Users className="h-6 w-6 mx-auto mb-1" />
                  <div className="text-sm font-medium">My Wall</div>
                </div>
              </Button>
              
              <Button className="bg-purple-600 hover:bg-purple-700 h-16">
                <div className="text-center">
                  <Share2 className="h-6 w-6 mx-auto mb-1" />
                  <div className="text-sm font-medium">Multi-Share</div>
                </div>
              </Button>
            </div>
          </div>

          {/* Posts Feed */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-semibold mb-6">Recent Activity</h2>
            <div className="text-center py-16 text-gray-500">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-12 w-12 text-gray-400" />
              </div>
              <h3 className="text-xl font-medium text-gray-700 mb-2">Ready to Connect</h3>
              <p className="text-gray-500 mb-6">Start sharing your thoughts and connect with the community</p>
              <div className="flex gap-3 justify-center">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Create First Post
                </Button>
                <Link href="/community">
                  <Button variant="outline">
                    Browse Discussions
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}