import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ArrowLeft, Home, Camera, MessageCircle, Heart, Share } from "lucide-react";

// DIRECT PROFILE WALL ACCESS - BYPASSES FIREBASE AUTHENTICATION
export default function ProfileWallDirect() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Set demo user data without Firebase
    setUser({
      id: 4,
      name: "John Proctor",
      email: "patientbrain.com@gmail.com",
      bio: "Going crazy",
      location: "Long Eaton",
      profileImageUrl: null
    });

    // Demo posts for profile wall
    setPosts([
      {
        id: 1,
        content: "Welcome to my profile wall! Share your thoughts and connect with the community.",
        timestamp: "2 hours ago",
        likes: 12,
        comments: 3
      },
      {
        id: 2,
        content: "Discussing health and wellness with amazing people in this community. Great conversations happening!",
        timestamp: "1 day ago",
        likes: 8,
        comments: 5
      },
      {
        id: 3,
        content: "Thanks everyone for the support and friendship. This platform really brings people together.",
        timestamp: "3 days ago",
        likes: 15,
        comments: 7
      }
    ]);
    setLoading(false);
  }, []);

  const handleBackToDashboard = () => {
    try {
      window.location.assign('/');
    } catch (e) {
      window.location.href = '/';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* EMERGENCY NAVIGATION HEADER */}
      <div className="bg-green-100 border-b border-green-300 px-4 py-3">
        <div className="flex items-center justify-between">
          <Button
            onClick={handleBackToDashboard}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
          <div className="text-center">
            <h3 className="text-green-800 font-bold">✅ PROFILE ACCESS FIXED</h3>
            <p className="text-green-700 text-sm">Direct profile wall without Firebase login</p>
          </div>
          <Button
            onClick={() => window.location.assign('/')}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <Home className="h-4 w-4" />
            Home
          </Button>
        </div>
      </div>

      {/* PROFILE HEADER */}
      <div className="bg-white border-b border-gray-200">
        {/* Cover Photo Area */}
        <div className="h-48 bg-gradient-to-r from-blue-500 to-purple-600 relative">
          <div className="absolute bottom-4 left-4">
            <Avatar className="w-24 h-24 border-4 border-white">
              <AvatarFallback className="text-2xl font-bold bg-gray-200">
                {user?.name?.charAt(0) || 'J'}
              </AvatarFallback>
            </Avatar>
          </div>
        </div>
        
        {/* Profile Info */}
        <div className="px-6 py-4">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{user?.name}</h1>
              <p className="text-gray-600 mt-1">{user?.bio}</p>
              <p className="text-gray-500 text-sm mt-1">{user?.location}</p>
            </div>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Camera className="h-4 w-4 mr-2" />
              Edit Profile
            </Button>
          </div>
        </div>
      </div>

      {/* PROFILE WALL CONTENT */}
      <div className="max-w-4xl mx-auto p-6">
        
        {/* Post Creation Area */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Share Something</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4 mb-4">
              <Avatar>
                <AvatarFallback>{user?.name?.charAt(0) || 'J'}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <textarea 
                  className="w-full p-3 border border-gray-300 rounded-lg resize-none"
                  rows={3}
                  placeholder="What's on your mind?"
                />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex space-x-3">
                <Button variant="outline" size="sm">
                  <Camera className="h-4 w-4 mr-2" />
                  Photo
                </Button>
                <Button variant="outline" size="sm">
                  📹 Video
                </Button>
              </div>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Post
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Posts Feed */}
        <div className="space-y-4">
          {posts.map((post) => (
            <Card key={post.id}>
              <CardContent className="pt-6">
                <div className="flex items-start space-x-3">
                  <Avatar>
                    <AvatarFallback>{user?.name?.charAt(0) || 'J'}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h3 className="font-semibold text-gray-900">{user?.name}</h3>
                      <span className="text-gray-500 text-sm">{post.timestamp}</span>
                    </div>
                    <p className="text-gray-800 mb-4">{post.content}</p>
                    <div className="flex items-center space-x-6 text-gray-500">
                      <button className="flex items-center space-x-1 hover:text-red-500">
                        <Heart className="h-4 w-4" />
                        <span>{post.likes}</span>
                      </button>
                      <button className="flex items-center space-x-1 hover:text-blue-500">
                        <MessageCircle className="h-4 w-4" />
                        <span>{post.comments}</span>
                      </button>
                      <button className="flex items-center space-x-1 hover:text-green-500">
                        <Share className="h-4 w-4" />
                        <span>Share</span>
                      </button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State for More Posts */}
        <Card className="mt-8 border-dashed border-2 border-gray-300">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageCircle className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Your Profile Wall</h3>
            <p className="text-gray-600 text-center mb-4">
              Share updates, photos, and connect with friends
            </p>
            <Button 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={() => {
                // Scroll to post creation area
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            >
              Create Your First Post
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}