import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageCircle, Users, Plus, ArrowLeft, Home } from "lucide-react";

// DIRECT COMMUNITY ACCESS - BYPASSES FIREBASE AUTHENTICATION
export default function CommunityDirect() {
  const [discussions, setDiscussions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Direct API call without authentication checks
    fetch('/api/discussions/public')
      .then(res => res.json())
      .then(data => {
        setDiscussions(data || []);
        setLoading(false);
      })
      .catch(err => {
        console.log('Using demo discussions');
        setDiscussions([
          {
            id: 1,
            title: "Health Discussion Community",
            description: "Share your health experiences and get support",
            category: "Health",
            messageCount: 45,
            lastActivity: "2 hours ago"
          },
          {
            id: 2,
            title: "Local Community Chat",
            description: "Connect with people in your area",
            category: "Community", 
            messageCount: 23,
            lastActivity: "1 hour ago"
          },
          {
            id: 3,
            title: "Government & Politics",
            description: "Discuss current affairs and policies",
            category: "Government",
            messageCount: 67,
            lastActivity: "30 minutes ago"
          }
        ]);
        setLoading(false);
      });
  }, []);

  const handleBackToDashboard = () => {
    try {
      window.location.assign('/');
    } catch (e) {
      window.location.href = '/';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Community...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* EMERGENCY NAVIGATION HEADER */}
      <div className="bg-green-100 border-b border-green-300 px-4 py-3">
        <div className="flex items-center justify-between">
          <Button
            onClick={handleBackToDashboard}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
          <div className="text-center">
            <h3 className="text-green-800 font-bold">✅ AUTHENTICATION BYPASS ACTIVE</h3>
            <p className="text-green-700 text-sm">Direct community access without Firebase login</p>
          </div>
          <Button
            onClick={() => window.location.assign('/')}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <Home className="h-4 w-4" />
            Home
          </Button>
        </div>
      </div>

      {/* COMMUNITY HEADER */}
      <div className="bg-white border-b border-gray-200 px-4 py-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Users className="h-8 w-8 text-blue-600" />
                Community Discussions
              </h1>
              <p className="text-gray-600 mt-2">Connect with people, share experiences, get support</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{discussions.length}</div>
                <div className="text-sm text-gray-500">Active Topics</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* DISCUSSIONS GRID */}
      <div className="max-w-6xl mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {discussions.map((discussion) => (
            <Card key={discussion.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="text-lg font-semibold text-gray-900">
                    {discussion.title}
                  </span>
                  <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                    {discussion.category}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4 line-clamp-2">
                  {discussion.description}
                </p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center gap-1">
                    <MessageCircle className="h-4 w-4" />
                    <span>{discussion.messageCount} messages</span>
                  </div>
                  <span>{discussion.lastActivity}</span>
                </div>
                <Button 
                  className="w-full mt-4"
                  onClick={() => {
                    // Direct navigation to discussion
                    window.location.assign(`/category/${discussion.category.toLowerCase()}`);
                  }}
                >
                  Join Discussion
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CREATE NEW DISCUSSION */}
        <Card className="mt-8 border-dashed border-2 border-gray-300">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Plus className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Start a New Discussion</h3>
            <p className="text-gray-600 text-center mb-4">
              Share your thoughts, ask questions, or start a conversation
            </p>
            <Button 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={() => {
                // For now, just alert - can be enhanced later
                alert('Discussion creation will be available soon. Join existing discussions for now!');
              }}
            >
              Create Discussion
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}