import React from 'react';
import { useParams, Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Users, MessageCircle, Share2, Heart, Play, Camera, Send, Phone, Music, Edit, Hash } from 'lucide-react';
import { Facebook, Instagram, Twitter, Linkedin, Youtube } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { UniversalBackButton } from '@/components/UniversalBackButton';

const platformConfig = {
  facebook: {
    name: 'Facebook',
    icon: Facebook,
    color: 'bg-blue-600',
    description: 'Connect with friends and family, share updates, and discover communities.',
    features: ['News Feed', 'Friends', 'Groups', 'Marketplace', 'Events']
  },
  instagram: {
    name: 'Instagram',
    icon: Instagram,
    color: 'bg-pink-500',
    description: 'Share photos and videos, discover visual content, and connect through stories.',
    features: ['Photo Sharing', 'Stories', 'Reels', 'IGTV', 'Direct Messages']
  },
  twitter: {
    name: 'Twitter',
    icon: Twitter,
    color: 'bg-blue-400',
    description: 'Share thoughts, follow news, and engage in real-time conversations.',
    features: ['Tweets', 'Trending Topics', 'Direct Messages', 'Threads', 'Spaces']
  },
  linkedin: {
    name: 'LinkedIn',
    icon: Linkedin,
    color: 'bg-blue-700',
    description: 'Professional networking, career opportunities, and business connections.',
    features: ['Professional Posts', 'Job Search', 'Networking', 'Company Pages', 'Learning']
  },
  youtube: {
    name: 'YouTube',
    icon: Youtube,
    color: 'bg-red-600',
    description: 'Watch and share videos, subscribe to channels, and create content.',
    features: ['Video Streaming', 'Subscriptions', 'Playlists', 'Live Streaming', 'Shorts']
  },
  tiktok: {
    name: 'TikTok',
    icon: Play,
    color: 'bg-black',
    description: 'Short-form videos, viral content, and creative expression.',
    features: ['Short Videos', 'For You Page', 'Challenges', 'Duets', 'Live Streaming']
  },
  snapchat: {
    name: 'Snapchat',
    icon: Camera,
    color: 'bg-yellow-400',
    description: 'Disappearing messages, camera filters, and location sharing.',
    features: ['Snaps', 'Stories', 'Filters', 'Snap Map', 'Bitmoji']
  },
  discord: {
    name: 'Discord',
    icon: MessageCircle,
    color: 'bg-indigo-600',
    description: 'Gaming communities, voice chat, and text communication.',
    features: ['Servers', 'Voice Channels', 'Text Chat', 'Screen Sharing', 'Bots']
  },
  reddit: {
    name: 'Reddit',
    icon: MessageCircle,
    color: 'bg-orange-600',
    description: 'Discussion communities, news aggregation, and content voting.',
    features: ['Subreddits', 'Upvoting', 'Comments', 'AMAs', 'Reddit Gold']
  },
  pinterest: {
    name: 'Pinterest',
    icon: Heart,
    color: 'bg-red-500',
    description: 'Visual discovery, inspiration boards, and creative ideas.',
    features: ['Boards', 'Pins', 'Shopping', 'Recipes', 'DIY Ideas']
  },
  tumblr: {
    name: 'Tumblr',
    icon: Hash,
    color: 'bg-blue-900',
    description: 'Microblogging, creative content, and community expression.',
    features: ['Blog Posts', 'Reblogs', 'Tags', 'Multimedia', 'Community']
  },
  twitch: {
    name: 'Twitch',
    icon: Play,
    color: 'bg-purple-600',
    description: 'Live streaming, gaming content, and interactive communities.',
    features: ['Live Streams', 'Chat', 'Follows', 'Subscriptions', 'Clips']
  },
  whatsapp: {
    name: 'WhatsApp',
    icon: Phone,
    color: 'bg-green-600',
    description: 'Messaging, voice calls, and group communication.',
    features: ['Messages', 'Voice Calls', 'Video Calls', 'Groups', 'Status']
  },
  telegram: {
    name: 'Telegram',
    icon: Send,
    color: 'bg-blue-500',
    description: 'Secure messaging, channels, and large group communication.',
    features: ['Messages', 'Channels', 'Bots', 'File Sharing', 'Secret Chats']
  },
  spotify: {
    name: 'Spotify',
    icon: Music,
    color: 'bg-green-500',
    description: 'Music streaming, playlists, and podcast discovery.',
    features: ['Music Streaming', 'Playlists', 'Podcasts', 'Discover Weekly', 'Social Sharing']
  },
  medium: {
    name: 'Medium',
    icon: Edit,
    color: 'bg-gray-700',
    description: 'Writing platform, thoughtful content, and professional publishing.',
    features: ['Articles', 'Publications', 'Claps', 'Highlights', 'Partner Program']
  }
};

export default function SocialNetworkView() {
  const { platform } = useParams<{ platform: string }>();
  const config = platformConfig[platform as keyof typeof platformConfig];

  if (!config) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardContent className="p-6 text-center">
              <h1 className="text-2xl font-bold mb-4">Platform Not Found</h1>
              <p className="text-gray-600 mb-4">The social media platform you're looking for doesn't exist.</p>
              <Link href="/profile-wall/4">
                <Button>Back to Profile Wall</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const IconComponent = config.icon;

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Universal Navigation */}
        <UniversalBackButton />

        {/* Platform Header */}
        <div className="flex items-center gap-4 mb-6">
          <div className={`w-12 h-12 ${config.color} rounded-lg flex items-center justify-center`}>
            <IconComponent className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{config.name} Network</h1>
            <p className="text-gray-600">View {config.name} content within OPC</p>
          </div>
        </div>

        {/* Platform Information */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <IconComponent className="h-5 w-5" />
              About {config.name}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-4">{config.description}</p>
            <div>
              <h4 className="font-semibold mb-2">Key Features:</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {config.features.map((feature, index) => (
                  <div key={index} className="bg-gray-100 px-3 py-2 rounded-lg text-sm">
                    {feature}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* OPC Integration Notice */}
        <Card className="mb-6 border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Users className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-900 mb-1">Ordinary People Community Integration</h3>
                <p className="text-blue-800 text-sm">
                  This is your {config.name} network view within OPC. Connect with community members who also use {config.name}, 
                  share content across platforms, and discover how other ordinary people are using {config.name} for meaningful connections.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Functional Social Sharing */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Share2 className="h-4 w-4" />
                Share to {config.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Share content directly to {config.name}</p>
              <Button 
                className="w-full"
                onClick={() => {
                  const shareUrl = encodeURIComponent('https://ordinarypeoplecommunity.com');
                  const shareText = encodeURIComponent('Check out Ordinary People Community - where real people discuss health, government, and daily life!');
                  
                  if (platform === 'facebook') {
                    window.open(`https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`, '_blank', 'width=600,height=400');
                  } else if (platform === 'twitter') {
                    window.open(`https://twitter.com/intent/tweet?text=${shareText}&url=${shareUrl}`, '_blank', 'width=600,height=400');
                  } else if (platform === 'linkedin') {
                    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`, '_blank', 'width=600,height=400');
                  } else if (platform === 'instagram') {
                    // Instagram doesn't support direct URL sharing, copy to clipboard
                    navigator.clipboard.writeText(`${decodeURIComponent(shareText)} ${decodeURIComponent(shareUrl)}`);
                    toast({ title: "Copied to clipboard!", description: "Paste this into your Instagram post" });
                  } else {
                    navigator.clipboard.writeText(`${decodeURIComponent(shareText)} ${decodeURIComponent(shareUrl)}`);
                    toast({ title: "Copied to clipboard!", description: `Paste this into your ${config.name} post` });
                  }
                }}
              >
                Share to {config.name}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                Find Community Members
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Connect with OPC members on {config.name}</p>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  if (platform === 'facebook') {
                    window.open('https://www.facebook.com/search/top?q=ordinary%20people%20community', '_blank');
                  } else if (platform === 'twitter') {
                    window.open('https://twitter.com/search?q=ordinary%20people%20community', '_blank');
                  } else if (platform === 'linkedin') {
                    window.open('https://www.linkedin.com/search/results/all/?keywords=ordinary%20people%20community', '_blank');
                  } else if (platform === 'instagram') {
                    window.open('https://www.instagram.com/explore/tags/ordinarypeople/', '_blank');
                  } else {
                    toast({ 
                      title: "Search for 'Ordinary People Community'", 
                      description: `Look for OPC members on ${config.name}` 
                    });
                  }
                }}
              >
                Find Members on {config.name}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Safety Notice */}
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="p-4">
            <h3 className="font-semibold text-amber-900 mb-2">Privacy & Safety</h3>
            <p className="text-amber-800 text-sm">
              Your privacy is important. When connecting external social media accounts, only share what you're comfortable with. 
              OPC provides a safe space for ordinary people to connect without elite control or excessive data harvesting.
            </p>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="flex gap-4 mt-6">
          <Link href="/community">
            <Button variant="outline">Join Community Discussions</Button>
          </Link>
          <Link href="/chat">
            <Button variant="outline">Start Private Chat</Button>
          </Link>
          <Link href="/dashboard">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}