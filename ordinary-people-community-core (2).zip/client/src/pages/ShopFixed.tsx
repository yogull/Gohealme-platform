import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DollarSign, ShoppingCart, Star, TrendingUp, Users, Package, ArrowLeft, Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";

export default function Shop() {
  const { appUser } = useAuth();
  const [location, setLocation] = useLocation();
  const { toast } = useToast();

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-6">
          {/* Navigation Buttons */}
          <div className="flex items-center gap-2 mb-4">
            <Button
              variant="outline"
              onClick={() => window.history.back()}
              className="flex items-center gap-2 text-xs md:text-sm px-2 md:px-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <Button
              variant="outline"
              onClick={() => setLocation('/dashboard')}
              className="flex items-center gap-2 text-xs md:text-sm px-2 md:px-4"
            >
              <Home className="w-4 h-4" />
              Dashboard
            </Button>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Personal Affiliate Shop</h1>
              <p className="text-gray-600 mt-1">Start earning money with your own affiliate links</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                <DollarSign className="w-4 h-4 mr-1" />
                Money Making System
              </Badge>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Welcome Card */}
        <Card className="mb-8 bg-gradient-to-r from-green-500 to-emerald-600 text-white">
          <CardContent className="p-8">
            <div className="text-center">
              <div className="bg-white/20 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <ShoppingCart className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-bold mb-2">We've Done Everything For You - Now Start Making Money!</h2>
              <p className="text-green-100 mb-4 max-w-2xl mx-auto">
                Your personal affiliate shop is ready. Add your Amazon, eBay, or other affiliate links and start earning commissions immediately.
              </p>
              <div className="flex justify-center items-center gap-6 text-sm">
                <span className="flex items-center gap-1">
                  <Package className="w-4 h-4" />
                  Zero Setup Required
                </span>
                <span className="flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  Instant Earnings
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  Your Personal Store
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pricing Structure */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="border-2 border-green-200">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl text-green-600">Starter Package</CardTitle>
              <CardDescription>Perfect for getting started</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-2">£1</div>
              <div className="text-gray-600 mb-4">per affiliate link</div>
              <div className="bg-green-50 p-4 rounded-lg mb-4">
                <div className="text-2xl font-bold text-green-700">First 20 Links</div>
                <div className="text-sm text-green-600">One-time payment per link</div>
              </div>
              <ul className="text-left space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  Amazon affiliate links
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  eBay affiliate links
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  Custom product descriptions
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  Instant commission tracking
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-2 border-blue-200">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl text-blue-600">Growth Package</CardTitle>
              <CardDescription>For expanding your business</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">£2</div>
              <div className="text-gray-600 mb-4">per month maintenance</div>
              <div className="bg-blue-50 p-4 rounded-lg mb-4">
                <div className="text-2xl font-bold text-blue-700">Links 21+</div>
                <div className="text-sm text-blue-600">Monthly maintenance fee</div>
              </div>
              <ul className="text-left space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                  Unlimited additional links
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                  Priority support
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                  Advanced analytics
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                  Custom shop branding
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Getting Started Guide */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-yellow-500" />
              How to Start Making Money Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-xl font-bold text-blue-600">1</span>
                </div>
                <h3 className="font-semibold mb-2">Get Affiliate Links</h3>
                <p className="text-sm text-gray-600">
                  Sign up for Amazon Associates, eBay Partner Network, or other affiliate programs. Get your unique referral links.
                </p>
              </div>
              <div className="text-center">
                <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-xl font-bold text-green-600">2</span>
                </div>
                <h3 className="font-semibold mb-2">Add to Your Shop</h3>
                <p className="text-sm text-gray-600">
                  Add your affiliate links to your personal shop with custom descriptions and images.
                </p>
              </div>
              <div className="text-center">
                <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-xl font-bold text-purple-600">3</span>
                </div>
                <h3 className="font-semibold mb-2">Earn Commissions</h3>
                <p className="text-sm text-gray-600">
                  Share your shop link with friends and family. Earn commissions on every purchase made through your links.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Success Stories */}
        <Card className="mb-8 bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-yellow-700">Success Stories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-lg">
                <p className="text-sm italic text-gray-600 mb-2">
                  "I started with just 5 Amazon links for kitchen gadgets. Within 3 months, I'm earning £150+ per month!"
                </p>
                <p className="text-xs font-semibold text-gray-700">- Sarah M., Manchester</p>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <p className="text-sm italic text-gray-600 mb-2">
                  "My tech product recommendations now bring in over £300 monthly. The setup was so simple!"
                </p>
                <p className="text-xs font-semibold text-gray-700">- David L., London</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <div className="text-center">
          <Button 
            size="lg" 
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-3"
            onClick={() => {
              if (appUser) {
                // Navigate directly to personal shop page
                setLocation('/personal-shop');
              } else {
                toast({
                  title: "Please Login",
                  description: "You need to be logged in to access your personal shop",
                  variant: "destructive"
                });
              }
            }}
          >
            <ShoppingCart className="w-5 h-5 mr-2" />
            Access My Personal Shop
          </Button>
          
          {/* Show shop creation status */}
          <div className="mt-4 p-3 bg-green-100 border border-green-200 rounded-lg">
            <p className="text-sm text-green-700">
              Your shop "Yogull" has been created successfully! Click above to manage your affiliate links.
            </p>
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Start your affiliate journey today - no experience required!
          </p>
        </div>
      </div>
    </div>
  );
}