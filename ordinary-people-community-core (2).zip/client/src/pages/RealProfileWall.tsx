import React, { useState } from 'react';
import { useParams } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Heart, MessageCircle, Share2, Camera, Video, Edit3, MapPin, User, Calendar, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface User {
  id: number;
  name: string;
  email: string;
  bio?: string;
  location?: string;
  profileImage?: string;
  coverImage?: string;
}

interface Post {
  id: number;
  userId: number;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  createdAt: string;
  likesCount: number;
  commentsCount: number;
  isLiked: boolean;
  user: User;
}

const RealProfileWall = () => {
  const { userId } = useParams<{ userId: string }>();
  const [newPost, setNewPost] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editingProfile, setEditingProfile] = useState({ name: '', bio: '', location: '' });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch user profile
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['user', userId],
    queryFn: async () => {
      const response = await fetch(`/api/users/${userId}`);
      if (!response.ok) throw new Error('Failed to fetch user');
      return response.json();
    }
  });

  // Fetch profile posts
  const { data: posts = [], isLoading: postsLoading } = useQuery({
    queryKey: ['profile-posts', userId],
    queryFn: async () => {
      const response = await fetch(`/api/profile-posts/${userId}`);
      if (!response.ok) throw new Error('Failed to fetch posts');
      return response.json();
    }
  });

  // Create new post mutation
  const createPostMutation = useMutation({
    mutationFn: async (postData: { content: string; mediaUrl?: string; mediaType?: string }) => {
      const response = await fetch('/api/profile-posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...postData, userId: parseInt(userId!) })
      });
      if (!response.ok) throw new Error('Failed to create post');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profile-posts', userId] });
      setNewPost('');
      setSelectedFile(null);
      toast({ title: 'Post created successfully!' });
    }
  });

  // Like post mutation
  const likePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      const response = await fetch(`/api/profile-posts/${postId}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!response.ok) throw new Error('Failed to like post');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profile-posts', userId] });
    }
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (profileData: { name: string; bio: string; location: string }) => {
      const response = await fetch(`/api/users/${userId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profileData)
      });
      if (!response.ok) throw new Error('Failed to update profile');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user', userId] });
      setIsEditing(false);
      toast({ title: 'Profile updated successfully!' });
    }
  });

  const handleCreatePost = () => {
    if (!newPost.trim() && !selectedFile) return;
    
    if (selectedFile) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const mediaUrl = e.target?.result as string;
        const mediaType = selectedFile.type.startsWith('image/') ? 'image' : 'video';
        createPostMutation.mutate({ content: newPost, mediaUrl, mediaType });
      };
      reader.readAsDataURL(selectedFile);
    } else {
      createPostMutation.mutate({ content: newPost });
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleProfileUpdate = () => {
    updateProfileMutation.mutate(editingProfile);
  };

  if (userLoading || postsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-lg">Loading profile...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-lg text-red-600">User not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Cover Photo */}
      <div className="relative h-64 bg-gradient-to-r from-blue-500 to-purple-600">
        {user.coverImage && (
          <img src={user.coverImage} alt="Cover" className="w-full h-full object-cover" />
        )}
        <Button
          variant="outline"
          size="sm"
          className="absolute bottom-4 right-4 bg-white/80 hover:bg-white"
        >
          <Camera className="w-4 h-4 mr-2" />
          Edit Cover
        </Button>
      </div>

      {/* Profile Header */}
      <div className="max-w-4xl mx-auto px-4 -mt-16 relative z-10">
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
              <Avatar className="w-32 h-32 border-4 border-white shadow-lg">
                <AvatarImage src={user.profileImage} />
                <AvatarFallback className="text-2xl bg-blue-500 text-white">
                  {user.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                {isEditing ? (
                  <div className="space-y-3">
                    <Input
                      value={editingProfile.name}
                      onChange={(e) => setEditingProfile(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Name"
                    />
                    <Textarea
                      value={editingProfile.bio}
                      onChange={(e) => setEditingProfile(prev => ({ ...prev, bio: e.target.value }))}
                      placeholder="Bio"
                      rows={2}
                    />
                    <Input
                      value={editingProfile.location}
                      onChange={(e) => setEditingProfile(prev => ({ ...prev, location: e.target.value }))}
                      placeholder="Location"
                    />
                    <div className="flex gap-2">
                      <Button onClick={handleProfileUpdate} size="sm">Save</Button>
                      <Button onClick={() => setIsEditing(false)} variant="outline" size="sm">Cancel</Button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
                    {user.bio && <p className="text-gray-600 mb-2">{user.bio}</p>}
                    {user.location && (
                      <div className="flex items-center text-gray-500 mb-4">
                        <MapPin className="w-4 h-4 mr-1" />
                        {user.location}
                      </div>
                    )}
                    <Button
                      onClick={() => {
                        setEditingProfile({ name: user.name, bio: user.bio || '', location: user.location || '' });
                        setIsEditing(true);
                      }}
                      variant="outline"
                      size="sm"
                    >
                      <Edit3 className="w-4 h-4 mr-2" />
                      Edit Profile
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Create Post */}
        <Card className="mb-6">
          <CardHeader>
            <h2 className="text-lg font-semibold">What's on your mind?</h2>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Textarea
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                placeholder="Share your thoughts..."
                rows={3}
                className="w-full"
              />
              
              {selectedFile && (
                <div className="flex items-center justify-between bg-gray-100 p-2 rounded">
                  <span className="text-sm text-gray-600">{selectedFile.name}</span>
                  <Button
                    onClick={() => setSelectedFile(null)}
                    variant="ghost"
                    size="sm"
                  >
                    Remove
                  </Button>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="flex gap-2">
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      accept="image/*,video/*"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                    <Button variant="outline" size="sm" asChild>
                      <span>
                        <Camera className="w-4 h-4 mr-2" />
                        Photo/Video
                      </span>
                    </Button>
                  </label>
                </div>
                
                <Button
                  onClick={handleCreatePost}
                  disabled={!newPost.trim() && !selectedFile}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Post
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts Feed */}
        <div className="space-y-6">
          {posts.map((post: Post) => (
            <Card key={post.id}>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Avatar>
                    <AvatarImage src={post.user.profileImage} />
                    <AvatarFallback className="bg-blue-500 text-white">
                      {post.user.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold">{post.user.name}</h3>
                    <p className="text-sm text-gray-500">
                      {new Date(post.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {post.content && (
                  <p className="mb-4 text-gray-800 whitespace-pre-wrap">{post.content}</p>
                )}

                {post.mediaUrl && (
                  <div className="mb-4">
                    {post.mediaType === 'image' ? (
                      <img
                        src={post.mediaUrl}
                        alt="Post media"
                        className="w-full max-w-lg rounded-lg"
                      />
                    ) : (
                      <video
                        src={post.mediaUrl}
                        controls
                        className="w-full max-w-lg rounded-lg"
                      />
                    )}
                  </div>
                )}

                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="flex items-center gap-6">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => likePostMutation.mutate(post.id)}
                      className={post.isLiked ? 'text-red-500' : ''}
                    >
                      <Heart className={`w-4 h-4 mr-1 ${post.isLiked ? 'fill-current' : ''}`} />
                      {post.likesCount}
                    </Button>
                    
                    <Button variant="ghost" size="sm">
                      <MessageCircle className="w-4 h-4 mr-1" />
                      {post.commentsCount}
                    </Button>
                    
                    <Button variant="ghost" size="sm">
                      <Share2 className="w-4 h-4 mr-1" />
                      Share
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {posts.length === 0 && (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="text-gray-500">
                  <User className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg mb-2">No posts yet</p>
                  <p className="text-sm">Start sharing your thoughts and experiences!</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default RealProfileWall;