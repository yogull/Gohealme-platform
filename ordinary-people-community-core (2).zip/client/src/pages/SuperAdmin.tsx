import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { 
  Shield, 
  Users, 
  Ban, 
  Trash2, 
  Eye, 
  AlertTriangle, 
  MessageSquare, 
  ShoppingCart,
  FileText,
  UserPlus,
  Clock,
  CheckCircle,
  XCircle,
  Settings,
  Database,
  Search,
  Edit,
  Image,
  BarChart3,
  Rss,
  Folder,
  ShoppingBag,
  Rocket,
  Activity
} from "lucide-react";
import { Link } from "wouter";
import type { User, AdminAction, UserReport, ProfileWallPost, BlogPost, CompanyProduct, CommunityDiscussion, DiscussionCategory } from "@shared/schema";
import { useAuth } from "@/hooks/useAuth";

export default function SuperAdmin() {
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [blockReason, setBlockReason] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch all data
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    queryFn: async () => {
      const response = await fetch("/api/admin/users");
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json();
    },
  });

  const { data: posts = [] } = useQuery<ProfileWallPost[]>({
    queryKey: ["/api/admin/posts"],
    queryFn: async () => {
      const response = await fetch("/api/admin/posts");
      if (!response.ok) throw new Error('Failed to fetch posts');
      return response.json();
    },
  });

  const { data: blogs = [] } = useQuery<BlogPost[]>({
    queryKey: ["/api/admin/blogs"],
    queryFn: async () => {
      const response = await fetch("/api/admin/blogs");
      if (!response.ok) throw new Error('Failed to fetch blogs');
      return response.json();
    },
  });

  const { data: discussions = [] } = useQuery<CommunityDiscussion[]>({
    queryKey: ["/api/admin/discussions"],
    queryFn: async () => {
      const response = await fetch("/api/admin/discussions");
      if (!response.ok) throw new Error('Failed to fetch discussions');
      return response.json();
    },
  });

  const { data: categories = [] } = useQuery<DiscussionCategory[]>({
    queryKey: ["/api/discussion-categories"],
    queryFn: async () => {
      const response = await fetch("/api/discussion-categories");
      if (!response.ok) throw new Error('Failed to fetch categories');
      return response.json();
    },
  });

  const { data: products = [] } = useQuery<CompanyProduct[]>({
    queryKey: ["/api/admin/products"],
    queryFn: async () => {
      const response = await fetch("/api/admin/products");
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  const { data: actions = [] } = useQuery<AdminAction[]>({
    queryKey: ["/api/admin/actions"],
    queryFn: async () => {
      const response = await fetch("/api/admin/actions");
      if (!response.ok) throw new Error('Failed to fetch admin actions');
      return response.json();
    },
  });

  const { data: reports = [] } = useQuery<UserReport[]>({
    queryKey: ["/api/admin/reports"],
    queryFn: async () => {
      const response = await fetch("/api/admin/reports");
      if (!response.ok) throw new Error('Failed to fetch reports');
      return response.json();
    },
  });

  // Mutations for user management
  const blockUserMutation = useMutation({
    mutationFn: async ({ userId, reason }: { userId: number; reason: string }) => {
      const response = await apiRequest("POST", `/api/admin/users/${userId}/block`, { reason });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "User blocked successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
  });

  const deleteContentMutation = useMutation({
    mutationFn: async ({ type, id }: { type: string; id: number }) => {
      const response = await apiRequest("DELETE", `/api/admin/${type}/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Content deleted successfully" });
      queryClient.invalidateQueries();
    },
  });

  const filteredUsers = users.filter(user => 
    user.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!appUser?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardHeader>
            <CardTitle className="text-red-600 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Access Denied
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>You do not have administrator privileges.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <PageHeader title="Admin Dashboard" />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Admin Dashboard
          </h1>
          <p className="text-gray-600">
            Comprehensive platform management and analytics
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-8 lg:w-fit">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Users
            </TabsTrigger>
            <TabsTrigger value="content" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Content
            </TabsTrigger>
            <TabsTrigger value="categories" className="flex items-center gap-2">
              <Folder className="w-4 h-4" />
              Categories
            </TabsTrigger>
            <TabsTrigger value="feeds" className="flex items-center gap-2">
              <Rss className="w-4 h-4" />
              Feeds
            </TabsTrigger>
            <TabsTrigger value="shops" className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4" />
              Shops
            </TabsTrigger>
            <TabsTrigger value="deploy" className="flex items-center gap-2">
              <Rocket className="w-4 h-4" />
              Deploy
            </TabsTrigger>
            <TabsTrigger value="system" className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              System
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{users.length}</div>
                  <p className="text-xs text-muted-foreground">
                    {users.filter(u => u.isBlocked).length} blocked
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Content Items</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{posts.length + blogs.length + discussions.length}</div>
                  <p className="text-xs text-muted-foreground">
                    Posts, blogs, discussions
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Categories</CardTitle>
                  <Folder className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{categories.length}</div>
                  <p className="text-xs text-muted-foreground">
                    Discussion categories
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Products</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{products.length}</div>
                  <p className="text-xs text-muted-foreground">
                    Shop products
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Admin Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {actions.slice(0, 5).map((action) => (
                      <div key={action.id} className="flex items-center space-x-4">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{action.action}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(action.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Reports</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {reports.slice(0, 5).map((report) => (
                      <div key={report.id} className="flex items-center space-x-4">
                        <AlertTriangle className="w-4 h-4 text-yellow-500" />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{report.reason}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(report.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="flex items-center space-x-4">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="grid gap-4">
              {filteredUsers.map((user) => (
                <Card key={user.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Avatar>
                          <AvatarFallback>{user.name?.[0] || 'U'}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.name || 'Unknown'}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            {user.isAdmin && <Badge variant="secondary">Admin</Badge>}
                            {user.isBlocked && <Badge variant="destructive">Blocked</Badge>}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>User Details</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <Label>Name</Label>
                                <p className="text-sm">{user.name || 'Not set'}</p>
                              </div>
                              <div>
                                <Label>Email</Label>
                                <p className="text-sm">{user.email}</p>
                              </div>
                              <div>
                                <Label>Bio</Label>
                                <p className="text-sm">{user.bio || 'Not set'}</p>
                              </div>
                              <div>
                                <Label>Location</Label>
                                <p className="text-sm">{user.location || 'Not set'}</p>
                              </div>
                              <div>
                                <Label>Joined</Label>
                                <p className="text-sm">{new Date(user.createdAt).toLocaleString()}</p>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                        
                        {!user.isBlocked && (
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="destructive" size="sm">
                                <Ban className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Block User</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label>Reason for blocking</Label>
                                  <Textarea
                                    value={blockReason}
                                    onChange={(e) => setBlockReason(e.target.value)}
                                    placeholder="Enter reason..."
                                  />
                                </div>
                                <Button
                                  onClick={() => {
                                    blockUserMutation.mutate({ userId: user.id, reason: blockReason });
                                    setBlockReason("");
                                  }}
                                  disabled={!blockReason.trim()}
                                  className="w-full"
                                >
                                  Block User
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <Tabs defaultValue="posts" className="space-y-4">
              <TabsList>
                <TabsTrigger value="posts">Profile Posts ({posts.length})</TabsTrigger>
                <TabsTrigger value="blogs">Blog Posts ({blogs.length})</TabsTrigger>
                <TabsTrigger value="discussions">Discussions ({discussions.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="posts" className="space-y-4">
                {posts.map((post) => (
                  <Card key={post.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline">Profile Post</Badge>
                            <Badge variant="outline">ID: {post.id}</Badge>
                            <Badge variant="outline">User: {post.userId}</Badge>
                          </div>
                          <p className="text-sm mb-2 line-clamp-2">{post.content}</p>
                          {post.mediaUrl && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-2">
                              <Image className="w-3 h-3" />
                              Media attached
                            </div>
                          )}
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>❤️ {post.likes} likes</span>
                            <span>📤 {post.shares} shares</span>
                            <span>📅 {new Date(post.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => deleteContentMutation.mutate({ type: 'posts', id: post.id })}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="blogs" className="space-y-4">
                {blogs.map((blog) => (
                  <Card key={blog.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline">Blog Post</Badge>
                            <Badge variant="outline">ID: {blog.id}</Badge>
                            <Badge variant="outline">User: {blog.userId}</Badge>
                          </div>
                          <h3 className="font-semibold mb-1">{blog.title}</h3>
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{blog.content}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>❤️ {blog.likes} likes</span>
                            <span>📋 {blog.category}</span>
                            <span>📅 {new Date(blog.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => deleteContentMutation.mutate({ type: 'blogs', id: blog.id })}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="discussions" className="space-y-4">
                {discussions.map((discussion) => (
                  <Card key={discussion.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline">Discussion</Badge>
                            <Badge variant="outline">ID: {discussion.id}</Badge>
                          </div>
                          <h3 className="font-semibold mb-1">{discussion.title}</h3>
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{discussion.description}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>💬 {discussion.messageCount} messages</span>
                            <span>👥 {discussion.participantCount} participants</span>
                            <span>📅 {new Date(discussion.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => deleteContentMutation.mutate({ type: 'discussions', id: discussion.id })}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </TabsContent>

          {/* Other tabs with placeholder content */}
          <TabsContent value="categories">
            <Card>
              <CardHeader>
                <CardTitle>Discussion Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Categories management will be implemented here.</p>
                <div className="mt-4">
                  <Link href="/admin/categories">
                    <Button>Manage Categories</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="feeds">
            <Card>
              <CardHeader>
                <CardTitle>RSS Feeds Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p>RSS feeds and news management will be implemented here.</p>
                <div className="mt-4">
                  <Link href="/admin/feeds">
                    <Button>Manage Feeds</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="shops">
            <Card>
              <CardHeader>
                <CardTitle>Affiliate Shops</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Affiliate shops management will be implemented here.</p>
                <div className="mt-4">
                  <Link href="/admin/affiliate-shops">
                    <Button>Manage Shops</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="deploy">
            <Card>
              <CardHeader>
                <CardTitle>Deployment Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Deployment controls and monitoring will be implemented here.</p>
                <div className="mt-4">
                  <Link href="/admin/deployment">
                    <Button>Deployment Panel</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system">
            <Card>
              <CardHeader>
                <CardTitle>System Status</CardTitle>
              </CardHeader>
              <CardContent>
                <p>System monitoring and analytics will be implemented here.</p>
                <div className="mt-4 space-x-4">
                  <Link href="/admin-dashboard">
                    <Button>System Dashboard</Button>
                  </Link>
                  <Link href="/admin-analytics">
                    <Button>Analytics</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}