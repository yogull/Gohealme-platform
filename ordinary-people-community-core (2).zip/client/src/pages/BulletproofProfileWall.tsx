import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Camera, ArrowLeft, Home, Users, Share2 } from 'lucide-react';
import { Link } from 'wouter';
import { auth } from '@/lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

export default function BulletproofProfileWall() {
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [forceUpdate, setForceUpdate] = useState(0);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });
    return () => unsubscribe();
  }, []);

  const { data: users } = useQuery({
    queryKey: ['/api/users'],
    enabled: !!user,
  });

  const currentUser = users && Array.isArray(users) ? users.find((u: any) => u.firebaseUid === user?.uid) : null;
  const userId = currentUser?.id;

  // BULLETPROOF image upload that guarantees display
  const uploadImage = async (target: 'profile' | 'cover') => {
    console.log(`🚀 BULLETPROOF ${target} upload starting...`);
    
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    
    fileInput.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      
      console.log('📁 File selected:', file.name);
      
      try {
        const reader = new FileReader();
        reader.onload = async (e) => {
          const imageData = e.target?.result as string;
          const fileName = `${target}_${userId}_${Date.now()}.jpg`;
          
          console.log('☁️ Uploading to server...');
          
          // Direct fetch to upload endpoint
          const response = await fetch('/api/files/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileName,
              fileData: imageData,
              userId: userId
            })
          });
          
          const uploadResponse = await response.json();
          const imageUrl = `/api/files/${uploadResponse.id}`;
          console.log('✅ Upload complete! URL:', imageUrl);
          
          // NUCLEAR OPTION: Update ALL possible image elements immediately
          if (target === 'profile') {
            // Update profile images
            document.querySelectorAll('img[alt*="Profile"], .profile-image, [data-profile-image]').forEach((img: any) => {
              img.src = imageUrl;
              img.style.display = 'block';
              console.log('🖼️ Updated profile image element');
            });
            
            // Update profile containers with background images
            document.querySelectorAll('.profile-container, .profile-avatar').forEach((container: any) => {
              container.style.backgroundImage = `url(${imageUrl})`;
              container.style.backgroundSize = 'cover';
              container.style.backgroundPosition = 'center';
            });
            
            toast({ title: "✅ Profile image uploaded and visible!" });
          } else {
            // Update cover images
            document.querySelectorAll('.cover-image, [data-cover-image], .cover-container').forEach((element: any) => {
              element.style.backgroundImage = `url(${imageUrl})`;
              element.style.backgroundSize = 'cover';
              element.style.backgroundPosition = 'center';
              console.log('🖼️ Updated cover image element');
            });
            
            toast({ title: "✅ Cover image uploaded and visible!" });
          }
          
          // Force React re-render
          setForceUpdate(prev => prev + 1);
          
          // Guaranteed display: Page refresh after 500ms
          console.log('🔄 Forcing page refresh in 500ms for guaranteed display...');
          setTimeout(() => {
            window.location.reload();
          }, 500);
        };
        
        reader.readAsDataURL(file);
      } catch (error) {
        console.error('❌ Upload failed:', error);
        toast({ title: "Upload failed", variant: "destructive" });
      }
    };
    
    fileInput.click();
  };

  if (!currentUser) {
    return <div className="p-4">Loading profile...</div>;
  }

  return (
    <div className="min-h-screen bg-white" key={`profile-${forceUpdate}`}>
      {/* Navigation Buttons */}
      <div className="max-w-4xl mx-auto pt-4 px-4">
        <div className="flex flex-wrap justify-center gap-3 mb-4">
          <Link href="/dashboard">
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
          <Link href="/dashboard">
            <Button variant="outline" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              Dashboard
            </Button>
          </Link>
          <Link href="/social">
            <Button className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2">
              <Users className="h-4 w-4" />
              Social
            </Button>
          </Link>
        </div>
      </div>

      {/* Cover Image Upload Button */}
      <div className="max-w-4xl mx-auto mb-2 px-4">
        <div className="flex justify-end">
          <Button
            size="sm"
            onClick={() => uploadImage('cover')}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Camera className="h-4 w-4 mr-2" />
            Edit Cover Photo
          </Button>
        </div>
      </div>

      {/* Cover Image Section */}
      <div className="relative mb-16">
        <div 
          className="h-48 bg-gradient-to-r from-blue-400 to-purple-500 rounded-lg overflow-hidden relative cursor-pointer cover-container"
          onClick={() => uploadImage('cover')}
          data-cover-image="true"
        >
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-white text-center">
              <Camera className="h-12 w-12 mx-auto mb-2 opacity-75" />
              <p className="text-lg font-medium">Add Cover Photo</p>
              <p className="text-sm opacity-75">Click to upload</p>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Picture Section */}
      <div className="max-w-4xl mx-auto -mt-12 mb-6 pl-6">
        <div className="relative inline-block">
          <div 
            className="w-24 h-24 rounded-full bg-gray-300 border-4 border-white overflow-hidden cursor-pointer shadow-lg profile-container"
            onClick={() => uploadImage('profile')}
          >
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-400 to-purple-500">
              <span className="text-white text-2xl font-bold">J</span>
            </div>
          </div>
          
          <Button
            size="sm"
            onClick={() => uploadImage('profile')}
            className="absolute -bottom-2 -right-2 w-6 h-6 rounded-full p-0 bg-blue-600 hover:bg-blue-700"
          >
            <Camera className="h-3 w-3" />
          </Button>
        </div>
        
        <div className="mt-4">
          <h1 className="text-2xl font-bold text-gray-900">{currentUser.name || 'User'}</h1>
          <p className="text-gray-600">{currentUser.bio || 'Welcome to my profile!'}</p>
        </div>
      </div>

      {/* Share Button */}
      <div className="max-w-4xl mx-auto px-4 mb-8">
        <div className="flex justify-center">
          <Button
            onClick={() => {
              const url = window.location.href;
              const text = `Check out ${currentUser.name}'s profile on Ordinary People Community!`;
              if (navigator.share) {
                navigator.share({ title: 'OPC Profile', text, url });
              } else {
                navigator.clipboard.writeText(`${text} ${url}`);
                toast({ title: "Link Copied!", description: "Profile link copied to clipboard" });
              }
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2"
          >
            <Share2 className="h-4 w-4 mr-2" />
            Share Profile
          </Button>
        </div>
      </div>

      {/* Posts Section */}
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
          <div className="text-gray-500 text-center py-8">
            <p>No posts yet. Start sharing your thoughts with the community!</p>
          </div>
        </div>
      </div>
    </div>
  );
}