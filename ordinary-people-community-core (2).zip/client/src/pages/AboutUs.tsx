import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/PageHeader";
import { SEO } from "@/components/SEO";
import { PageHelpSystem } from "@/components/PageHelpSystem";
import { Heart, Users, Brain, Shield, Smartphone, Globe, MapPin, Mail, MessageCircle, Share2, Facebook, Twitter, Linkedin, Send, ShoppingCart, Camera, MessageSquare, Dumbbell, Bot, Rss, Building2, Search, Zap, Star, TrendingUp, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

export default function AboutUs() {
  const { toast } = useToast();
  const { appUser } = useAuth();

  const shareContent = {
    title: "Ordinary People Community - Revolutionary Social Platform",
    text: "Join the ultimate social platform: Multi-share to 20+ platforms, Personal Affiliate Shops (£1/link), AI assistance, RSS feeds worldwide, exercise tracking, automated social invites, and comprehensive business directory. Real people, real discussions.",
    url: `${window.location.origin}/about`
  };

  const handlePostToAll = async () => {
    if (!appUser) {
      toast({
        title: "Login Required",
        description: "Please sign in to post to your social media platforms.",
        variant: "destructive",
      });
      return;
    }

    const platforms = ['facebook', 'twitter', 'linkedin', 'whatsapp', 'telegram'];
    let openedWindows = 0;

    platforms.forEach(platform => {
      let shareUrl = "";
      const encodedUrl = encodeURIComponent(shareContent.url);
      const encodedTitle = encodeURIComponent(shareContent.title);
      const encodedText = encodeURIComponent(shareContent.text);

      switch (platform) {
        case 'facebook':
          shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedText}`;
          break;
        case 'twitter':
          shareUrl = `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedText}`;
          break;
        case 'linkedin':
          shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}&title=${encodedTitle}&summary=${encodedText}`;
          break;
        case 'whatsapp':
          shareUrl = `https://wa.me/?text=${encodedText}%20${encodedUrl}`;
          break;
        case 'telegram':
          shareUrl = `https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`;
          break;
      }
      
      if (shareUrl) {
        setTimeout(() => {
          window.open(shareUrl, '_blank', 'width=600,height=400');
        }, openedWindows * 500);
        openedWindows++;
      }
    });

    toast({
      title: "Opening Social Media Posts",
      description: `Launching ${openedWindows} social media platforms for posting`,
    });
  };

  const handleShare = async (platform?: string) => {
    if (platform) {
      let shareUrl = "";
      const encodedUrl = encodeURIComponent(shareContent.url);
      const encodedTitle = encodeURIComponent(shareContent.title);
      const encodedText = encodeURIComponent(shareContent.text);

      switch (platform) {
        case 'facebook':
          shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
          break;
        case 'twitter':
          shareUrl = `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedText}`;
          break;
        case 'linkedin':
          shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`;
          break;
      }
      
      if (shareUrl) {
        window.open(shareUrl, '_blank', 'width=600,height=400');
        return;
      }
    }

    if (navigator.share) {
      try {
        await navigator.share(shareContent);
      } catch (error) {
        console.log('Native sharing cancelled');
      }
    } else {
      navigator.clipboard.writeText(`${shareContent.title}\n\n${shareContent.text}\n\n${shareContent.url}`);
      toast({
        title: "Copied to Clipboard",
        description: "Share content copied to clipboard for easy sharing",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <SEO 
        title="Ordinary People Community - Revolutionary Social Platform" 
        description="The ultimate social platform: Multi-share to 20+ platforms, Personal Affiliate Shops (£1/link), AI assistance, worldwide RSS feeds, exercise tracking, automated social invites, and comprehensive business directory."
        keywords={["social platform", "multi-share", "affiliate shops", "AI assistant", "RSS feeds", "exercise tracking", "business directory", "automated invites"]}
      />
      
      <PageHeader 
        title="Ordinary People Community" 
        description="Revolutionary Social Platform - Everything You Need in One Place"
      />
      
      <PageHelpSystem 
        helpContent="Complete platform overview showcasing revolutionary features: Multi-platform sharing to 20+ social networks, Personal Affiliate Shops earning £1 per link, universal AI assistance, worldwide RSS feeds, comprehensive exercise tracking, automated social media invitations, and global business directory. Perfect for marketing and sharing with potential users."
      />

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <Card className="mb-8 border-2 border-primary">
          <CardHeader className="text-center bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
            <CardTitle className="text-4xl mb-4">
              🚀 Revolutionary Social Platform
            </CardTitle>
            <CardDescription className="text-xl text-blue-100">
              Multi-Share • Affiliate Shops • AI Assistant • Global RSS • Exercise Tracking • Auto Invites
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="text-center mb-6">
              <p className="text-lg text-gray-700 leading-relaxed mb-4">
                The most comprehensive social platform ever created - combining Facebook-style feeds, multi-platform sharing to 20+ networks, personal affiliate shops, AI assistance, worldwide news feeds, exercise tracking, and automated social media invitations.
              </p>
              <div className="flex flex-wrap justify-center gap-2 mb-4">
                <Badge variant="secondary" className="text-sm">20+ Social Platforms</Badge>
                <Badge variant="secondary" className="text-sm">£1 Per Affiliate Link</Badge>
                <Badge variant="secondary" className="text-sm">AI Assistant</Badge>
                <Badge variant="secondary" className="text-sm">Global RSS Feeds</Badge>
                <Badge variant="secondary" className="text-sm">Exercise Tracking</Badge>
                <Badge variant="secondary" className="text-sm">Auto Invitations</Badge>
              </div>
            </div>
            
            {/* Share Buttons */}
            <div className="flex flex-wrap gap-2 justify-center mb-6">
              <Button 
                onClick={() => handleShare('facebook')}
                variant="outline" 
                size="sm"
                className="flex items-center gap-2"
              >
                <Facebook className="w-4 h-4" />
                Facebook
              </Button>
              <Button 
                onClick={() => handleShare('twitter')}
                variant="outline" 
                size="sm"
                className="flex items-center gap-2"
              >
                <Twitter className="w-4 h-4" />
                Twitter
              </Button>
              <Button 
                onClick={() => handleShare('linkedin')}
                variant="outline" 
                size="sm"
                className="flex items-center gap-2"
              >
                <Linkedin className="w-4 h-4" />
                LinkedIn
              </Button>
              <Button 
                onClick={handlePostToAll}
                className="flex items-center gap-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
              >
                <Send className="w-4 h-4" />
                Share to ALL Platforms
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Revolutionary Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Multi-Platform Sharing */}
          <Card className="border-2 border-green-200 hover:border-green-400 transition-colors">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Share2 className="w-8 h-8 text-green-600" />
                <div>
                  <CardTitle className="text-lg">Multi-Platform Sharing</CardTitle>
                  <Badge variant="outline" className="text-xs">REVOLUTIONARY</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">
                Share to 20+ social platforms simultaneously: Facebook, Twitter, Instagram, LinkedIn, TikTok, Snapchat, Discord, Reddit, Pinterest, Tumblr, Twitch, Spotify, Medium, GitHub, and more.
              </p>
              <div className="flex flex-wrap gap-1">
                <Badge variant="secondary" className="text-xs">Facebook</Badge>
                <Badge variant="secondary" className="text-xs">Twitter</Badge>
                <Badge variant="secondary" className="text-xs">Instagram</Badge>
                <Badge variant="secondary" className="text-xs">LinkedIn</Badge>
                <Badge variant="secondary" className="text-xs">TikTok</Badge>
                <Badge variant="secondary" className="text-xs">+15 More</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Personal Affiliate Shops */}
          <Card className="border-2 border-yellow-200 hover:border-yellow-400 transition-colors">
            <CardHeader>
              <div className="flex items-center gap-3">
                <DollarSign className="w-8 h-8 text-yellow-600" />
                <div>
                  <CardTitle className="text-lg">Affiliate Shops</CardTitle>
                  <Badge variant="outline" className="text-xs">MONEY MAKER</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">
                Create personal affiliate shops and earn £1 per affiliate link for the first 20 links, then £2/month maintenance for additional links. Connect Amazon, eBay, and other affiliate programs.
              </p>
              <div className="flex items-center gap-2 text-green-600 font-semibold">
                <Star className="w-4 h-4" />
                <span>£1 per link • £2/month after 20</span>
              </div>
            </CardContent>
          </Card>

          {/* AI Assistant */}
          <Card className="border-2 border-blue-200 hover:border-blue-400 transition-colors">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Bot className="w-8 h-8 text-blue-600" />
                <div>
                  <CardTitle className="text-lg">Universal AI Assistant</CardTitle>
                  <Badge variant="outline" className="text-xs">GPT-4 POWERED</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">
                Ask AI anything on every page - health advice, science questions, general knowledge like "How far is the Moon?". Comprehensive responses with medical disclaimers for health topics.
              </p>
              <div className="text-blue-600 font-medium text-sm">
                Available on every page across the platform
              </div>
            </CardContent>
          </Card>

          {/* RSS Feeds */}
          <Card className="border-2 border-purple-200 hover:border-purple-400 transition-colors">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Rss className="w-8 h-8 text-purple-600" />
                <div>
                  <CardTitle className="text-lg">Worldwide RSS Feeds</CardTitle>
                  <Badge variant="outline" className="text-xs">GLOBAL NEWS</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">
                Automated news posting from 60+ international sources: BBC, CNN, Al Jazeera, Xinhua, NHK World, Le Monde, Der Spiegel, Times of India, and sources from every continent.
              </p>
              <div className="flex flex-wrap gap-1">
                <Badge variant="secondary" className="text-xs">60+ Sources</Badge>
                <Badge variant="secondary" className="text-xs">Global Coverage</Badge>
                <Badge variant="secondary" className="text-xs">Auto-Posted</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Exercise Tracking */}
          <Card className="border-2 border-red-200 hover:border-red-400 transition-colors">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Dumbbell className="w-8 h-8 text-red-600" />
                <div>
                  <CardTitle className="text-lg">Exercise Tracking</CardTitle>
                  <Badge variant="outline" className="text-xs">HEALTH FOCUS</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">
                Comprehensive fitness tracking with supplement logging, biometric data, step counting, sleep tracking, weight management, and health metric visualization with charts.
              </p>
              <div className="flex items-center gap-2 text-red-600 font-medium">
                <Heart className="w-4 h-4" />
                <span>Complete Health Dashboard</span>
              </div>
            </CardContent>
          </Card>

          {/* Auto Social Invites */}
          <Card className="border-2 border-indigo-200 hover:border-indigo-400 transition-colors">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Users className="w-8 h-8 text-indigo-600" />
                <div>
                  <CardTitle className="text-lg">Auto Social Invites</CardTitle>
                  <Badge variant="outline" className="text-xs">GROWTH ENGINE</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">
                Automated friend invitations across Instagram, LinkedIn, Telegram, Facebook, and Twitter. System sends personalized invites to grow your network automatically.
              </p>
              <div className="flex items-center gap-2 text-indigo-600 font-medium">
                <Zap className="w-4 h-4" />
                <span>Automated Network Growth</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Additional Features */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Business Directory */}
          <Card className="border-2 border-emerald-200">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Building2 className="w-8 h-8 text-emerald-600" />
                <CardTitle className="text-xl">Global Business Directory</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Comprehensive business directory with 241 businesses across 43 countries. Location-based search, interactive maps, contact integration, and advertising opportunities for £24/year.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge>241 Businesses</Badge>
                <Badge>43 Countries</Badge>
                <Badge>Location Search</Badge>
                <Badge>£24/Year Ads</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Facebook-Style Features */}
          <Card className="border-2 border-pink-200">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Camera className="w-8 h-8 text-pink-600" />
                <CardTitle className="text-xl">Facebook-Style Social</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Profile walls with cover photos, image cropping, photo/video galleries, like/comment/share functionality, and universal Facebook-style feeds across all content areas.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge>Profile Walls</Badge>
                <Badge>Image Cropping</Badge>
                <Badge>Video Galleries</Badge>
                <Badge>Social Feeds</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Marketing CTA */}
        <Card className="border-4 border-gradient-to-r from-green-400 to-blue-500 bg-gradient-to-r from-green-50 to-blue-50">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl text-gray-800">
              🎯 Perfect for Marketing & Business Growth
            </CardTitle>
            <CardDescription className="text-lg">
              Everything you need to build your online presence and monetize your content
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <div className="bg-white p-4 rounded-lg shadow">
                <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <h4 className="font-semibold">Grow Your Network</h4>
                <p className="text-sm text-gray-600">Automated invitations across all platforms</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <DollarSign className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                <h4 className="font-semibold">Monetize Content</h4>
                <p className="text-sm text-gray-600">Affiliate shops with £1 per link earnings</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <Globe className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <h4 className="font-semibold">Global Reach</h4>
                <p className="text-sm text-gray-600">Share to 20+ platforms simultaneously</p>
              </div>
            </div>
            
            <Button 
              onClick={handlePostToAll}
              size="lg"
              className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white text-lg px-8 py-3"
            >
              <Send className="w-5 h-5 mr-2" />
              Share This Revolutionary Platform
            </Button>
          </CardContent>
        </Card>

        {/* Instructions Section */}
        <Card className="mt-8 border-2 border-gray-300">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <MessageSquare className="w-8 h-8 text-gray-600" />
              Platform Instructions & Features Guide
            </CardTitle>
            <CardDescription>
              Comprehensive guide to using all platform features - perfect for sharing and onboarding
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2">🚀 Getting Started</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Create account with email verification</li>
                  <li>• Set up Profile Wall with cover photo</li>
                  <li>• Connect social media accounts for multi-sharing</li>
                  <li>• Create Personal Affiliate Shop for earnings</li>
                  <li>• Join community discussions and RSS feeds</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">💰 Monetization Features</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Personal Affiliate Shops: £1 per link (first 20)</li>
                  <li>• Business advertising: £24/year with carousel ads</li>
                  <li>• Location-based business listings</li>
                  <li>• Dedicated storefronts with Stripe payments</li>
                  <li>• Affiliate link tracking and management</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">🌐 Social Features</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Multi-share to 20+ platforms simultaneously</li>
                  <li>• Facebook-style feeds with like/comment/share</li>
                  <li>• Photo/video galleries with cropping tools</li>
                  <li>• Automated social media friend invitations</li>
                  <li>• Universal AI assistant on every page</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">📊 Health & Tracking</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Comprehensive exercise and fitness tracking</li>
                  <li>• Supplement logging with dosage management</li>
                  <li>• Biometric data with charts and trends</li>
                  <li>• Health condition guides and support</li>
                  <li>• AI health assistance with medical disclaimers</li>
                </ul>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-blue-800 mb-2">🎯 Perfect for Marketing Teams</h4>
              <p className="text-blue-700 text-sm">
                This comprehensive feature set makes Ordinary People Community ideal for businesses, influencers, and individuals looking to maximize their online presence. The combination of multi-platform sharing, affiliate earnings, automated networking, and comprehensive content management tools provides everything needed for successful digital marketing and community building.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}