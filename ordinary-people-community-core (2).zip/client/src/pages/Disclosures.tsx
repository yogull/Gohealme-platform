import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Shield, Users, Store, MessageSquare, Scale } from "lucide-react";

export default function Disclosures() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Platform Disclosures & Legal Notices</h1>
          <p className="text-lg text-gray-600">
            Important information about platform usage, user content, and business activities
          </p>
        </div>

        {/* Platform Liability Disclaimer */}
        <Card className="mb-6 border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-800">
              <Shield className="w-5 h-5" />
              Platform Liability Disclaimer
            </CardTitle>
          </CardHeader>
          <CardContent className="text-red-700">
            <div className="space-y-4">
              <p className="font-semibold">
                IMPORTANT: This platform operates as a neutral technology service provider and assumes NO LIABILITY for user-generated content, business activities, or transactions.
              </p>
              <ul className="list-disc list-inside space-y-2">
                <li>The platform does not endorse, verify, or guarantee any user content, products, services, or business claims</li>
                <li>All user interactions, purchases, and business dealings are conducted at users' own risk</li>
                <li>Platform operators are not responsible for disputes, damages, or losses arising from user activities</li>
                <li>Users agree to indemnify and hold harmless the platform from any claims related to their content or activities</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* User Content Disclaimer */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              User-Generated Content
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                <h3 className="font-semibold text-yellow-800 mb-2">Content Responsibility</h3>
                <p className="text-yellow-700">
                  All posts, comments, discussions, and shared content represent the personal views and opinions of individual users, not the platform.
                </p>
              </div>
              <ul className="space-y-2">
                <li><strong>User Ownership:</strong> Users retain full responsibility for all content they create, share, or post</li>
                <li><strong>No Editorial Control:</strong> The platform does not edit, verify, or fact-check user content</li>
                <li><strong>Diverse Opinions:</strong> Content may include varied viewpoints that do not reflect platform positions</li>
                <li><strong>Health Information:</strong> Health-related discussions are for informational purposes only, not medical advice</li>
                <li><strong>Political Content:</strong> Political opinions expressed are personal views of individual users</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Business Activities Disclaimer */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Store className="w-5 h-5" />
              Business Activities & Advertisements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-blue-800 mb-2">Independent Business Operations</h3>
                <p className="text-blue-700">
                  All businesses, shops, and advertisers operate independently. The platform serves only as a listing service.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Business Listings</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Businesses pay listing fees only</li>
                    <li>• No endorsement or quality guarantee</li>
                    <li>• Direct customer-business relationships</li>
                    <li>• Platform not party to transactions</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Personal Shops</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Individual user-operated stores</li>
                    <li>• Affiliate links and personal products</li>
                    <li>• No platform quality control</li>
                    <li>• Buyer-seller direct responsibility</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Legal Protection Statement */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Scale className="w-5 h-5" />
              Legal Protection & User Agreement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-gray-100 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">By Using This Platform, You Agree:</h3>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li>To use the platform at your own risk and discretion</li>
                  <li>That platform operators are not liable for user content or business activities</li>
                  <li>To verify all information and conduct due diligence before transactions</li>
                  <li>To resolve disputes directly with other users or businesses</li>
                  <li>To indemnify the platform against claims arising from your activities</li>
                  <li>That health discussions are not professional medical advice</li>
                  <li>That business listings are advertising only, not recommendations</li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Communication Services Disclaimer */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Communication Services
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p><strong>WhatsApp & Messenger Integration:</strong></p>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>External communication services provided by third parties (Meta/WhatsApp)</li>
                <li>Platform provides links/integration only - not responsible for service functionality</li>
                <li>Users responsible for their own communications and privacy settings</li>
                <li>All calls, messages, and interactions subject to third-party terms of service</li>
                <li>Platform cannot guarantee availability or security of external communication services</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Final Warning */}
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-red-600 mt-1 flex-shrink-0" />
              <div className="text-red-800">
                <h3 className="font-bold mb-2">IMPORTANT FINAL NOTICE</h3>
                <p className="text-sm">
                  This platform operates as a technology service only. We do not validate, endorse, or guarantee any user content, 
                  business offerings, health advice, or commercial transactions. Users engage with all content and services entirely 
                  at their own risk and must exercise proper judgment and due diligence. By continuing to use this platform, 
                  you acknowledge and accept full responsibility for your interactions and agree to hold the platform harmless 
                  from any disputes, damages, or legal issues that may arise.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <div className="text-center mt-8 text-sm text-gray-600">
          <p>For questions about these disclosures, contact: gohealme.org@gmail.com</p>
          <p className="mt-2">Last updated: June 29, 2025</p>
        </div>
      </div>
    </div>
  );
}