import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plus, Package, ExternalLink, Edit, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const CATEGORIES = [
  "Electronics",
  "Health & Wellness", 
  "Fashion",
  "Home & Garden",
  "Sports & Fitness",
  "Beauty & Personal Care",
  "Books & Media",
  "Automotive",
  "Food & Beverages",
  "Toys & Games"
];

interface AffiliateLink {
  id: number;
  shopId: number;
  title: string;
  description?: string;
  affiliateUrl: string;
  price?: string;
  category: string;
  brand?: string;
  productImageUrl?: string;
  createdAt: string;
}

export default function PersonalShopManage() {
  const { shopId } = useParams();
  const [, setLocation] = useLocation();
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<AffiliateLink | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    affiliateUrl: "",
    price: "",
    category: "",
    brand: "",
    productImageUrl: ""
  });

  // Fetch shop details
  const { data: shop } = useQuery({
    queryKey: [`/api/personal-shops/${shopId}`],
    enabled: !!shopId,
  });

  // Fetch affiliate products
  const { data: affiliateLinks, isLoading } = useQuery({
    queryKey: [`/api/personal-shops/${shopId}/affiliate-links`],
    enabled: !!shopId,
  });

  // Add/Edit product mutation
  const addProductMutation = useMutation({
    mutationFn: async (data: any) => {
      const url = editingProduct 
        ? `/api/affiliate-products/${editingProduct.id}`
        : `/api/personal-shops/${shopId}/affiliate-products`;
      
      const response = await fetch(url, {
        method: editingProduct ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to save product');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: editingProduct ? "Product Updated!" : "Product Added!",
        description: editingProduct ? "Your affiliate product has been updated successfully." : "Your affiliate product has been added successfully. Start earning commissions!",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/personal-shops/${shopId}/affiliate-links`] });
      setShowAddProduct(false);
      setEditingProduct(null);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save product. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Delete product mutation
  const deleteProductMutation = useMutation({
    mutationFn: async (productId: number) => {
      const response = await fetch(`/api/affiliate-products/${productId}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete product');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Product Deleted",
        description: "Affiliate product has been removed from your shop.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/personal-shops/${shopId}/affiliate-links`] });
    }
  });

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      affiliateUrl: "",
      price: "",
      category: "",
      brand: "",
      productImageUrl: ""
    });
  };

  const handleAddProduct = () => {
    setEditingProduct(null);
    resetForm();
    setShowAddProduct(true);
  };

  const handleEditProduct = (product: AffiliateLink) => {
    setEditingProduct(product);
    setFormData({
      title: product.title,
      description: product.description || "",
      affiliateUrl: product.affiliateUrl,
      price: product.price || "",
      category: product.category,
      brand: product.brand || "",
      productImageUrl: product.productImageUrl || ""
    });
    setShowAddProduct(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.affiliateUrl || !formData.category) {
      toast({
        title: "Missing Information",
        description: "Please fill in the title, affiliate link, and category.",
        variant: "destructive",
      });
      return;
    }
    addProductMutation.mutate(formData);
  };

  const categories = [
    "Health & Supplements",
    "Electronics",
    "Books & Education", 
    "Fitness & Sports",
    "Home & Garden",
    "Fashion & Beauty",
    "Food & Beverages",
    "Travel & Lifestyle",
    "Business & Finance",
    "Arts & Crafts"
  ];

  if (!shop || (shop as any).userId !== appUser?.id) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="text-center p-6">
            <Package className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600 mb-4">You can only manage your own shop.</p>
            <Button onClick={() => setLocation('/profile-wall')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Go Back
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => setLocation(`/personal-shop-view/${shopId}`)}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Shop
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Manage {(shop as any).shopName}</h1>
              <p className="text-gray-600">Add and manage your affiliate products</p>
            </div>
          </div>
          <Button
            onClick={handleAddProduct}
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Product
          </Button>
        </div>

        {/* Getting Started Card */}
        <Card className="mb-6 border-green-200 bg-green-50">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-3 text-green-800">💰 Start Making Money Today!</h3>
            <div className="grid md:grid-cols-3 gap-4 text-sm">
              <div>
                <strong>Step 1:</strong> Get affiliate links from Amazon, eBay, or any online store
              </div>
              <div>
                <strong>Step 2:</strong> Add products here with your affiliate links
              </div>
              <div>
                <strong>Step 3:</strong> Share to your Profile Wall and earn commissions when people buy!
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Products Grid */}
        {isLoading ? (
          <div className="text-center py-8">
            <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full mx-auto" />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 auto-rows-fr">
            {(affiliateLinks as any[])?.map((product: AffiliateLink) => (
              <Card key={product.id} className="flex flex-col hover:shadow-lg transition-shadow h-full">
                <CardHeader className="pb-3 flex-1">
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="outline" className="text-xs">
                      {product.category}
                    </Badge>
                    <div className="flex gap-1">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleEditProduct(product)}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => deleteProductMutation.mutate(product.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  {product.productImageUrl ? (
                    <div className="w-full h-40 bg-gray-100 rounded-lg overflow-hidden mb-3">
                      <img 
                        src={product.productImageUrl} 
                        alt={product.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="w-full h-40 bg-gray-100 rounded-lg flex items-center justify-center mb-3">
                      <Package className="w-8 h-8 text-gray-400" />
                    </div>
                  )}
                  <CardTitle className="text-base line-clamp-2 mb-2">{product.title}</CardTitle>
                  <div className="space-y-2 flex-1">
                    {product.description && (
                      <p className="text-gray-600 text-sm line-clamp-2">{product.description}</p>
                    )}
                    {product.price && (
                      <p className="text-lg font-bold text-green-600">{product.price}</p>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="pt-0 mt-auto">
                  <Button 
                    className="w-full bg-purple-600 hover:bg-purple-700"
                    onClick={() => window.open(product.affiliateUrl, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Test Affiliate Link
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Empty State */}
        {(affiliateLinks as any[])?.length === 0 && (
          <Card className="text-center p-12">
            <Package className="w-20 h-20 mx-auto text-gray-400 mb-6" />
            <h3 className="text-2xl font-semibold mb-4">Ready to Start Earning?</h3>
            <p className="text-gray-600 mb-6 max-w-md mx-auto">
              Add your first affiliate product and start making money from your recommendations!
            </p>
            <Button 
              onClick={handleAddProduct}
              className="bg-green-600 hover:bg-green-700 text-white font-bold px-8 py-3"
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Your First Product
            </Button>
          </Card>
        )}
      </div>

      {/* Add/Edit Product Dialog */}
      <Dialog open={showAddProduct} onOpenChange={setShowAddProduct}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? "Edit Product" : "Add New Affiliate Product"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="title">Product Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                placeholder="e.g., Amazing Health Supplement"
                required
              />
            </div>

            <div>
              <Label htmlFor="affiliateUrl">Your Affiliate Link *</Label>
              <Input
                id="affiliateUrl"
                type="url"
                value={formData.affiliateUrl}
                onChange={(e) => setFormData({...formData, affiliateUrl: e.target.value})}
                placeholder="https://amazon.com/dp/B123456?tag=yourID"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                This is where you earn money! Paste your affiliate link from Amazon, eBay, etc.
              </p>
            </div>

            <div>
              <Label htmlFor="category">Category *</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="price">Price (optional)</Label>
                <Input
                  id="price"
                  value={formData.price}
                  onChange={(e) => setFormData({...formData, price: e.target.value})}
                  placeholder="£29.99"
                />
              </div>
              <div>
                <Label htmlFor="brand">Brand (optional)</Label>
                <Input
                  id="brand"
                  value={formData.brand}
                  onChange={(e) => setFormData({...formData, brand: e.target.value})}
                  placeholder="Brand name"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="productImageUrl">Product Image URL (optional)</Label>
              <Input
                id="productImageUrl"
                type="url"
                value={formData.productImageUrl}
                onChange={(e) => setFormData({...formData, productImageUrl: e.target.value})}
                placeholder="https://example.com/product-image.jpg"
              />
            </div>

            <div>
              <Label htmlFor="description">Description (optional)</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Why do you recommend this product? Share your honest review..."
                rows={3}
              />
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={() => setShowAddProduct(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={addProductMutation.isPending}
                className="bg-green-600 hover:bg-green-700"
              >
                {addProductMutation.isPending ? "Saving..." : editingProduct ? "Update Product" : "Add Product"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}