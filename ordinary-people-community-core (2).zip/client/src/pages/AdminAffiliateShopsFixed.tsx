import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { ArrowLeft } from "lucide-react";
import { Plus, Trash2, User, Store } from "lucide-react";

interface User {
  id: number;
  name: string;
  email: string;
  isAdmin: boolean;
}

interface PersonalShop {
  id: number;
  userId: number;
  shopName: string;
  description: string;
  category: string;
  user?: {
    name: string;
    email: string;
  };
}

interface CreateShopData {
  userId: number;
  shopName: string;
  description: string;
  category: string;
}

export default function AdminAffiliateShopsFixed() {
  // All hooks called unconditionally at top level
  const { appUser } = useAuth();
  const { toast } = useToast();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [newShop, setNewShop] = useState({
    shopName: "",
    description: "",
    category: "Health & Wellness"
  });

  // Fetch all users for shop creation
  const { data: users = [] } = useQuery({
    queryKey: ["/api/admin/users"],
    staleTime: 5 * 60 * 1000,
    enabled: !!appUser?.isAdmin,
  });

  // Fetch all affiliate shops
  const { data: shops = [], isLoading } = useQuery<PersonalShop[]>({
    queryKey: ["/api/admin/affiliate-shops"],
    staleTime: 2 * 60 * 1000,
    enabled: !!appUser?.isAdmin,
  });

  // Create shop mutation
  const createShopMutation = useMutation({
    mutationFn: async (shopData: CreateShopData) => {
      return await apiRequest("POST", "/api/admin/affiliate-shops", shopData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/affiliate-shops"] });
      setShowCreateDialog(false);
      setNewShop({ shopName: "", description: "", category: "Health & Wellness" });
      setSelectedUserId(null);
      toast({
        title: "Success",
        description: "Affiliate shop created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create affiliate shop",
        variant: "destructive",
      });
    },
  });

  // Delete shop mutation
  const deleteShopMutation = useMutation({
    mutationFn: async (shopId: number) => {
      return await apiRequest("DELETE", `/api/admin/affiliate-shops/${shopId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/affiliate-shops"] });
      toast({
        title: "Success",
        description: "Affiliate shop deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete affiliate shop",
        variant: "destructive",
      });
    },
  });

  // Check admin access - conditional render after all hooks
  if (!appUser?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-bold text-red-600 mb-2">Access Denied</h2>
            <p className="text-gray-600">You need admin privileges to access this page.</p>
            <Button variant="outline" onClick={() => window.history.back()} className="mt-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleCreateShop = () => {
    if (!selectedUserId || !newShop.shopName.trim()) {
      toast({
        title: "Error",
        description: "Please select a user and enter a shop name",
        variant: "destructive",
      });
      return;
    }

    createShopMutation.mutate({
      userId: selectedUserId,
      shopName: newShop.shopName.trim(),
      description: newShop.description.trim(),
      category: newShop.category,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => window.history.back()}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Affiliate Shop Management</h1>
              <p className="text-gray-600">Create and manage user affiliate shops</p>
            </div>
          </div>
          
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Create Shop
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Affiliate Shop</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="user-select">Select User</Label>
                  <Select value={selectedUserId?.toString() || ""} onValueChange={(value) => setSelectedUserId(Number(value))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a user..." />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map((user: any) => (
                        <SelectItem key={user.id} value={user.id.toString()}>
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4" />
                            {user.name} ({user.email})
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="shop-name">Shop Name</Label>
                  <Input
                    id="shop-name"
                    value={newShop.shopName}
                    onChange={(e) => setNewShop(prev => ({ ...prev, shopName: e.target.value }))}
                    placeholder="Enter shop name..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newShop.description}
                    onChange={(e) => setNewShop(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Shop description..."
                    rows={3}
                  />
                </div>
                
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select value={newShop.category} onValueChange={(value) => setNewShop(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Health & Wellness">Health & Wellness</SelectItem>
                      <SelectItem value="Technology">Technology</SelectItem>
                      <SelectItem value="Fashion">Fashion</SelectItem>
                      <SelectItem value="Home & Garden">Home & Garden</SelectItem>
                      <SelectItem value="Sports & Fitness">Sports & Fitness</SelectItem>
                      <SelectItem value="Books & Media">Books & Media</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex gap-2 pt-4">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => setShowCreateDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    onClick={handleCreateShop}
                    disabled={createShopMutation.isPending}
                  >
                    {createShopMutation.isPending ? "Creating..." : "Create Shop"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-2 text-gray-600">Loading affiliate shops...</p>
          </div>
        ) : (
          <div className="grid gap-4 grid-cols-1 max-w-2xl mx-auto">
            {shops.map((shop) => (
              <Card key={shop.id} className="bg-white shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Store className="w-5 h-5 text-blue-600" />
                      <CardTitle className="text-lg">{shop.shopName}</CardTitle>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteShopMutation.mutate(shop.id)}
                      disabled={deleteShopMutation.isPending}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-sm font-medium text-gray-700">Owner</p>
                    <p className="text-sm text-gray-600">{shop.user?.name || `User ${shop.userId}`}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-gray-700">Category</p>
                    <p className="text-sm text-gray-600">{shop.category}</p>
                  </div>
                  
                  {shop.description && (
                    <div>
                      <p className="text-sm font-medium text-gray-700">Description</p>
                      <p className="text-sm text-gray-600 line-clamp-2">{shop.description}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!isLoading && shops.length === 0 && (
          <div className="text-center py-8 px-4">
            <Store className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Affiliate Shops</h3>
            <p className="text-gray-600 mb-4 text-sm">Get started by creating the first affiliate shop for a user.</p>
            <Button
              onClick={() => setShowCreateDialog(true)}
              className="bg-blue-600 hover:bg-blue-700 w-full max-w-xs"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create First Shop
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}