// Live Button Monitor - Reports critical failures for auto-deployment
export class LiveButtonMonitor {
  private failureCount: Map<string, number> = new Map();
  private reportedFailures: Set<string> = new Set();
  private isMonitoring = true;

  constructor() {
    this.startLiveMonitoring();
    console.log('🔍 Live Button Monitor active - detecting failures for auto-deployment');
  }

  private startLiveMonitoring() {
    // PASSIVE monitoring only - never interfere with existing functionality
    // Monitor button clicks that fail (observation only)
    document.addEventListener('click', (event) => {
      if (!this.isMonitoring) return;

      const target = event.target as HTMLElement;
      const isButton = target.tagName === 'BUTTON' || 
                      target.getAttribute('role') === 'button' ||
                      target.tagName === 'A' ||
                      target.classList.contains('cursor-pointer');

      if (isButton) {
        // Use longer delay to avoid interfering with React state updates
        setTimeout(() => {
          this.checkButtonFunctionality(target);
        }, 500);
      }
    }, { passive: true }); // Passive listener - never prevents default

    // Periodic check for critical button functionality (less frequent to avoid interference)
    setInterval(() => {
      this.scanCriticalButtons();
    }, 30000); // Check every 30 seconds (reduced frequency)
  }

  private scanCriticalButtons() {
    const criticalSelectors = [
      'button[type="submit"]',
      'a[href*="login"]',
      'a[href*="sign-in"]', 
      'button:contains("sign in")',
      'button:contains("login")',
      'button:contains("emergency")',
      'button:contains("payment")',
      'button:contains("donate")',
      '.payment-button',
      '.stripe-button',
      '[data-testid*="login"]',
      '[data-testid*="signin"]'
    ];

    criticalSelectors.forEach(selector => {
      try {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
          this.checkButtonFunctionality(element as HTMLElement);
        });
      } catch (e) {
        // Continue with other selectors
      }
    });

    // Check for buttons containing critical text
    const allButtons = document.querySelectorAll('button, a[role="button"], [role="button"]');
    allButtons.forEach(button => {
      const text = button.textContent?.toLowerCase() || '';
      if (text.includes('sign in') || 
          text.includes('login') || 
          text.includes('emergency') ||
          text.includes('payment') ||
          text.includes('donate')) {
        this.checkButtonFunctionality(button as HTMLElement);
      }
    });
  }

  private checkButtonFunctionality(element: HTMLElement): boolean {
    const buttonId = this.getButtonIdentifier(element);
    const text = element.textContent?.toLowerCase() || '';
    
    // Check if button appears functional
    const hasClickHandler = !!(element.onclick || 
                             element.getAttribute('onclick') ||
                             (element as HTMLAnchorElement).href ||
                             element.getAttribute('href'));

    const isVisible = element.offsetParent !== null && 
                     element.getBoundingClientRect().width > 0;

    const looksClickable = element.style.cursor === 'pointer' ||
                          element.tagName === 'BUTTON' ||
                          element.tagName === 'A';

    const isFunctional = hasClickHandler && isVisible && looksClickable;

    if (!isFunctional) {
      this.recordButtonFailure(buttonId, text, element);
      return false;
    }

    return true;
  }

  private recordButtonFailure(buttonId: string, buttonText: string, element: HTMLElement) {
    const currentCount = this.failureCount.get(buttonId) || 0;
    this.failureCount.set(buttonId, currentCount + 1);

    // Report critical failures after 2 detection cycles
    if (currentCount >= 1 && !this.reportedFailures.has(buttonId)) {
      this.reportedFailures.add(buttonId);
      this.reportCriticalFailure(buttonId, buttonText, element);
    }
  }

  private async reportCriticalFailure(buttonId: string, buttonText: string, element: HTMLElement) {
    const failureData = {
      buttonType: buttonText,
      buttonId: buttonId,
      userLocation: this.getUserLocation(),
      severity: this.getSeverity(buttonText),
      elementDetails: {
        tagName: element.tagName,
        className: element.className,
        href: (element as HTMLAnchorElement).href || null,
        onclick: element.getAttribute('onclick') || null
      },
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      url: window.location.href
    };

    console.log('🚨 CRITICAL BUTTON FAILURE DETECTED:', failureData);

    // Show user notification that auto-fix is deploying
    this.showAutoFixNotification(buttonText);

    try {
      // Report to auto-deployment service
      const response = await fetch('/api/admin/button-failure-deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(failureData)
      });

      const result = await response.json();
      
      if (result.deploymentStatus === 'immediate') {
        this.showDeploymentNotification();
      }
    } catch (error) {
      console.error('Failed to report button failure:', error);
    }
  }

  private getSeverity(buttonText: string): 'low' | 'medium' | 'high' | 'critical' {
    const criticalButtons = ['sign in', 'login', 'emergency', 'payment', 'donate'];
    const highButtons = ['submit', 'send', 'save', 'create'];
    
    if (criticalButtons.some(btn => buttonText.includes(btn))) {
      return 'critical';
    }
    if (highButtons.some(btn => buttonText.includes(btn))) {
      return 'high';
    }
    return 'medium';
  }

  private getUserLocation(): string {
    // Attempt to get user location from various sources
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const language = navigator.language;
    
    // Basic location inference from timezone
    if (timezone.includes('Africa')) return 'Africa';
    if (timezone.includes('Europe')) return 'Europe';
    if (timezone.includes('America')) return 'Americas';
    if (timezone.includes('Asia')) return 'Asia';
    if (timezone.includes('Australia')) return 'Australia';
    
    return `${language}-${timezone}`;
  }

  private getButtonIdentifier(element: HTMLElement): string {
    const text = element.textContent?.trim() || '';
    const href = (element as HTMLAnchorElement).href || '';
    const id = element.id || '';
    const classes = element.className || '';
    
    return `${text}-${href}-${id}-${classes}`.substring(0, 150);
  }

  private showAutoFixNotification(buttonText: string) {
    const notification = document.createElement('div');
    notification.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: #f59e0b;
        color: white;
        padding: 16px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        z-index: 10000;
        max-width: 300px;
        font-size: 14px;
        font-weight: 500;
      ">
        🔧 Button fix deploying...<br>
        <small>${buttonText} should work in 2-3 minutes</small>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 8000);
  }

  private showDeploymentNotification() {
    const notification = document.createElement('div');
    notification.innerHTML = `
      <div style="
        position: fixed;
        top: 80px;
        right: 20px;
        background: #10b981;
        color: white;
        padding: 16px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        z-index: 10000;
        max-width: 300px;
        font-size: 14px;
        font-weight: 500;
      ">
        ✅ Fix deployed automatically!<br>
        <small>Button should work now</small>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 6000);
  }

  public stop() {
    this.isMonitoring = false;
  }
}

// Global instance
let liveButtonMonitor: LiveButtonMonitor;

export function startLiveButtonMonitor() {
  if (!liveButtonMonitor) {
    liveButtonMonitor = new LiveButtonMonitor();
    console.log('⚡ Button click monitoring started - auto-deployment triggers enabled');
  }
}

export function stopLiveButtonMonitor() {
  if (liveButtonMonitor) {
    liveButtonMonitor.stop();
    liveButtonMonitor = null as any;
  }
}