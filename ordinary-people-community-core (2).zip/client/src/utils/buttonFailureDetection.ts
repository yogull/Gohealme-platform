// Button Failure Detection System - Enhanced Brain Monitoring
// Tracks user button clicks and detects when they don't respond

interface ButtonClickData {
  buttonText: string;
  buttonId: string;
  currentPage: string;
  initialUrl: string;
  timestamp: number;
}

class ButtonFailureDetector {
  private clickData: Map<number, ButtonClickData> = new Map();
  private reportedFailures: Set<string> = new Set();

  constructor() {
    this.initializeMonitoring();
  }

  private initializeMonitoring() {
    // Monitor all button clicks
    document.addEventListener('click', (event) => {
      const target = event.target as Element;
      const buttonElement = this.findButtonElement(target);
      
      if (buttonElement) {
        this.trackButtonClick(buttonElement);
      }
    });

    // Monitor form submissions
    document.addEventListener('submit', (event) => {
      const form = event.target as HTMLFormElement;
      this.trackFormSubmission(form);
    });

    console.log('🔍 Button failure detection system active');
  }

  private findButtonElement(element: Element): HTMLElement | null {
    if (element.tagName === 'BUTTON') {
      return element as HTMLElement;
    }
    
    const buttonParent = element.closest('button');
    if (buttonParent) {
      return buttonParent as HTMLElement;
    }
    
    if (element.getAttribute('role') === 'button') {
      return element as HTMLElement;
    }
    
    return null;
  }

  private trackButtonClick(buttonElement: HTMLElement) {
    const buttonText = (buttonElement.textContent || buttonElement.innerHTML || '').trim();
    const buttonId = buttonElement.id || buttonElement.className || 'no-id';
    const currentPage = window.location.pathname;
    const timestamp = Date.now();

    console.log('🔘 Button clicked:', buttonText, 'on page:', currentPage);

    const clickData: ButtonClickData = {
      buttonText,
      buttonId,
      currentPage,
      initialUrl: window.location.href,
      timestamp
    };

    this.clickData.set(timestamp, clickData);

    // Check for button response after 3 seconds
    setTimeout(() => {
      this.checkButtonResponse(timestamp);
    }, 3000);
  }

  private checkButtonResponse(timestamp: number) {
    const clickData = this.clickData.get(timestamp);
    if (!clickData) return;

    const currentUrl = window.location.href;
    const urlChanged = currentUrl !== clickData.initialUrl;
    
    let buttonFailed = false;
    let failureReason = '';

    // Check specific button failure patterns
    const buttonText = clickData.buttonText.toLowerCase();

    if (buttonText.includes('change password')) {
      // Check if password dialog opened
      const dialogOpen = document.querySelector('[data-state="open"]') || 
                        document.querySelector('.dialog-content') ||
                        document.querySelector('[aria-expanded="true"]');
      if (!dialogOpen) {
        buttonFailed = true;
        failureReason = 'Change password button should open dialog but dialog not found';
      }
    } else if (buttonText.includes('back')) {
      // Back button should navigate
      if (!urlChanged && !history.length) {
        buttonFailed = true;
        failureReason = 'Back button clicked but no navigation occurred';
      }
    } else if (buttonText.includes('dashboard')) {
      // Dashboard button should navigate to dashboard
      if (!currentUrl.includes('/dashboard') && !urlChanged) {
        buttonFailed = true;
        failureReason = 'Dashboard button clicked but not navigated to dashboard';
      }
    } else if (buttonText.includes('settings')) {
      // Settings button should navigate to settings
      if (!currentUrl.includes('settings') && !urlChanged) {
        buttonFailed = true;
        failureReason = 'Settings button clicked but not navigated to settings';
      }
    } else if (buttonText.includes('submit') || buttonText.includes('save')) {
      // Check for form errors or success indicators
      const errors = document.querySelector('.error, .text-red-500, .text-destructive, [role="alert"]');
      const success = document.querySelector('.success, .text-green-500, [data-success="true"]');
      
      if (errors && !success) {
        buttonFailed = true;
        failureReason = 'Form submission button clicked but form shows errors';
      }
    }

    if (buttonFailed) {
      this.reportButtonFailure(clickData, failureReason);
    } else {
      console.log('✅ Button action successful:', clickData.buttonText);
    }

    // Cleanup old click data
    this.clickData.delete(timestamp);
  }

  private reportButtonFailure(clickData: ButtonClickData, failureReason: string) {
    const failureKey = `${clickData.currentPage}-${clickData.buttonText}`;
    
    // Avoid duplicate reports for the same button
    if (this.reportedFailures.has(failureKey)) {
      return;
    }
    
    this.reportedFailures.add(failureKey);

    console.error('❌ BUTTON FAILURE DETECTED:', {
      buttonText: clickData.buttonText,
      page: clickData.currentPage,
      reason: failureReason,
      buttonId: clickData.buttonId,
      timestamp: new Date(clickData.timestamp).toISOString()
    });

    // Report to Enhanced Autonomous Brain
    fetch('/api/button-failure-report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        buttonText: clickData.buttonText,
        buttonId: clickData.buttonId,
        currentPage: clickData.currentPage,
        failureReason,
        timestamp: clickData.timestamp,
        userAgent: navigator.userAgent
      })
    }).catch(err => {
      console.log('Failed to report button failure to brain:', err);
    });

    // Apply immediate client-side fixes
    this.applyImmediateFix(clickData);
  }

  private applyImmediateFix(clickData: ButtonClickData) {
    const buttonText = clickData.buttonText.toLowerCase();

    if (buttonText.includes('change password')) {
      // Force open password change dialog
      console.log('🔧 Applying immediate fix: Opening password dialog');
      this.forceOpenPasswordDialog();
    } else if (buttonText.includes('back')) {
      // Force navigation back
      console.log('🔧 Applying immediate fix: Forcing back navigation');
      window.history.back();
    } else if (buttonText.includes('dashboard')) {
      // Force navigation to dashboard
      console.log('🔧 Applying immediate fix: Forcing dashboard navigation');
      window.location.assign('/dashboard');
    } else if (buttonText.includes('settings')) {
      // Force navigation to settings
      console.log('🔧 Applying immediate fix: Forcing settings navigation');
      window.location.assign('/profile-settings');
    }
  }

  private forceOpenPasswordDialog() {
    // Try multiple methods to open password dialog
    const passwordButton = document.querySelector('button[aria-haspopup="dialog"]') ||
                          document.querySelector('button:contains("Change Password")') ||
                          document.querySelector('[data-dialog-trigger]');
    
    if (passwordButton) {
      (passwordButton as HTMLElement).click();
    }
  }

  private trackFormSubmission(form: HTMLFormElement) {
    const formType = form.id || form.className || 'unknown-form';
    console.log('📝 Form submitted:', formType);

    setTimeout(() => {
      const hasErrors = document.querySelector('.error, .text-red-500, .text-destructive, [role="alert"]');
      const hasSuccess = document.querySelector('.success, .text-green-500, [data-success="true"]');
      
      if (hasErrors && !hasSuccess) {
        console.error('❌ FORM FAILURE DETECTED:', formType);
        
        fetch('/api/form-failure-report', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            formType,
            currentPage: window.location.pathname,
            timestamp: Date.now()
          })
        }).catch(err => console.log('Failed to report form failure:', err));
      }
    }, 2000);
  }
}

// Initialize the button failure detector when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new ButtonFailureDetector();
  });
} else {
  new ButtonFailureDetector();
}

export default ButtonFailureDetector;