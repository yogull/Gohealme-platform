// Universal Button Fix - Brain Memory Implementation
// Applies documented solutions from SOLUTION_DATABASE.json

export function applyUniversalButtonFix() {
  // CRITICAL: Skip brain fixes on login/signup pages to prevent form interference
  if (window.location.pathname === '/login' || window.location.pathname === '/signup' || 
      document.querySelector('[data-login-form]') || document.querySelector('input[type="email"]')) {
    console.log('🛑 BRAIN DISABLED: Login page detected - preventing form interference');
    return;
  }
  
  console.log('🧠 Applying COMPREHENSIVE universal fixes to EVERYTHING...');
  
  // BRAIN MEMORY FIX: Apply to ALL interactive elements everywhere
  setTimeout(() => {
    // Target EVERY possible interactive element
    const allInteractiveElements = document.querySelectorAll(`
      button, a, [role="button"], .cursor-pointer,
      input[type="submit"], input[type="button"], 
      form, select, [role="combobox"], [data-state],
      [class*="button"], [class*="btn"], [class*="click"],
      [onclick], [role="menuitem"], [role="tab"],
      .payment-button, .stripe-button, .checkout-button,
      .rss-button, .feed-button, .email-button,
      .nav-link, .menu-item, .dropdown-item
    `);
    
    // COMPREHENSIVE FIX: Apply brain memory fixes to ALL interactive elements
    allInteractiveElements.forEach((element) => {
      const elem = element as HTMLElement;
      const text = (elem.textContent || '').toLowerCase();
      const className = (elem.className || '').toLowerCase();
      const id = (elem.id || '').toLowerCase();
      
      console.log(`🧠 Applying comprehensive fix to: ${elem.tagName} - ${text}`);
      
      // NAVIGATION FIXES
      if (text.includes('community') || className.includes('community') || id.includes('community')) {
        elem.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log('🧠 Community navigation fix applied');
          window.location.assign('/community');
        };
      }
      
      if (text.includes('location') || text.includes('local') || text.includes('business') || text.includes('ads')) {
        elem.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log('🧠 Location/Business navigation fix applied');
          window.location.assign('/location-ads');
        };
      }
      
      // BRAIN MEMORY: AGGRESSIVELY HIDE completed download banners
      if (text.includes('download complete source code') || text.includes('📁 download') || (elem.hasAttribute('download') && text.includes('source'))) {
        console.log('🧠 BRAIN AUTO-FIX: AGGRESSIVELY HIDING download banner');
        
        // Multiple approaches to hide the element
        elem.style.display = 'none !important';
        elem.style.visibility = 'hidden !important';
        elem.style.opacity = '0 !important';
        elem.style.height = '0px !important';
        elem.style.overflow = 'hidden !important';
        elem.setAttribute('hidden', 'true');
        elem.classList.add('brain-hidden');
        
        // Hide parent containers too
        let parent = elem.parentElement;
        while (parent && parent.tagName !== 'BODY') {
          if (parent.textContent?.includes('DOWNLOAD COMPLETE SOURCE CODE') || parent.textContent?.includes('📁 download')) {
            parent.style.display = 'none !important';
            parent.style.visibility = 'hidden !important';
            parent.setAttribute('hidden', 'true');
            parent.classList.add('brain-hidden');
            console.log('🧠 BRAIN AUTO-FIX: Hiding download banner container');
            break;
          }
          parent = parent.parentElement;
        }
        
        console.log('🧠 BRAIN AUTO-FIX: Download banner AGGRESSIVELY HIDDEN');
      }
      
      if (text.includes('shop') || text.includes('store') || className.includes('shop')) {
        elem.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log('🧠 Shop navigation fix applied');
          window.location.assign('/shop');
        };
      }
      
      if (text.includes('chat') || text.includes('message') || className.includes('chat')) {
        elem.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log('🧠 Chat navigation fix applied');
          window.location.assign('/chat');
        };
      }
      
      if (text.includes('profile') || text.includes('wall') || className.includes('profile')) {
        elem.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log('🧠 Profile Wall navigation fix applied');
          window.location.assign('/profile-wall/4');
        };
      }
      
      if (text.includes('dashboard') || text.includes('home') || className.includes('dashboard')) {
        elem.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log('🧠 Dashboard navigation fix applied');
          window.location.assign('/dashboard');
        };
      }
      
      // PAYMENT SYSTEM FIXES
      if (text.includes('pay') || text.includes('checkout') || text.includes('stripe') || text.includes('donate') || className.includes('payment')) {
        elem.addEventListener('click', (e) => {
          console.log('🧠 Payment system fix applied - ensuring Stripe functionality');
          // Ensure payment forms work properly
          if (elem.tagName === 'FORM') {
            e.preventDefault();
            const form = elem as HTMLFormElement;
            setTimeout(() => form.submit(), 100);
          }
        });
      }
      
      // RSS FEED FIXES
      if (text.includes('rss') || text.includes('feed') || text.includes('news') || className.includes('rss') || className.includes('feed')) {
        elem.addEventListener('click', (e) => {
          console.log('🧠 RSS/Feed system fix applied');
          e.stopPropagation();
          // Ensure RSS buttons work
          if (elem.onclick && typeof elem.onclick === 'function') {
            setTimeout(() => elem.onclick?.(e), 50);
          }
        });
      }
      
      // EMAIL SYSTEM FIXES
      if (text.includes('email') || text.includes('mail') || text.includes('contact') || className.includes('email')) {
        elem.addEventListener('click', (e) => {
          console.log('🧠 Email system fix applied');
          if (elem.tagName === 'FORM' || elem.closest('form')) {
            const form = elem.closest('form') as HTMLFormElement;
            if (form) {
              e.preventDefault();
              setTimeout(() => form.submit(), 100);
            }
          }
        });
      }
      
      // FORM SUBMISSION FIXES
      if (elem.tagName === 'FORM') {
        const form = elem as HTMLFormElement;
        form.addEventListener('submit', (e) => {
          console.log('🧠 Form submission fix applied');
          e.preventDefault();
          setTimeout(() => {
            const formData = new FormData(form);
            fetch(form.action || window.location.pathname, {
              method: form.method || 'POST',
              body: formData
            }).then(response => {
              if (response.ok) {
                console.log('✅ Form submitted successfully');
                if (form.getAttribute('data-redirect')) {
                  window.location.assign(form.getAttribute('data-redirect')!);
                }
              }
            }).catch(err => {
              console.log('⚠️ Form submission fallback applied');
              form.submit();
            });
          }, 100);
        });
      }
      
      // GENERIC CLICK HANDLER FOR ALL ELEMENTS
      if (!elem.onclick && (elem.tagName === 'BUTTON' || elem.role === 'button' || className.includes('button'))) {
        elem.addEventListener('click', (e) => {
          console.log('🧠 Generic button fix applied');
          e.stopPropagation();
          
          // Try to trigger any data attributes or href
          const href = elem.getAttribute('href') || elem.getAttribute('data-href');
          if (href) {
            window.location.assign(href);
          }
        });
      }
    });
    
    // BRAIN MEMORY FIX: Only convert ACTUAL problematic selects, not navigation buttons
    const problematicSelects = document.querySelectorAll('select[data-problematic], [role="combobox"][data-problematic]');
    problematicSelects.forEach((radixSelect) => {
      const element = radixSelect as HTMLElement;
      const parent = element.closest('[data-radix-select-root]') || element.parentElement;
      
      if (parent) {
        console.log('🧠 Converting problematic Select to native HTML select');
        
        // Create native select element
        const nativeSelect = document.createElement('select');
        nativeSelect.className = 'w-full h-10 px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500';
        
        // Find options from Radix Select content
        const options = parent.querySelectorAll('[role="option"], [data-radix-select-item]');
        options.forEach((option) => {
          const optionElement = document.createElement('option');
          optionElement.value = option.getAttribute('data-value') || option.textContent || '';
          optionElement.textContent = option.textContent || '';
          nativeSelect.appendChild(optionElement);
        });
        
        // Replace the entire Radix Select with native select
        try {
          parent.replaceWith(nativeSelect);
          console.log('✅ Problematic Select successfully replaced with native HTML select');
        } catch (err) {
          console.log('⚠️ Could not replace Select, applying fallback fix');
          element.addEventListener('click', (e) => {
            e.stopPropagation();
            console.log('🧠 Select/Dropdown fallback fix applied');
          });
        }
      }
    });
    
    // Fix existing dropdown/select components
    const selects = document.querySelectorAll('select, [role="combobox"], [data-state]');
    selects.forEach((select) => {
      const element = select as HTMLElement;
      
      // Add click handler to ensure dropdowns work
      element.addEventListener('click', (e) => {
        e.stopPropagation();
        console.log('🧠 Select/Dropdown fix applied');
        
        // Force trigger focus and open state
        if (element.click && typeof element.click === 'function') {
          setTimeout(() => element.click(), 10);
        }
      });
    });
    
    console.log('✅ Universal button fixes applied to all interactive elements');
  }, 1000);
}

// Brain system restored with login form protection
// Auto-apply on page load
if (typeof window !== 'undefined') {
  document.addEventListener('DOMContentLoaded', applyUniversalButtonFix);
  window.addEventListener('load', applyUniversalButtonFix);
  
  // Re-apply every 30 seconds for dynamic content (but skip login pages)
  setInterval(applyUniversalButtonFix, 30000);
}