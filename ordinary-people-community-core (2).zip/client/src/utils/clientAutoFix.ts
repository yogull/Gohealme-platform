/**
 * Client-Side Auto-Fix System
 * Monitors UI components and fixes issues automatically
 */

class ClientAutoFixSystem {
  private isActive = false;
  private fixIntervals: NodeJS.Timeout[] = [];

  // Disabled permanent monitoring - using deployment snapshots instead
  startPermanentMonitoring() {
    if (this.isActive) return;
    this.isActive = false;
    
    console.log('🛑 CLIENT AUTO-FIX: Monitoring disabled - using snapshot deployment system');
    // All auto-fix intervals removed to prevent code interference
  }

  // Check and fix UI components
  private checkUIComponents() {
    try {
      // Fix any missing z-index issues
      this.fixZIndexIssues();
      
      // Fix unclickable elements
      this.fixClickableElements();
      
      // Fix missing scroll functionality
      this.fixScrollIssues();
      
    } catch (error) {
      console.log('🔧 CLIENT AUTO-FIX: Repairing UI components');
    }
  }

  // Fix dropdown z-index and functionality issues
  private fixDropdownIssues() {
    const dropdowns = document.querySelectorAll('[data-radix-popper-content-wrapper]');
    dropdowns.forEach((dropdown) => {
      const element = dropdown as HTMLElement;
      if (element.style.zIndex !== '9999') {
        element.style.zIndex = '9999';
        element.style.position = 'fixed';
      }
    });

    // Fix Select components specifically
    const selectContents = document.querySelectorAll('[role="listbox"]');
    selectContents.forEach((content) => {
      const element = content as HTMLElement;
      element.style.zIndex = '9999';
      element.style.maxHeight = '240px';
      element.style.overflowY = 'auto';
    });
  }

  // Fix button click issues
  private fixButtonIssues() {
    const buttons = document.querySelectorAll('button');
    buttons.forEach((button) => {
      if (!button.onclick && !button.getAttribute('data-click-fixed')) {
        button.style.pointerEvents = 'auto';
        button.style.cursor = 'pointer';
        button.setAttribute('data-click-fixed', 'true');
      }
    });
  }

  // Fix form submission issues
  private fixFormIssues() {
    const forms = document.querySelectorAll('form');
    forms.forEach((form) => {
      if (!form.getAttribute('data-form-fixed')) {
        form.style.opacity = '1';
        form.style.pointerEvents = 'auto';
        form.setAttribute('data-form-fixed', 'true');
      }
    });
  }

  // Fix z-index issues across the site
  private fixZIndexIssues() {
    // Skip dialog interference - let dialogs manage their own state
    const modals = document.querySelectorAll('[role="dialog"]:not([data-dialog-protected])');
    modals.forEach((modal) => {
      const element = modal as HTMLElement;
      element.style.zIndex = '9999';
    });

    // Fix dropdowns and selects
    const selectTriggers = document.querySelectorAll('[data-radix-select-trigger]');
    selectTriggers.forEach((trigger) => {
      const element = trigger as HTMLElement;
      element.style.zIndex = '1';
    });
  }

  // Fix clickable elements
  private fixClickableElements() {
    const clickables = document.querySelectorAll('[data-clickable="true"], .cursor-pointer');
    clickables.forEach((element) => {
      const el = element as HTMLElement;
      el.style.pointerEvents = 'auto';
      el.style.cursor = 'pointer';
    });
  }

  // Fix scroll issues
  private fixScrollIssues() {
    const scrollContainers = document.querySelectorAll('.overflow-y-auto, .overflow-auto');
    scrollContainers.forEach((container) => {
      const element = container as HTMLElement;
      if (element.scrollHeight > element.clientHeight) {
        element.style.overflowY = 'auto';
      }
    });
  }

  // Stop monitoring (emergency only)
  stopMonitoring() {
    this.isActive = false;
    this.fixIntervals.forEach(interval => clearInterval(interval));
    this.fixIntervals = [];
    console.log('🛡️ CLIENT AUTO-FIX: Monitoring stopped');
  }
}

// Create global instance
export const clientAutoFix = new ClientAutoFixSystem();

// Auto-start when DOM is ready
if (typeof window !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      clientAutoFix.startPermanentMonitoring();
    });
  } else {
    clientAutoFix.startPermanentMonitoring();
  }
}