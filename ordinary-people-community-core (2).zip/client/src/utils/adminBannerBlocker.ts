// Admin Banner Blocker - DISABLED FOR JOHN'S ACCESS
export const blockAdminBanners = () => {
  // DISABLED - Return early to allow download buttons
  return;
  const hideElement = (elem: HTMLElement) => {
    elem.style.cssText = `
      display: none !important;
      visibility: hidden !important;
      opacity: 0 !important;
      height: 0px !important;
      width: 0px !important;
      margin: 0 !important;
      padding: 0 !important;
      border: none !important;
      overflow: hidden !important;
      position: absolute !important;
      left: -99999px !important;
      top: -99999px !important;
      z-index: -9999 !important;
      pointer-events: none !important;
      user-select: none !important;
    `;
    elem.classList.add('brain-hidden');
    elem.setAttribute('data-brain-hidden', 'true');
  };

  // Target specific download banner patterns
  const bannersToHide = [
    'a[href*="download/source-code"]',
    'a[href*="admin-control-panel"]',
    'a[href*="ordinary-people-community-core.zip"]',
    '*[data-admin-download]',
    // Text-based selectors using CSS :has() where supported
  ];

  bannersToHide.forEach(selector => {
    document.querySelectorAll(selector).forEach(elem => {
      hideElement(elem as HTMLElement);
    });
  });

  // Text-based hiding for browsers that don't support :has()
  document.querySelectorAll('*').forEach(elem => {
    const text = elem.textContent?.toLowerCase() || '';
    const href = (elem as HTMLAnchorElement).href?.toLowerCase() || '';
    
    if (text.includes('📁 download complete source code') ||
        text.includes('admin control panel') ||
        text.includes('download complete source code') ||
        href.includes('download/source-code') ||
        href.includes('admin-control-panel') ||
        (text.includes('source code') && text.includes('1.4mb'))) {
      hideElement(elem as HTMLElement);
      
      // Also hide parent if it only contains download content
      const parent = elem.parentElement;
      if (parent && parent.textContent?.toLowerCase().includes('download') && 
          parent.children.length === 1) {
        hideElement(parent);
      }
    }
  });
};

// Auto-run on DOM changes
let observer: MutationObserver;

export const startAdminBannerBlocker = () => {
  // Initial run
  blockAdminBanners();
  
  // Watch for DOM changes
  observer = new MutationObserver(() => {
    blockAdminBanners();
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['href', 'data-admin-download']
  });
  
  // Periodic cleanup
  setInterval(blockAdminBanners, 2000);
};

export const stopAdminBannerBlocker = () => {
  if (observer) {
    observer.disconnect();
  }
};