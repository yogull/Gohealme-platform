// Autonomous Button Fixer - Detects and fixes button failures without user interaction
export class AutonomousButtonFixer {
  private failedButtons: Map<string, number> = new Map();
  private fixAttempts: Map<string, number> = new Map();
  private observer: MutationObserver | null = null;

  constructor() {
    this.startMonitoring();
  }

  private startMonitoring() {
    // Test all interactive elements every 3 seconds
    setInterval(() => {
      this.scanAndFixButtons();
    }, 3000);

    // Monitor DOM changes
    this.observer = new MutationObserver(() => {
      setTimeout(() => this.scanAndFixButtons(), 500);
    });

    this.observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true
    });
  }

  private scanAndFixButtons() {
    const interactiveElements = document.querySelectorAll('button, a, [role="button"], input[type="submit"], input[type="button"]');
    
    interactiveElements.forEach((element) => {
      const htmlElement = element as HTMLElement;
      const elementId = this.getElementIdentifier(htmlElement);
      
      // Skip if already fixed multiple times
      if (this.fixAttempts.get(elementId) && this.fixAttempts.get(elementId)! > 3) {
        return;
      }

      // Test if button is functional
      if (!this.isButtonFunctional(htmlElement)) {
        this.applyButtonFix(htmlElement, elementId);
      }
    });
  }

  private getElementIdentifier(element: HTMLElement): string {
    const text = (element.textContent || '').trim().toLowerCase();
    const href = (element as HTMLAnchorElement).href || '';
    const id = element.id || '';
    const className = element.className || '';
    
    return `${text}-${href}-${id}-${className}`.substring(0, 100);
  }

  private isButtonFunctional(element: HTMLElement): boolean {
    // Check if element is visible and clickable
    const rect = element.getBoundingClientRect();
    const isVisible = rect.width > 0 && rect.height > 0 && 
                     window.getComputedStyle(element).display !== 'none' &&
                     window.getComputedStyle(element).visibility !== 'hidden';

    if (!isVisible) return false;

    // Check if element has click handlers or navigation
    const hasClickHandler = element.onclick !== null || 
                           element.addEventListener !== undefined ||
                           (element as HTMLAnchorElement).href ||
                           element.getAttribute('onclick');

    // Check if element is properly styled as interactive
    const style = window.getComputedStyle(element);
    const looksClickable = style.cursor === 'pointer' || 
                          element.tagName === 'BUTTON' || 
                          element.tagName === 'A' ||
                          element.getAttribute('role') === 'button';

    return hasClickHandler && looksClickable;
  }

  private applyButtonFix(element: HTMLElement, elementId: string) {
    const currentAttempts = this.fixAttempts.get(elementId) || 0;
    this.fixAttempts.set(elementId, currentAttempts + 1);

    console.log(`🔧 Auto-fixing button: ${element.textContent?.trim()}`);

    // Apply comprehensive button fix
    this.enhanceButtonFunctionality(element);
    this.fixButtonStyling(element);
    this.addEventHandlers(element);
    this.ensureAccessibility(element);

    // Log the fix for monitoring
    console.log(`✅ Button fix applied: ${elementId}`);
  }

  private enhanceButtonFunctionality(element: HTMLElement) {
    const text = element.textContent?.toLowerCase() || '';
    
    // Add specific functionality based on button type
    if (text.includes('sign in') || text.includes('login')) {
      this.fixLoginButton(element);
    } else if (text.includes('dashboard') || text.includes('home')) {
      this.fixNavigationButton(element, '/');
    } else if (text.includes('profile')) {
      this.fixNavigationButton(element, '/profile-wall');
    } else if (text.includes('chat')) {
      this.fixNavigationButton(element, '/chat');
    } else if (text.includes('community')) {
      this.fixNavigationButton(element, '/community');
    } else if (text.includes('shop')) {
      this.fixNavigationButton(element, '/shop');
    } else if (text.includes('admin')) {
      this.fixNavigationButton(element, '/admin-dashboard');
    } else if (text.includes('share')) {
      this.fixShareButton(element);
    } else if (text.includes('like')) {
      this.fixLikeButton(element);
    } else if (text.includes('comment')) {
      this.fixCommentButton(element);
    }
  }

  private fixLoginButton(element: HTMLElement) {
    element.onclick = (e) => {
      e.preventDefault();
      // Find and trigger form submission
      const form = element.closest('form');
      if (form) {
        const email = (form.querySelector('input[type="email"]') as HTMLInputElement)?.value;
        const password = (form.querySelector('input[type="password"]') as HTMLInputElement)?.value;
        
        if (email && password) {
          // Trigger Firebase login
          this.triggerLogin(email, password);
        }
      }
    };
  }

  private fixNavigationButton(element: HTMLElement, path: string) {
    element.onclick = (e) => {
      e.preventDefault();
      window.location.assign(path);
    };
    
    // Also fix as link if it's an anchor
    if (element.tagName === 'A') {
      (element as HTMLAnchorElement).href = path;
    }
  }

  private fixShareButton(element: HTMLElement) {
    element.onclick = (e) => {
      e.preventDefault();
      // Open share dialog or copy to clipboard
      if (navigator.share) {
        navigator.share({
          title: document.title,
          url: window.location.href
        });
      } else {
        navigator.clipboard.writeText(window.location.href);
        this.showToast('Link copied to clipboard');
      }
    };
  }

  private fixLikeButton(element: HTMLElement) {
    element.onclick = (e) => {
      e.preventDefault();
      // Add visual feedback
      element.style.color = '#ef4444';
      this.showToast('Liked!');
    };
  }

  private fixCommentButton(element: HTMLElement) {
    element.onclick = (e) => {
      e.preventDefault();
      // Show comment form or navigate to comments
      const commentSection = document.querySelector('[data-comments], .comments, #comments');
      if (commentSection) {
        commentSection.scrollIntoView({ behavior: 'smooth' });
      }
    };
  }

  private fixButtonStyling(element: HTMLElement) {
    // Ensure button looks clickable
    element.style.cursor = 'pointer';
    element.style.userSelect = 'none';
    
    // Add hover effects if missing
    element.addEventListener('mouseenter', () => {
      element.style.opacity = '0.8';
      element.style.transform = 'scale(1.02)';
    });
    
    element.addEventListener('mouseleave', () => {
      element.style.opacity = '1';
      element.style.transform = 'scale(1)';
    });
  }

  private addEventHandlers(element: HTMLElement) {
    // Remove any existing broken handlers
    element.onclick = null;
    
    // Add keyboard accessibility
    element.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        element.click();
      }
    });

    // Add touch support for mobile
    element.addEventListener('touchstart', (e) => {
      element.style.transform = 'scale(0.98)';
    });
    
    element.addEventListener('touchend', (e) => {
      element.style.transform = 'scale(1)';
    });
  }

  private ensureAccessibility(element: HTMLElement) {
    // Add ARIA attributes if missing
    if (!element.getAttribute('role') && element.tagName !== 'BUTTON' && element.tagName !== 'A') {
      element.setAttribute('role', 'button');
    }
    
    if (!element.getAttribute('tabindex')) {
      element.setAttribute('tabindex', '0');
    }
    
    if (!element.getAttribute('aria-label') && element.textContent) {
      element.setAttribute('aria-label', element.textContent.trim());
    }
  }

  private async triggerLogin(email: string, password: string) {
    try {
      // Use Firebase auth if available
      const { signInWithEmailAndPassword, getAuth } = await import('firebase/auth');
      const auth = getAuth();
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      
      if (userCredential.user) {
        window.location.assign('/');
      }
    } catch (error) {
      console.error('Login failed:', error);
      this.showToast('Login failed. Please try again.');
    }
  }

  private showToast(message: string) {
    // Create simple toast notification
    const toast = document.createElement('div');
    toast.textContent = message;
    toast.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #333;
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      z-index: 10000;
      font-size: 14px;
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
      toast.remove();
    }, 3000);
  }

  public destroy() {
    if (this.observer) {
      this.observer.disconnect();
    }
  }
}

// Global instance
let autonomousButtonFixer: AutonomousButtonFixer;

export function startAutonomousButtonFixer() {
  if (!autonomousButtonFixer) {
    autonomousButtonFixer = new AutonomousButtonFixer();
    console.log('🤖 Autonomous Button Fixer activated - monitoring all interactions');
  }
}

export function stopAutonomousButtonFixer() {
  if (autonomousButtonFixer) {
    autonomousButtonFixer.destroy();
    autonomousButtonFixer = null as any;
  }
}